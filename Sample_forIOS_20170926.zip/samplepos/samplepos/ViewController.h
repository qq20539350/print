//
//  ViewController.h
//  samplepos
//
//  Created by 彭书旗 on 2017/7/17.
//  Copyright © 2017年 Caysn. All rights reserved.
//

#import "AppDelegate.h"

@interface ViewController : UIViewController<BLEPrintingDiscoverDelegate>

@end

