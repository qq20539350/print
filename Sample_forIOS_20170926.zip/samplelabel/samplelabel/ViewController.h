//
//  ViewController.h
//  samplebarcode
//
//  Created by 彭书旗 on 16/4/23.
//  Copyright © 2016年 开聪电子. All rights reserved.
//

#import "AppDelegate.h"

@interface ViewController : UIViewController<BLEPrintingDiscoverDelegate>

@end

