//
//  FBProtocol.h
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <Foundation/Foundation.h>

extern const UInt16 FBBootstrap;

extern UInt8 cacChecksum(const UInt8 *data, const UInt16 len);

typedef struct __FBResponseInfo {
    UInt16 bootstrap;
    UInt16 length;
    UInt8 responseID;
    UInt8 statusCode;
    UInt8 checksum;
    UInt16 bodyLength;
    const UInt8 *bodyBytes;
} FBResponseInfo;
