//
//  FBRequest.h
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FBPacket : NSObject

@property (nonatomic, assign, readonly) UInt8 packetID;
@property (nonatomic, assign, readonly) BOOL isResponse;
@property (nonatomic, strong, readonly) NSData *encodedData;

- (id)initWithID:(UInt8)packetID;
- (id)initWithID:(UInt8)packetID isResponse:(BOOL)isResponse;
- (void)beginEncoding;
- (void)endEncoding;
- (void)encodeInt8:(UInt8)value;
- (void)encodeInt16:(UInt16)value;
- (void)encodeInt32:(UInt32)value;
- (void)encodeBytes:(const void *)bytes length:(NSUInteger)length;

@end
