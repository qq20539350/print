//
//  FBSession.h
//  FeasycomLE
//
//  Created by LIDONG on 5/4/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "FBPacket.h"
#import "FBResponse.h"

@class FBPeripheralItem;
@class FBSession;


typedef enum __FBSessionState : char {
    FBSessionStateUnknown = 0,
    FBSessionStateAuthorizing,
    FBSessionStateAuthorized
} FBSessionState;

typedef enum __FBSessionMode : unsigned char {
    FBSessionModeUnknown = 0,
    FBSessionModeUnsafe = 1,
    FBSessionModeCommunication = 0xA0,
    FBSessionModeSettings = 0xA1
} FBSessionMode;


@protocol FBSessionDelegate <NSObject>

@required
- (void)sessionDidOpen:(FBSession *)session;
- (void)sessionDidClose:(FBSession *)session error:(NSError *)error;
- (void)sessionDidFinishAuthorizing:(FBSession *)session;
- (void)sessionAuthorizingDidTimeout:(FBSession *)session;
- (void)session:(FBSession *)session authorizationDidFailWithError:(NSError *)error;

@optional
- (void)session:(FBSession *)session didReceiveResponse:(FBResponse *)response forRequest:(FBPacket *)request;
- (void)session:(FBSession *)session requestDidTimeout:(FBPacket *)request;
- (void)session:(FBSession *)session requestDidFail:(FBPacket *)request error:(NSError *)error;
- (void)sessionDidWriteData:(FBSession *)session;
- (void)session:(FBSession *)session didFailToWriteWithError:(NSError *)error;
- (void)session:(FBSession *)session didReceiveData:(NSData *)data;

@end

@interface FBSession : NSObject

@property (nonatomic, weak) id<FBSessionDelegate> delegate;
@property (nonatomic, strong, readonly) FBPeripheralItem *peripheralItem;
@property (nonatomic, assign, readonly) BOOL isAuthorized;

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem;
- (BOOL)sendPacket:(FBPacket *)request timeoutInterval:(NSTimeInterval)timeoutInterval;
- (BOOL)sendData:(NSData *)data;
- (BOOL)sendData:(NSData *)data withoutResponse:(BOOL)withoutResponse;
- (void)authorizeWithMode:(FBSessionMode)mode timeoutInterval:(NSTimeInterval)timeoutInterval;
- (void)close;

@end
