//
//  FBResponse.h
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FBResponse : NSObject

@property (nonatomic, assign, readonly) UInt8 responseID;
@property (nonatomic, assign, readonly) UInt8 statusCode;
@property (nonatomic, assign, readonly) UInt8 checksum;
@property (nonatomic, assign, readonly) UInt16 bodyLength;

- (void)beginDecoding;
- (BOOL)endDecoding;
- (BOOL)decodeInt8:(UInt8 *)value;
- (BOOL)decodeInt16:(UInt16 *)value;
- (BOOL)decodeInt32:(UInt32 *)value;
- (BOOL)decodeBytes:(UInt8 *)bytes length:(UInt16)length;
- (NSData *)bodyData;

@end
