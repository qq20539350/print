//
//  FBPeripheralItem.h
//  FeasycomLE
//
//  Created by LIDONG on 14-2-28.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@class FBPeripheralItem;

typedef enum __FBPeripheralItemState : char {
    FBPeripheralItemStateDisconnected = 0,
    FBPeripheralItemStateConnecting,
    FBPeripheralItemStateConnected,
    FBPeripheralItemStateOpened
} FBPeripheralItemState;

@protocol FBPeripheralItemDelegate <NSObject>

@optional
- (void)peripheralItemDidOpen:(FBPeripheralItem *)peripheralItem;
- (void)peripheralItemDidClose:(FBPeripheralItem *)peripheralItem error:(NSError *)error;
- (void)peripheralItem:(FBPeripheralItem *)peripheralItem didUpdateRSSI:(NSInteger)RSSI;
- (void)peripheralItem:(FBPeripheralItem *)peripheralItem didReceiveData:(NSData *)data;
- (void)peripheralItemDidWrite:(FBPeripheralItem *)peripheralItem;
- (void)peripheralItem:(FBPeripheralItem *)peripheralItem didFailToWriteWithError:(NSError *)error;

@end

@interface FBPeripheralItem : NSObject

@property (nonatomic, strong, readonly) NSString *name;
@property (nonatomic, strong, readonly) NSString *UUID;
@property (nonatomic, assign, readonly) NSInteger RSSI;
@property (nonatomic, strong, readonly) NSArray *serviceUUIDs;
@property (nonatomic, assign, readonly) FBPeripheralItemState state;
@property (nonatomic, assign, readonly) BOOL isConnectable;

- (BOOL)connect;
- (BOOL)connectWithCharacteristics:(NSArray *)characteristicsUUIDs;
- (void)disconnect;
- (void)readRSSI;
- (BOOL)writeData:(NSData *)data;
- (BOOL)writeData:(NSData *)data withoutResponse:(BOOL)withoutResponse;
- (void)attachDelegate:(id<FBPeripheralItemDelegate>)delegate;
- (void)detachDelegate:(id<FBPeripheralItemDelegate>)delegate;

@end
