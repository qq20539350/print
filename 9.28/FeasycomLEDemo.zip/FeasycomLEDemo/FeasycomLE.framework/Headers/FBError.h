//
//  FBError.h
//  FeasycomLE
//
//  Created by LIDONG on 7/9/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <Foundation/Foundation.h>


extern NSString * const FBBrowserErrorDomain;
extern NSString * const FBSessionErrorDomain;
extern NSString * const FBPeripheralItemErrorDomain;

typedef enum : NSUInteger {
    FBBrowserErrorNone = 0,
    FBBrowserErrorBLEUnsupported,
    FBBrowserErrorBLEUnauthorized,
    FBBrowserErrorBLEPowerOff,
} FBBrowserError;

typedef enum : NSUInteger {
    FBSessionErrorNone = 0,
    FBSessionErrorInvalidResponse,
    FBSessionErrorAuthorizationFailed
} FBSessionError;

typedef enum : NSUInteger {
    FBPeripheralItemErrorNone = 0,
    FBPeripheralItemErrorConnectionTimeout,
    FBPeripheralItemErrorDiscoveringTimeout
} FBPeripheralItemError;