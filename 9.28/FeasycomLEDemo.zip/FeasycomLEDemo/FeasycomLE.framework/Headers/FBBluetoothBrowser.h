//
//  FBBluetoothBrowser.h
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FBBluetoothBrowser;
@class FBPeripheralItem;

@protocol FBBluetoothBrowserDelegate <NSObject>
@required
- (void)bluetoothBrowserDidStartScanning:(FBBluetoothBrowser *)bluetoothBrowser;
- (void)bluetoothBrowserDidStopScanning:(FBBluetoothBrowser *)bluetoothBrowser;
- (void)bluetoothBrowser:(FBBluetoothBrowser *)bluetoothBrowser didFindPeripheralItem:(FBPeripheralItem *)peripheralItem;
- (void)bluetoothBrowser:(FBBluetoothBrowser *)bluetoothBrowser didRemovePeripheralItem:(FBPeripheralItem *)peripheralItem;
- (void)bluetoothBrowser:(FBBluetoothBrowser *)bluetoothBrowser didUpdatePeripheralItems:(NSArray *)peripheralItems;
@end


@interface FBBluetoothBrowser : NSObject

@property (nonatomic, weak) id<FBBluetoothBrowserDelegate> delegate;
@property (nonatomic, assign, readonly) BOOL isScanning;

- (BOOL)startScanningWithServices:(NSArray *)serviceUUIDs;
- (void)stopScanning;

@end
