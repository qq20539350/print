//
//  FBSettings.m
//  FeasycomLE
//
//  Created by LIDONG on 14-2-24.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import "FBSettings.h"

NSString * const CFBundleShortVersionString = @"CFBundleShortVersionString";
NSString * const NSStringEmpty = @"";
NSString * const FBPeripheralItemDidFinishUpdateNotification = @"FBPeripheralItemDidFinishUpdateNotification";
NSString * const FBPeripheralItemDidFailUpdateNotification = @"FBPeripheralItemDidFailUpdateNotification";

CGRect FBScreenBounds;
CGFloat FBScreenScale;
NSString * FSDocumentsDirectory;
NSFileManager *NSMainFileManager;
NSDateFormatter *NSMainDateFormatter;
NSString *NSIdentifierForVendor;
NSString *NSAppVersion;

UIViewAnimationCurve NSKeyboardAnimationCurve = 7;
NSTimeInterval NSKeyboardAnimationDuration = 0.25;

UIColor *UIColorClear;
UIColor *UIColorWhite;
UIColor *UIColorBlack;
UIColor *UIColorBackground;
UIColor *UIColorMainText;
UIColor *UIColorSubText;
UIColor *UIColorSeparator;

UIFont *UIFont12;
UIFont *UIFont13;
UIFont *UIFont14;
UIFont *UIFont16;
UIFont *UIFont19;
UIFont *UIFontBold14;
UIFont *UIFontBold16;
UIFont *UIFontBold19;


void FBGlobalIntialize(void) {
    UIScreen *mainScreen = [UIScreen mainScreen];
    
    FBScreenBounds = [mainScreen bounds];
    FBScreenScale = [mainScreen scale];
    
    UIColorClear = [UIColor clearColor];
    UIColorWhite = [UIColor whiteColor];
    UIColorBlack = [UIColor blackColor];
    UIColorBackground = UIColorWhite;
    UIColorMainText = UIColorBlack;
    UIColorSubText = [UIColor darkGrayColor];
    UIColorSeparator = [UIColor grayColor];
    
    UIFont12 = [UIFont systemFontOfSize:12];
    UIFont13 = [UIFont systemFontOfSize:13];
    UIFont14 = [UIFont systemFontOfSize:14];
    UIFont16 = [UIFont systemFontOfSize:16];;
    UIFont19 = [UIFont systemFontOfSize:19];
    UIFontBold14 = [UIFont boldSystemFontOfSize:14];
    UIFontBold16 = [UIFont boldSystemFontOfSize:16];
    UIFontBold19 = [UIFont boldSystemFontOfSize:19];
    
    UIDevice *currentDevice = [UIDevice currentDevice];
    
    NSIdentifierForVendor = [[[currentDevice identifierForVendor] UUIDString] copy];
    
    NSBundle *mainBundle = [NSBundle mainBundle];
    
    NSAppVersion = [[[mainBundle infoDictionary] objectForKey:CFBundleShortVersionString] copy];
    
    NSString *homeDirectory = NSHomeDirectory();
    
    NSMainFileManager = [[NSFileManager alloc] init];
    
    NSMainDateFormatter = [[NSDateFormatter alloc] init];
    [NSMainDateFormatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    FSDocumentsDirectory = [[homeDirectory stringByAppendingPathComponent:@"Documents"] copy];
}

