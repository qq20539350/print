//
//  FBUtilities.m
//  FeasycomLE
//
//  Created by LIDONG on 14-2-24.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import "FBUtilities.h"
#import <sys/time.h>

NSTimeInterval NSGetCurrentTimestamp(void) {
    struct timeval tv = { 0 };
    
    gettimeofday(&tv, 0);
    return (double)tv.tv_sec + (double)tv.tv_usec / 1000000.f;
}

NSString *NSDescriptionForCurrentTime(void) {
    struct timeval tv = { 0 };
    
    gettimeofday(&tv, 0);
    
    const UInt64 milliseconds = (UInt64)tv.tv_sec * 1000ULL + (UInt64)((tv.tv_usec + 500) / 1000);
    const time_t t = (const time_t)(milliseconds / 1000ULL);
    const struct tm *ptm = localtime(&t);
    
    return [NSString stringWithFormat:@"%04d-%02d-%02d %02d:%02d:%02d.%03d", (1900 + ptm->tm_year), (ptm->tm_mon + 1), ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec, (int)(milliseconds % 1000)];
}

NSString *NSShortDescriptionForCurrentTime(void) {
    struct timeval tv = { 0 };
    
    gettimeofday(&tv, 0);
    
    const UInt64 milliseconds = (UInt64)tv.tv_sec * 1000ULL + (UInt64)((tv.tv_usec + 500) / 1000);
    const time_t t = (const time_t)(milliseconds / 1000ULL);
    const struct tm *ptm = localtime(&t);
    
    return [NSString stringWithFormat:@"%02d-%02d %02d:%02d:%02d.%03d", (ptm->tm_mon + 1), ptm->tm_mday, ptm->tm_hour, ptm->tm_min, ptm->tm_sec, (int)(milliseconds % 1000)];
}

NSMutableArray *NSArrayCreateMutableWithCapacity(const CFIndex capacity) {
    const CFArrayCallBacks callbacks = { 0, NULL, NULL, NULL, NULL };
    
    return (__bridge_transfer NSMutableArray *)CFArrayCreateMutable(kCFAllocatorDefault, capacity, &callbacks);
}

NSString *FSStringCreateWithFileSize(const UInt64 size) {
    NSString *result = nil;
    
    if (size >= SIZE_1_G) {
        result = [[NSString alloc] initWithFormat:@"%.2f GB", size / (double)SIZE_1_G];
    } else if (size >= SIZE_1_M) {
        result = [[NSString alloc] initWithFormat:@"%.2f MB", size / (double)SIZE_1_M];
    } else if (size >= SIZE_1_K) {
        result = [[NSString alloc] initWithFormat:@"%.2f KB", size / (double)SIZE_1_K];
    } else {
        result = [[NSString alloc] initWithFormat:@"%u Bytes", (int)size];
    }
    return result;
}

Boolean NSStringIsNumber(NSString *string) {
    const char *cString = [string cStringUsingEncoding:NSASCIIStringEncoding];
    const size_t len = strlen(cString);
    
    if (0 >= len) {
        return false;
    }
    
    for (size_t i = 0; i < len; ++ i) {
        if (!isnumber(cString[i])) {
            return false;
        }
    }
    return true;
}

Boolean NSStringIsHexNumber(NSString *string) {
    const char *cString = [string cStringUsingEncoding:NSASCIIStringEncoding];
    const size_t len = strlen(cString);
    
    if (0 >= len) {
        return false;
    }
    
    for (size_t i = 0; i < len; ++ i) {
        const char c = cString[i];
        
        if (!ishexnumber(c)) {
            return false;
        }
    }
    return true;
}
