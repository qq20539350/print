//
//  FBUtilities.h
//  FeasycomLE
//
//  Created by LIDONG on 14-2-24.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

//////////////////////////////////////////////////////////////////////////////
// C函数

#ifdef __cplusplus
extern "C" {
#endif
    
    extern NSTimeInterval NSGetCurrentTimestamp(void);
    extern NSString *NSDescriptionForCurrentTime(void);
    extern NSString *NSShortDescriptionForCurrentTime(void);
    extern NSMutableArray *NSArrayCreateMutableWithCapacity(const CFIndex capacity);
    extern NSString *FSStringCreateWithFileSize(const UInt64 size);
    extern Boolean NSStringIsNumber(NSString *string);
    extern Boolean NSStringIsHexNumber(NSString *string);
    
#ifdef __cplusplus
}
#endif


#define SIZE_1_K    1024
#define SIZE_16_K   (SIZE_1_K * 16)
#define SIZE_64_K   (SIZE_1_K * 64)
#define SIZE_128_K  (SIZE_1_K * 128)
#define SIZE_160_K  (SIZE_1_K * 160)
#define SIZE_256_K  (SIZE_1_K * 256)
#define SIZE_512_K  (SIZE_1_K * 512)
#define SIZE_640_K  (SIZE_1_K * 640)
#define SIZE_768_K  (SIZE_1_K * 768)
#define SIZE_1_M    (SIZE_1_K * 1024)
#define SIZE_2_M    (SIZE_1_M * 2)
#define SIZE_3_M    (SIZE_1_M * 3)
#define SIZE_8_M    (SIZE_1_M * 8)
#define SIZE_16_M   (SIZE_1_M * 16)
#define SIZE_1_G    (SIZE_1_M * 1024)


#define RND(x) (int)((x) + 0.5)

#define RX(r) r.origin.x
#define RY(r) r.origin.y
#define RW(r) r.size.width
#define RH(r) r.size.height
#define PT(x, y) (CGPoint){ (x), (y) }
#define SZ(w, h) (CGSize){ (w), (h) }
#define RECT(x, y, w, h) (CGRect){ (x), (y), (w), (h) }
#define EDGE(t, l, b, r) (UIEdgeInsets){ (t), (l), (b), (r) }


#define RGBA(r, g, b, a) [[UIColor alloc] initWithRed:((CGFloat)(r) / 255.f) green:((CGFloat)(g) / 255.f) blue:((CGFloat)(b) / 255.f) alpha:((CGFloat)(a) / 255.f)]
#define RGB(r, g, b) RGBA(r, g, b, 255.f)


//////////////////////////////////////////////////////////////////////////////
// 多语言
#define LS(key) NSLocalizedString(key, nil)


//////////////////////////////////////////////////////////////////////////////
// 其他
#define STOP_TIMER(timer) do { [timer invalidate]; timer = nil; } while(0)


//////////////////////////////////////////////////////////////////////////////
// UI
#define IMG(name) [UIImage imageNamed:name]

#define UI(cls, frame) [[cls alloc] initWithFrame:frame]
#define UI0(cls) UI(cls, CGRectZero)
#define VIEW(frame) [[UIView alloc] initWithFrame:frame]
#define VIEW0() VIEW(CGRectZero)

#define ALERT(title, messageText) do { \
UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:messageText delegate:nil cancelButtonTitle:LS(@"CLOSE") otherButtonTitles:nil]; \
[alert show]; } while (0)
