//
//  FBSettings.h
//  FeasycomLE
//
//  Created by LIDONG on 14-2-24.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import <Foundation/Foundation.h>


#define kScreenWidth            FBScreenBounds.size.width
#define kScreenHeight           FBScreenBounds.size.height
#define kDefaultStatusBarHeight 20
#define kDefaultKeyboardHeight  216
#define kNavBarHeight           44
#define kTabBarHeight           49
#define kFullViewWidth          kScreenWidth
#define kFullViewHeight         (kScreenHeight - kNavBarHeight - kDefaultStatusBarHeight)
#define kMainViewHeight         (kFullViewHeight - kTabBarHeight)

#define UIViewAutoresizingFlexibleHorizontalMargin (UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin)
#define UIViewAutoresizingFlexibleVerticalMargin (UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin)
#define UIViewAutoresizingFlexibleAllMargin (UIViewAutoresizingFlexibleHorizontalMargin | UIViewAutoresizingFlexibleVerticalMargin)
#define UIViewAutoresizingFlexibleSize (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight)


#define kTimeoutInterval 5

extern NSString * const NSStringEmpty;
extern NSString * const FBPeripheralItemDidFinishUpdateNotification;
extern NSString * const FBPeripheralItemDidFailUpdateNotification;

extern CGRect FBScreenBounds;
extern CGFloat FBScreenScale;
extern NSString * FSDocumentsDirectory;
extern NSFileManager *NSMainFileManager;
extern NSDateFormatter *NSMainDateFormatter;
extern NSString *NSIdentifierForVendor;
extern NSString *NSAppVersion;

extern UIViewAnimationCurve NSKeyboardAnimationCurve;
extern NSTimeInterval NSKeyboardAnimationDuration;

extern UIColor *UIColorClear;
extern UIColor *UIColorWhite;
extern UIColor *UIColorBlack;
extern UIColor *UIColorBackground;
extern UIColor *UIColorMainText;
extern UIColor *UIColorSubText;
extern UIColor *UIColorSeparator;

extern UIFont *UIFont12;
extern UIFont *UIFont13;
extern UIFont *UIFont14;
extern UIFont *UIFont16;
extern UIFont *UIFont19;
extern UIFont *UIFontBold14;
extern UIFont *UIFontBold16;
extern UIFont *UIFontBold19;


typedef enum __FBSettingMode : char {
    FBSettingModePropertiesDefining,
    FBSettingModeFunctionTesting,
    FBSettingModeProductionAuthorizing,
    FBSettingModeDFUUpgrading
} FBSettingMode;

