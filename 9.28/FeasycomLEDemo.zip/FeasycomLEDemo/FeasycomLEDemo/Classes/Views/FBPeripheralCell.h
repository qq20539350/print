//
//  FBPeripheralCell.h
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FBPeripheralItem;

@interface FBPeripheralCell : UITableViewCell {
    UILabel *mTitleLabel;
    UILabel *mRSSILabel;
    UILabel *mUUIDLabel;
    UILabel *mServiceUUIDsLabel;
}

@property (nonatomic, strong, readonly) UILabel *titleLabel;
@property (nonatomic, strong, readonly) UILabel *RSSILabel;
@property (nonatomic, strong, readonly) UILabel *UUIDLabel;
@property (nonatomic, strong, readonly) UILabel *serviceUUIDsLabel;

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier;
- (void)setPeripheralItem:(FBPeripheralItem *)peripheralItem;

@end
