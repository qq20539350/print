//
//  FBTextInputGroupCell.m
//  FeasycomLE
//
//  Created by LIDONG on 6/13/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBTextInputGroupCell.h"

#define kTitleWidth 80
#define kTextFieldX (kTitleWidth + 5)

@interface FBTextInputGroupCell () {
    NSMutableArray *mTextFields;
}

@end

@implementation FBTextInputGroupCell

@synthesize titleLabel = mTitleLabel;
@synthesize settingSwitch = mSettingSwitch;
@synthesize textFields = mTextFields;

- (id)initWithFrame:(CGRect)frame numberOfTextFieds:(NSUInteger)numberOfTextFields {
    if (self = [super initWithFrame:frame]) {
        const CGFloat halfHeight = frame.size.height / 2.f;
        
        mTitleLabel = [[UILabel alloc] initWithFrame:RECT(10, 12, kTitleWidth, 20)];
        [mTitleLabel setTextAlignment:NSTextAlignmentCenter];
        [mTitleLabel setTextColor:UIColorMainText];
        [mTitleLabel setFont:UIFont14];
        [self addSubview:mTitleLabel];
        
        mSettingSwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
        [mSettingSwitch sizeToFit];
        
        CGRect switchFrame = [mSettingSwitch frame];
        
        switchFrame.origin.x = kScreenWidth - switchFrame.size.width - 10;
        switchFrame.origin.y = (44.f - switchFrame.size.height) / 2.f;
        
        [mSettingSwitch setFrame:switchFrame];
        
        [self addSubview:mSettingSwitch];
        
        const CGFloat textFieldWidth = (kScreenWidth - ((numberOfTextFields - 1.f) * 5.f + 20.f)) / (CGFloat)numberOfTextFields;
        
        mTextFields = [[NSMutableArray alloc] initWithCapacity:numberOfTextFields];
        
        for (NSUInteger i = 0; i < numberOfTextFields; ++ i) {
            UITextField *textField = [[UITextField alloc] initWithFrame:RECT(10 + (textFieldWidth + 5) * i, halfHeight + 6, textFieldWidth, 31)];
            
            [textField setBackgroundColor:UIColorClear];
            [textField setTextColor:UIColorMainText];
            [textField setTextAlignment:NSTextAlignmentCenter];
            [textField setBorderStyle:UITextBorderStyleLine];
            [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
            [textField setFont:UIFont16];
            [textField setClearButtonMode:UITextFieldViewModeNever];
            [textField setKeyboardAppearance:UIKeyboardAppearanceDefault];
            [textField setKeyboardType:UIKeyboardTypeASCIICapable];
            [textField setReturnKeyType:UIReturnKeyNext];
            [textField setAutocapitalizationType:UITextAutocapitalizationTypeNone];
            [textField setAutocorrectionType:UITextAutocorrectionTypeNo];
            
            [self addSubview:textField];
            [mTextFields addObject:textField];
        }
    }
    return self;
}

@end
