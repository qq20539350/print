//
//  FBReportView.h
//  FeasycomLE
//
//  Created by LIDONG on 6/22/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FBReportView : UIView

- (void)appendDescription:(NSString *)description;
- (void)appendDescription:(NSString *)description font:(UIFont *)font textColor:(UIColor *)textColor;
- (void)clear;

@end
