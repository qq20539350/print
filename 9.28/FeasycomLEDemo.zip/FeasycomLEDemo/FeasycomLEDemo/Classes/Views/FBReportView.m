//
//  FBReportView.m
//  FeasycomLE
//
//  Created by LIDONG on 6/22/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBReportView.h"

@interface FBReportView () {
    UITextView *mTextView;
}

@end

@implementation FBReportView

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setBackgroundColor:[UIColor colorWithWhite:0.9 alpha:1]];
        [self setAutoresizesSubviews:YES];
        
        frame.origin = CGPointZero;
        
        mTextView = [[UITextView alloc] initWithFrame:frame];
        [mTextView setAutoresizingMask:UIViewAutoresizingFlexibleSize];
        [mTextView setBackgroundColor:UIColorClear];
        [mTextView setTextColor:UIColorSubText];
        [mTextView setFont:UIFont14];
        [mTextView setEditable:NO];
        [mTextView setKeyboardAppearance:UIKeyboardAppearanceDefault];
        [mTextView setKeyboardType:UIKeyboardTypeDefault];
        [mTextView setAutocapitalizationType:UITextAutocapitalizationTypeNone];
        [mTextView setAutocorrectionType:UITextAutocorrectionTypeNo];
        [mTextView setReturnKeyType:UIReturnKeyDefault];
        [self addSubview:mTextView];
    }
    return self;
}

- (void)appendDescription:(NSString *)description font:(UIFont *)font textColor:(UIColor *)textColor {
    NSAttributedString *oldAttributedText = [mTextView attributedText];
    NSMutableAttributedString *newAttributedText = [[NSMutableAttributedString alloc] init];
    
    if (oldAttributedText) {
        [newAttributedText appendAttributedString:oldAttributedText];
    }
    
    NSAttributedString *attributedDescription = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"[%@] %@\n", NSShortDescriptionForCurrentTime(), description] attributes:@{ NSForegroundColorAttributeName : textColor, NSFontAttributeName : font }];
    
    [newAttributedText appendAttributedString:attributedDescription];
    
    DLog(@"self: %@", self);
    DLog(@"mTextView: %@", mTextView);
    
    [mTextView setAttributedText:newAttributedText];
    [mTextView scrollRectToVisible:RECT(0, mTextView.contentSize.height - 1, 1, 1) animated:YES];
}

- (void)appendDescription:(NSString *)description {
    [self appendDescription:description font:UIFont14 textColor:UIColorSubText];
}

- (void)clear {
    [mTextView setText:@""];
}

@end
