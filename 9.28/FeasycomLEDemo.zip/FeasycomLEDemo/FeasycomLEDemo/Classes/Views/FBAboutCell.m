//
//  FBAboutCell.m
//  FeasycomLE
//
//  Created by LIDONG on 4/24/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBAboutCell.h"

@implementation FBAboutCell

#define kTitleWidth (kScreenWidth / 4.f)

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.textLabel setFrame:(CGRect){0, 12, kTitleWidth, 20}];
    [self.detailTextLabel setFrame:(CGRect){kTitleWidth, 12, kScreenWidth - kTitleWidth, 20}];
}

@end
