//
//  FBTextInputCell.m
//  FeasycomLE
//
//  Created by LIDONG on 4/25/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBTextInputCell.h"

#define kTitleWidth 80
#define kTextFieldX (kTitleWidth + 5)

@implementation FBTextInputCell

@synthesize titleLabel = mTitleLabel;
@synthesize textField = mTextField;
@synthesize settingSwitch = mSettingSwitch;

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        mTitleLabel = [[UILabel alloc] initWithFrame:RECT(0, 12, kTitleWidth, 20)];
        [mTitleLabel setTextAlignment:NSTextAlignmentRight];
        [mTitleLabel setTextColor:UIColorMainText];
        [mTitleLabel setFont:UIFont14];
        [self addSubview:mTitleLabel];
        
        mSettingSwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
        [mSettingSwitch sizeToFit];
        
        CGRect switchFrame = [mSettingSwitch frame];
        
        switchFrame.origin.x = kScreenWidth - switchFrame.size.width - 10;
        switchFrame.origin.y = (44.f - switchFrame.size.height) / 2.f;
        
        [mSettingSwitch setFrame:switchFrame];
        
        [self addSubview:mSettingSwitch];
        
        mTextField = [[UITextField alloc] initWithFrame:RECT(kTextFieldX, 6, switchFrame.origin.x - kTextFieldX - 10, 31)];
        [mTextField setBackgroundColor:UIColorClear];
        [mTextField setTextColor:UIColorMainText];
        [mTextField setBorderStyle:UITextBorderStyleLine];
        [mTextField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
        [mTextField setFont:UIFont16];
        [mTextField setClearButtonMode:UITextFieldViewModeWhileEditing];
        [mTextField setKeyboardAppearance:UIKeyboardAppearanceDefault];
        [mTextField setKeyboardType:UIKeyboardTypeASCIICapable];
        [mTextField setReturnKeyType:UIReturnKeyNext];
        [mTextField setAutocapitalizationType:UITextAutocapitalizationTypeNone];
        [mTextField setAutocorrectionType:UITextAutocorrectionTypeNo];
        [self addSubview:mTextField];
    }
    return self;
}

@end
