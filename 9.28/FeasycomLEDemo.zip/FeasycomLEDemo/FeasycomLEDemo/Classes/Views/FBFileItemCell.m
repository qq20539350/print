//
//  FBFileItemCell.m
//  FeasycomLE
//
//  Created by LIDONG on 3/23/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBFileItemCell.h"
#import "FBFileItem.h"

@implementation FBFileItemCell

@synthesize fileItem = _fileItem;

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier]) {
        UIColor *clearColor = UIColorClear;
        UIColor *whiteColor = UIColorWhite;
        UIColor *darkGrayColor = [UIColor darkGrayColor];
        
        [self setClipsToBounds:YES];
        [self setBackgroundColor:whiteColor];
        [self setSelectionStyle:UITableViewCellSelectionStyleGray];
        [self setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
        
        UIView *contentView = [self contentView];
        UILabel *textLabel = [self textLabel];
        UILabel *detailLabel = [self detailTextLabel];
        
        [contentView setClipsToBounds:YES];
        [contentView setBackgroundColor:whiteColor];
        [textLabel setBackgroundColor:clearColor];
        [textLabel setTextColor:UIColorMainText];
        [textLabel setHighlightedTextColor:whiteColor];
        [textLabel setFont:UIFontBold16];
        [textLabel setAdjustsFontSizeToFitWidth:YES];
        [textLabel setMinimumScaleFactor:0.75];
        [textLabel setNumberOfLines:2];
        [detailLabel setBackgroundColor:clearColor];
        [detailLabel setTextColor:darkGrayColor];
        [detailLabel setHighlightedTextColor:whiteColor];
        [detailLabel setFont:[UIFont systemFontOfSize:12]];
        
        _statisticLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [_statisticLabel setBackgroundColor:clearColor];
        [_statisticLabel setTextColor:darkGrayColor];
        [_statisticLabel setHighlightedTextColor:whiteColor];
        [_statisticLabel setFont:[UIFont systemFontOfSize:12]];
        [_statisticLabel setTextAlignment:NSTextAlignmentRight];
        [contentView addSubview:_statisticLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    UILabel *detailTextLabel = [self detailTextLabel];
    CGRect detailFrame = [detailTextLabel frame];
    const CGFloat contentWidth = self.contentView.bounds.size.width;
    const CGFloat restCap = contentWidth - detailFrame.origin.x - 10;
    
    detailFrame.size.width = restCap * 2.f / 3.f;
    [detailTextLabel setFrame:detailFrame];
    
    const CGFloat statisticWidth = restCap / 3.f;
    CGRect statisticFrame = { contentWidth - statisticWidth - 10.f, detailFrame.origin.y, statisticWidth, detailFrame.size.height };
    
    [_statisticLabel setFrame:statisticFrame];
}

- (void)setFileItem:(FBFileItem *)newFileItem {
    _fileItem = newFileItem;
    [_fileItem loadAttributesIfNeeded];
    
    [[self textLabel] setText:[_fileItem displayName]];
    [[self detailTextLabel] setText:[_fileItem creationTime]];
    [_statisticLabel setText:[_fileItem statistic]];
    [self setAccessoryType:([_fileItem isSelected] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone)];
}

@end
