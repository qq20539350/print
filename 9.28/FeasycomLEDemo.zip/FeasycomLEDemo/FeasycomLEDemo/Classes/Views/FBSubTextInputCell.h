//
//  FBSubTextInputCell.h
//  FeasycomLE
//
//  Created by LIDONG on 5/15/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FBSubTextInputCell : UIView

@property (nonatomic, strong, readonly) UILabel *titleLabel;
@property (nonatomic, strong, readonly) UITextField *textField;

@end
