//
//  FBUpdatingSettingsCell.h
//  FeasycomLE
//
//  Created by LIDONG on 5/4/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBPeripheralCell.h"

@class FBSession;

@interface FBUpdatingSettingsCell : FBPeripheralCell

@property (nonatomic, strong, readonly) UIButton *updateButton;

@end
