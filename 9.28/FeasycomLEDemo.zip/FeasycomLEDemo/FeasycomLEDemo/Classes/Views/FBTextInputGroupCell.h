//
//  FBTextInputGroupCell.h
//  FeasycomLE
//
//  Created by LIDONG on 6/13/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FBTextInputGroupCell : UIView

@property (nonatomic, strong, readonly) UILabel *titleLabel;
@property (nonatomic, strong, readonly) UISwitch *settingSwitch;
@property (nonatomic, strong, readonly) NSArray *textFields;

- (id)initWithFrame:(CGRect)frame numberOfTextFieds:(NSUInteger)numberOfTextFields;

@end
