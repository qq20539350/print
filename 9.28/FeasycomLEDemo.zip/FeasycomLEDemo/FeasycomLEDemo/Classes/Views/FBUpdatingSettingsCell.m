//
//  FBUpdatingSettingsCell.m
//  FeasycomLE
//
//  Created by LIDONG on 5/4/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBUpdatingSettingsCell.h"

@interface FBUpdatingSettingsCell () {
    FBSession *mSession;
}

@end

@implementation FBUpdatingSettingsCell

@synthesize updateButton = mUpdateButton;

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        [self setAccessoryType:UITableViewCellAccessoryNone];
        
        mUpdateButton = [[UIButton alloc] initWithFrame:RECT(kScreenWidth - 90, 29, 80, 32)];
        [mUpdateButton setBackgroundImage:[IMG(@"button.png") resizableImageWithCapInsets:UIEdgeInsetsMake(16, 16, 16, 16)] forState:UIControlStateNormal];
        [mUpdateButton.titleLabel setFont:UIFont14];
        [mUpdateButton.titleLabel setAdjustsFontSizeToFitWidth:YES];
        [mUpdateButton.titleLabel setMinimumScaleFactor:0.75];
        [mUpdateButton setTitleColor:UIColorMainText forState:UIControlStateNormal];
        [mUpdateButton setTitle:LS(@"CHOOSE_FILE") forState:UIControlStateNormal];
        [[self contentView] addSubview:mUpdateButton];
        
        [mUUIDLabel setFrame:RECT(10, 35, kScreenWidth - 100, 16)];
        [mServiceUUIDsLabel setFrame:RECT(10, 55, kScreenWidth - 100, 16)];
    }
    return self;
}

@end
