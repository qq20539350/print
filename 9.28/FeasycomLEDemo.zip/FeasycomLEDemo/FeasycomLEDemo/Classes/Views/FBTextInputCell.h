//
//  FBTextInputCell.h
//  FeasycomLE
//
//  Created by LIDONG on 4/25/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FBTextInputCell : UIView

@property (nonatomic, strong, readonly) UILabel *titleLabel;
@property (nonatomic, strong, readonly) UITextField *textField;
@property (nonatomic, strong, readonly) UISwitch *settingSwitch;

@end
