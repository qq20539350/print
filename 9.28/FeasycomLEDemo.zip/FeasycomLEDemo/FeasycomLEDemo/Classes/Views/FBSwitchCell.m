//
//  FBSwitchCell.m
//  FeasycomLE
//
//  Created by LIDONG on 4/26/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBSwitchCell.h"

#define kTitleWidth 80
#define kTextFieldX (kTitleWidth + 5)

@interface FBSwitchCell () {
    UILabel *mTitleLabel;
    UILabel *mDetailLabel;
    UISwitch *mSettingSwitch;
}

@end


@implementation FBSwitchCell

@synthesize titleLabel = mTitleLabel;
@synthesize detailLabel = mDetailLabel;
@synthesize settingSwitch = mSettingSwitch;

- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        mTitleLabel = [[UILabel alloc] initWithFrame:RECT(0, 12, kTitleWidth, 20)];
        [mTitleLabel setTextAlignment:NSTextAlignmentRight];
        [mTitleLabel setTextColor:UIColorMainText];
        [mTitleLabel setFont:UIFont14];
        [self addSubview:mTitleLabel];
        
        mSettingSwitch = [[UISwitch alloc] initWithFrame:CGRectZero];
        [mSettingSwitch sizeToFit];
        
        CGRect switchFrame = [mSettingSwitch frame];
        
        switchFrame.origin.x = kScreenWidth - switchFrame.size.width - 10;
        switchFrame.origin.y = (44.f - switchFrame.size.height) / 2.f;
        
        [mSettingSwitch setFrame:switchFrame];
        
        [self addSubview:mSettingSwitch];
        
        mDetailLabel = [[UILabel alloc] initWithFrame:RECT(kTextFieldX, 2, switchFrame.origin.x - kTextFieldX - 10, 40)];
        [mDetailLabel setTextColor:UIColorSubText];
        [mDetailLabel setFont:UIFont13];
        [mDetailLabel setLineBreakMode:NSLineBreakByCharWrapping];
        [mDetailLabel setNumberOfLines:2];
        [self addSubview:mDetailLabel];
    }
    return self;
}

@end
