//
//  FBPeripheralCell.m
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBPeripheralCell.h"

@implementation FBPeripheralCell

@synthesize titleLabel = mTitleLabel;
@synthesize RSSILabel = mRSSILabel;
@synthesize UUIDLabel = mUUIDLabel;
@synthesize serviceUUIDsLabel = mServiceUUIDsLabel;

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier]) {
        [self setClipsToBounds:YES];
        [self setBackgroundColor:UIColorBackground];
        [self setSelectionStyle:UITableViewCellSelectionStyleGray];
        [self setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
        
        UIView *contentView = [self contentView];
        
        [contentView setClipsToBounds:YES];
        [contentView setBackgroundColor:UIColorBackground];
        [contentView setAutoresizesSubviews:NO];
        
        mTitleLabel = [[UILabel alloc] initWithFrame:RECT(10, 10, kScreenWidth - 115, 20)];
        [mTitleLabel setBackgroundColor:UIColorClear];
        [mTitleLabel setTextColor:UIColorMainText];
        [mTitleLabel setFont:UIFontBold16];
        [contentView addSubview:mTitleLabel];
        
        mRSSILabel = [[UILabel alloc] initWithFrame:RECT(kScreenWidth - 100, 11, 80, 16)];
        [mRSSILabel setBackgroundColor:UIColorClear];
        [mRSSILabel setTextColor:UIColorMainText];
        [mRSSILabel setFont:UIFont14];
        [contentView addSubview:mRSSILabel];
        
        mUUIDLabel = [[UILabel alloc] initWithFrame:RECT(10, 35, kScreenWidth - 20, 16)];
        [mUUIDLabel setBackgroundColor:UIColorClear];
        [mUUIDLabel setTextColor:UIColorMainText];
        [mUUIDLabel setFont:UIFont13];
        [mUUIDLabel setAdjustsFontSizeToFitWidth:YES];
        [mUUIDLabel setMinimumScaleFactor:0.75];
        [contentView addSubview:mUUIDLabel];
        
        mServiceUUIDsLabel = [[UILabel alloc] initWithFrame:RECT(10, 55, kScreenWidth - 20, 32)];
        [mServiceUUIDsLabel setBackgroundColor:UIColorClear];
        [mServiceUUIDsLabel setTextColor:UIColorMainText];
        [mServiceUUIDsLabel setFont:UIFont12];
        [mServiceUUIDsLabel setLineBreakMode:NSLineBreakByCharWrapping];
        [mServiceUUIDsLabel setNumberOfLines:2];
        [contentView addSubview:mServiceUUIDsLabel];
    }
    return self;
}

- (void)setPeripheralItem:(FBPeripheralItem *)peripheralItem {
    [mTitleLabel setText:[peripheralItem name]];
    [mRSSILabel setText:[NSString stringWithFormat:@"RSSI: (%d)", (int)[peripheralItem RSSI]]];
    [mUUIDLabel setText:[peripheralItem UUID]];
    [mServiceUUIDsLabel setText:[[NSString alloc] initWithFormat:@"UUIDs: %@", [[peripheralItem serviceUUIDs] componentsJoinedByString:@", "]]];
    
    [mTitleLabel sizeToFit];
    [mRSSILabel sizeToFit];
    
    CGRect titleFrame = [mTitleLabel frame];
    CGRect RSSIFrame = [mRSSILabel frame];
    
    if (titleFrame.size.width > kScreenWidth - 100) {
        titleFrame.size.width = kScreenWidth - 100;
    }
    titleFrame.size.height = 20;
    
    RSSIFrame.origin.x = titleFrame.origin.x + titleFrame.size.width + 5;
    RSSIFrame.size.height = 16;
    
    [mTitleLabel setFrame:titleFrame];
    [mRSSILabel setFrame:RSSIFrame];
}

@end
