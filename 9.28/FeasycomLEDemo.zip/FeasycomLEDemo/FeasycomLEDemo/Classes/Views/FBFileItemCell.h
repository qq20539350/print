//
//  FBFileItemCell.h
//  FeasycomLE
//
//  Created by LIDONG on 3/23/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FBFileItem;

@interface FBFileItemCell : UITableViewCell {
    UILabel *_statisticLabel;
    FBFileItem *_fileItem;
}

@property (nonatomic, strong) FBFileItem *fileItem;

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier;

@end
