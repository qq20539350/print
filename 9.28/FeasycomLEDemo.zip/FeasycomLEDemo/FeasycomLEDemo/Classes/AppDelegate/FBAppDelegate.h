//
//  FBAppDelegate.h
//  FeasycomLE
//
//  Created by LIDONG on 14-2-23.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FBAppDelegate : UIResponder <UIApplicationDelegate> {
    UIWindow *mWindow;
}

@property (strong, nonatomic) UIWindow *window;

@end
