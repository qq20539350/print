//
//  FBCommunicationViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 11/2/14.
//  Copyright (c) 2014 LIDONG. All rights reserved.
//

#import "FBViewController.h"

@class FBPeripheralItem;

@interface FBCommunicationViewController : FBViewController

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem;

@end
