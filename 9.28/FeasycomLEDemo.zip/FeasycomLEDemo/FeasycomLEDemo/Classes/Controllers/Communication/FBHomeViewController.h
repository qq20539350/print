//
//  FBHomeViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBBluetoothBrowserViewController.h"

@interface FBHomeViewController : FBBluetoothBrowserViewController

@end
