//
//  FBCommunicationViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 11/2/14.
//  Copyright (c) 2014 LIDONG. All rights reserved.
//

#import "FBCommunicationViewController.h"
#import "FBFileBrowserViewController.h"
#import "DOKeyboard.h"
#import "NSString+Hexadecimal.h"
#import <CoreBluetooth/CoreBluetooth.h>

const UIViewAnimationCurve GTKeyboardAnimationCurve = 7;
const NSTimeInterval GTKeyboardAnimationDuration = 0.25;

@interface FBCommunicationViewController () <UITextFieldDelegate, UITextViewDelegate, FBSessionDelegate, FBFileBrowserViewControllerDelegate> {
    UIView *mContentView;
    UIButton *mUpdateButton;
    UILabel *mInStatisticsLabel;
    UITextView *mInTextView;
    UILabel *mOutStatisticsLabel;
    UITextView *mOutTextView;
    UITextField *mTimeTextField;
    UISwitch *mReadHexadecimalSwitch;
    UISwitch *mTimeSwitch;
    UISwitch *mWriteHexadecimalSwitch;
    UISwitch *mResponseSwitch;
    UIButton *mSendButton;
    DOKeyboard *mKeyboard;
    __weak id mActiveView;
    FBSession *mSession;
    NSTimer *mTimer;
    NSMutableData *mReceivedData;
    NSData *mSendingData;
    int mReceivedBytes;
    int mSentBytes;
    int mReceivedCount;
    int mSentCount;
    CGFloat mKeyboardHeight;
    BOOL mSessionAuthorized;
    BOOL mHexadecimal;
}

- (void)updateStatistics;

@end

@implementation NSData (NSString)

- (NSString *)hexadecimalString {
    const UInt8 *bytes = [self bytes];
    const int length = (const int)[self length];
    int counter = 0;
    NSMutableString *result = [[NSMutableString alloc] initWithCapacity:(length * 2 + length / 4 + 1)];
    
    for (int i = 0; i < length; ++ i) {
        const int value = bytes[i];
        
        [result appendFormat:@"%02X", value];
        if (4 == (++ counter)) {
            [result appendString:@" "];
            counter = 0;
        }
    }
    return result;
}

@end

@implementation FBCommunicationViewController

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem {
    if (self = [super init]) {
        mSession = [[FBSession alloc] initWithPeripheralItem:peripheralItem];
        [mSession setDelegate:self];
        
        NSString *name = [[mSession peripheralItem] name];
        
        if (nil == name) {
            name = LS(@"UNNAMED");
        }
        
        [self setTitle:name];
        [self setHidesBottomBarWhenPushed:YES];
        
        mKeyboardHeight = kDefaultKeyboardHeight;
        
        mReceivedData = [[NSMutableData alloc] initWithCapacity:4096];
        
        UIBarButtonItem *barButtonItem = [[UIBarButtonItem alloc] initWithTitle:LS(@"CLEAR") style:UIBarButtonItemStyleBordered target:self action:@selector(onClear)];
        
        [[self navigationItem] setRightBarButtonItem:barButtonItem];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *view = [self view];
    
    DLog(@"%@", view);
    
    if (nil == mContentView) {
        UIColor *clearColor = UIColorClear;
        UIColor *textColor = UIColorMainText;
        UIFont *font = UIFont16;
        const CGFloat contentHeight = kScreenHeight - kDefaultStatusBarHeight - kNavBarHeight;
        const CGFloat contentWidth = kScreenWidth - 10;
        
        mContentView = [[UIView alloc] initWithFrame:(CGRect){ 0, 0, kScreenWidth, contentHeight }];
        [mContentView setBackgroundColor:UIColorWhite];
        [mContentView setAutoresizesSubviews:NO];
        
        UILabel *label = [[UILabel alloc] initWithFrame:RECT(5, 10, 40, 20)];
        
        [label setTextAlignment:NSTextAlignmentLeft];
        [label setBackgroundColor:clearColor];
        [label setTextColor:textColor];
        [label setFont:font];
        [label setAdjustsFontSizeToFitWidth:YES];
        [label setMinimumScaleFactor:0.75];
        [label setText:@"Hex"];
        
        [mContentView addSubview:label];
        
        mReadHexadecimalSwitch = [[UISwitch alloc] initWithFrame:RECT(45, 5, 53, 31)];
        [mReadHexadecimalSwitch addTarget:self action:@selector(onValueChanged:) forControlEvents:UIControlEventValueChanged];
        [mContentView addSubview:mReadHexadecimalSwitch];
        
        mInStatisticsLabel = [[UILabel alloc] initWithFrame:RECT(120, 10, (contentWidth - 125), 20)];
        [mInStatisticsLabel setTextAlignment:NSTextAlignmentRight];
        [mInStatisticsLabel setBackgroundColor:clearColor];
        [mInStatisticsLabel setTextColor:textColor];
        [mInStatisticsLabel setFont:font];
        [mContentView addSubview:mInStatisticsLabel];
        
        const CGFloat outOffsetY = contentHeight - 190;
        const CGFloat inTextHeight = outOffsetY - 55;
        
        mInTextView = [[UITextView alloc] initWithFrame:RECT(5, 40, contentWidth, inTextHeight)];
        [mInTextView setBackgroundColor:[UIColor lightGrayColor]];
        [mInTextView setTextColor:textColor];
        [mInTextView setFont:font];
        [mInTextView setEditable:NO];
        [mInTextView setKeyboardAppearance:UIKeyboardAppearanceDefault];
        [mInTextView setKeyboardType:UIKeyboardTypeDefault];
        [mInTextView setAutocapitalizationType:UITextAutocapitalizationTypeNone];
        [mInTextView setAutocorrectionType:UITextAutocorrectionTypeNo];
        [mInTextView setReturnKeyType:UIReturnKeyNext];
        [mContentView addSubview:mInTextView];
        
        mOutTextView = [[UITextView alloc] initWithFrame:RECT(5, outOffsetY, contentWidth, 31)];
        [mOutTextView setDelegate:self];
        [mOutTextView setBackgroundColor:[UIColor lightGrayColor]];
        [mOutTextView setTextColor:textColor];
        [mOutTextView setFont:font];
        [mOutTextView setEditable:YES];
        [mOutTextView setKeyboardAppearance:UIKeyboardAppearanceDefault];
        [mOutTextView setKeyboardType:UIKeyboardTypeDefault];
        [mOutTextView setAutocapitalizationType:UITextAutocapitalizationTypeNone];
        [mOutTextView setAutocorrectionType:UITextAutocorrectionTypeNo];
        [mOutTextView setReturnKeyType:UIReturnKeyDefault];
        [mContentView addSubview:mOutTextView];
        
        mOutStatisticsLabel = [[UILabel alloc] initWithFrame:RECT(5, outOffsetY + 41, contentWidth - 10, 20)];
        [mOutStatisticsLabel setTextAlignment:NSTextAlignmentRight];
        [mOutStatisticsLabel setBackgroundColor:clearColor];
        [mOutStatisticsLabel setTextColor:textColor];
        [mOutStatisticsLabel setFont:font];
        [mContentView addSubview:mOutStatisticsLabel];
        
        const CGFloat offsetY = outOffsetY + 72;
        
        label = [[UILabel alloc] initWithFrame:(CGRect){ 5, offsetY, 70, 31 }];
        
        [label setBackgroundColor:clearColor];
        [label setTextColor:textColor];
        [label setFont:font];
        [label setAdjustsFontSizeToFitWidth:YES];
        [label setMinimumScaleFactor:0.75];
        [label setText:LS(@"TIMING_SEND")];
        [mContentView addSubview:label];
        
        mTimeTextField = [[UITextField alloc] initWithFrame:RECT(75, offsetY, 80, 31)];
        [mTimeTextField setBackgroundColor:[UIColor lightGrayColor]];
        [mTimeTextField setTextColor:textColor];
        [mTimeTextField setTextAlignment:NSTextAlignmentRight];
        [mTimeTextField setDelegate:self];
        [mTimeTextField setBorderStyle:UITextBorderStyleRoundedRect];
        [mTimeTextField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
        [mTimeTextField setFont:font];
        [mTimeTextField setKeyboardAppearance:UIKeyboardAppearanceDefault];
        [mTimeTextField setKeyboardType:UIKeyboardTypeNumberPad];
        [mTimeTextField setAutocapitalizationType:UITextAutocapitalizationTypeNone];
        [mTimeTextField setAutocorrectionType:UITextAutocorrectionTypeNo];
        [mTimeTextField setReturnKeyType:UIReturnKeyDone];
        [mTimeTextField setClearButtonMode:UITextFieldViewModeNever];
        [mTimeTextField setEnabled:[mTimeSwitch isOn]];
        [mContentView addSubview:mTimeTextField];
        
        mTimeSwitch = [[UISwitch alloc] initWithFrame:(CGRect){ 165, offsetY, 53, 31 }];
        [mTimeSwitch addTarget:self action:@selector(onValueChanged:) forControlEvents:UIControlEventValueChanged];
        [mContentView addSubview:mTimeSwitch];
        
        const CGFloat offsetY1 = offsetY + 36;
        
        label = [[UILabel alloc] initWithFrame:RECT(5, offsetY1 + 5, 40, 20)];
        
        [label setTextAlignment:NSTextAlignmentLeft];
        [label setBackgroundColor:clearColor];
        [label setTextColor:textColor];
        [label setFont:font];
        [label setAdjustsFontSizeToFitWidth:YES];
        [label setMinimumScaleFactor:0.75];
        [label setText:@"Hex"];
        
        [mContentView addSubview:label];
        
        mWriteHexadecimalSwitch = [[UISwitch alloc] initWithFrame:RECT(45, offsetY1, 53, 31)];
        [mWriteHexadecimalSwitch addTarget:self action:@selector(onValueChanged:) forControlEvents:UIControlEventValueChanged];
        [mContentView addSubview:mWriteHexadecimalSwitch];
        
        label = [[UILabel alloc] initWithFrame:RECT(130, offsetY1 + 5, 80, 20)];
        
        [label setTextAlignment:NSTextAlignmentLeft];
        [label setBackgroundColor:clearColor];
        [label setTextColor:textColor];
        [label setFont:font];
        [label setAdjustsFontSizeToFitWidth:YES];
        [label setMinimumScaleFactor:0.75];
        [label setText:@"Response"];
        
        [mContentView addSubview:label];
        
        mResponseSwitch = [[UISwitch alloc] initWithFrame:RECT(210, offsetY1, 53, 31)];
        [mResponseSwitch addTarget:self action:@selector(onValueChanged:) forControlEvents:UIControlEventValueChanged];
        [mContentView addSubview:mResponseSwitch];
        
        UIButton *sendFileButton = [[UIButton alloc] initWithFrame:RECT(10, offsetY1 + 40, 100, 32)];
        [sendFileButton setBackgroundImage:[[UIImage imageNamed:@"button.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(16, 16, 16, 16)] forState:UIControlStateNormal];
        [sendFileButton.titleLabel setFont:UIFontBold16];
        [sendFileButton setTitleColor:textColor forState:UIControlStateNormal];
        [sendFileButton setTitle:LS(@"SEND_FILE") forState:UIControlStateNormal];
        [sendFileButton addTarget:self action:@selector(onSendFile) forControlEvents:UIControlEventTouchUpInside];
        [mContentView addSubview:sendFileButton];
        
        mSendButton = [[UIButton alloc] initWithFrame:RECT(kScreenWidth - 85, offsetY1 + 40, 80, 32)];
        [mSendButton setBackgroundImage:[[UIImage imageNamed:@"button.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(16, 16, 16, 16)] forState:UIControlStateNormal];
        [mSendButton.titleLabel setFont:UIFontBold16];
        [mSendButton setTitleColor:textColor forState:UIControlStateNormal];
        [mSendButton setTitle:LS(@"SEND") forState:UIControlStateNormal];
        [mSendButton addTarget:self action:@selector(startWriting) forControlEvents:UIControlEventTouchUpInside];
        [mContentView addSubview:mSendButton];
        
        [self updateStatistics];
        
        UIView *separatorView = [[UIView alloc] initWithFrame:(CGRect){ 0, contentHeight - 1, kScreenWidth, 1 }];
        
        [separatorView setBackgroundColor:[UIColor colorWithWhite:0.85 alpha:1.f]];
        [mContentView addSubview:separatorView];
    }
    
    [self updateReceivedText];
    
    [view setUserInteractionEnabled:YES];
    [view addSubview:mContentView];
}

- (void)releaseUI {
    mContentView = nil;
    mUpdateButton = nil;
    mInStatisticsLabel = nil;
    mInTextView = nil;
    mOutStatisticsLabel = nil;
    mOutTextView = nil;
    mTimeTextField = nil;
    mTimeSwitch = nil;
    mReadHexadecimalSwitch = nil;
    mWriteHexadecimalSwitch = nil;
    mResponseSwitch = nil;
    mSendButton = nil;
}

- (void)dealloc {
    [mSession setDelegate:nil];
    [mSession close];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if ([[mSession peripheralItem] connect]) {
        [self startWaiting];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self stopWriting];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (textField == mTimeTextField) {
        if ([string length] > 0 && ![string isEqualToString:@"0"] && [string intValue] < 1) {
            return NO;
        }
    }
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    DLog(@"%s", __PRETTY_FUNCTION__);
    UITextField *previousTextField = mActiveView;
    
    mActiveView = textField;
    
    if (nil == previousTextField) {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationCurve:GTKeyboardAnimationCurve];
        [UIView setAnimationDuration:GTKeyboardAnimationDuration];
        [self calculateLayout];
        [UIView commitAnimations];
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    DLog(@"%s", __PRETTY_FUNCTION__);
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    DLog(@"%s", __PRETTY_FUNCTION__);
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    DLog(@"%s", __PRETTY_FUNCTION__);
    if (textField == mActiveView) {
        mActiveView = nil;
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationCurve:GTKeyboardAnimationCurve];
        [UIView setAnimationDuration:GTKeyboardAnimationDuration];
        [self calculateLayout];
        [UIView commitAnimations];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    
    return YES;
}

#pragma mark - UITextViewDelegate

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    id previousTextField = mActiveView;
    
    mActiveView = textView;
    
    if (nil == previousTextField) {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationCurve:GTKeyboardAnimationCurve];
        [UIView setAnimationDuration:GTKeyboardAnimationDuration];
        [self calculateLayout];
        [UIView commitAnimations];
    }
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
    
}

- (void)textViewDidEndEditing:(UITextView *)textView {
    if (textView == mActiveView) {
        mActiveView = nil;
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationCurve:GTKeyboardAnimationCurve];
        [UIView setAnimationDuration:GTKeyboardAnimationDuration];
        [self calculateLayout];
        [UIView commitAnimations];
    }
}

#pragma mrak - FBSessionDelegate

- (void)sessionDidFinishAuthorizing:(FBSession *)session {
    [self stopWaitingWithTitle:LS(@"AUTHORIZATION_SUCCEEDED")];
}

- (void)sessionAuthorizingDidTimeout:(FBSession *)session {
    [self performSelector:@selector(quit) withObject:nil afterDelay:600];
    [self stopWaitingWithTitle:LS(@"AUTHORIZATION_TIMEOUT")];
}

- (void)session:(FBSession *)session authorizationDidFailWithError:(NSError *)error {
    [self performSelector:@selector(quit) withObject:nil afterDelay:600];
    [self stopWaitingWithTitle:LS(@"AUTHORIZATION_FAILED")];
}

- (void)sessionDidOpen:(FBSession *)session {
//    [mSession authorizeWithMode:FBSessionModeCommunication timeoutInterval:kTimeoutInterval];
    [mSession authorizeWithMode:FBSessionModeUnsafe timeoutInterval:kTimeoutInterval];
}

- (void)sessionDidClose:(FBSession *)session error:(NSError *)error {
    if (session == mSession) {
        mSession = nil;
        
        UINavigationController *navigationController = [self navigationController];
        
        if ([navigationController topViewController] == self) {
            [navigationController popViewControllerAnimated:YES];
        }
        [self stopWaiting];
    }
}

- (void)session:(FBSession *)session didReceiveResponse:(FBResponse *)response forRequest:(FBPacket *)request {
    if (session == mSession) {
        
    }
}

- (void)session:(FBSession *)session requestDidTimeout:(FBPacket *)request {
    if (session == mSession) {
    }
}

- (void)session:(FBSession *)session requestDidFail:(FBPacket *)request error:(NSError *)error {
    if (session == mSession) {
        ALERT(LS(@"REQUEST_FAILED"), [error localizedDescription]);
    }
}

- (void)session:(FBSession *)session didFailToWriteWithError:(NSError *)error {
    
}

- (void)session:(FBSession *)session didReceiveData:(NSData *)data {
    const NSUInteger length = [data length];
    
    if (0 < length) {/*
        if (10240 <= ([mReceivedData length] + length)) {
            [mReceivedData setData:data];
        } else {
            [mReceivedData appendData:data];
        }*/
        mReceivedBytes += length;
        mReceivedCount ++;
        
        //[self updateReceivedText];
        [self updateStatistics];
      
    }
}


- (void)fileBrowserViewController:(FBFileBrowserViewController *)viewController didSelectFileAtPath:(NSString *)path {
    mSendingData = [[NSData alloc] initWithContentsOfFile:path];
    
    if ([mSendingData length] > 0) {
        [self finishWriting];
    }
}

#pragma mark - Actions

- (void)updateStatistics {
    [mInStatisticsLabel setText:[NSString stringWithFormat:@"接收：%d/%d", mReceivedBytes, mReceivedCount]];
    [mOutStatisticsLabel setText:[NSString stringWithFormat:@"发送：%d/%d", mSentBytes, mSentCount]];
}

- (void)updateControlStates {
    const BOOL enabled = (nil == mTimer);
    
    [mOutTextView setEditable:enabled];
    [mTimeSwitch setEnabled:enabled];
    [mTimeTextField setEnabled:(enabled && [mTimeSwitch isOn])];
}

- (void)updateReceivedText {
    NSString *text = nil;
    
    if ([mReadHexadecimalSwitch isOn]) {
        text = [mReceivedData hexadecimalString];
    } else {
        text = [[NSString alloc] initWithData:mReceivedData encoding:NSUTF8StringEncoding];
    }
    [mInTextView setText:text];
    [mInTextView scrollRangeToVisible:NSMakeRange([text length] - 1, 1)];
}

- (void)onValueChanged:(UISwitch *)sender {
    if (sender == mTimeSwitch) {
        const BOOL isOn = [sender isOn];
        
        if (!isOn) {
            [self stopWriting];
        }
        [mTimeTextField setEnabled:isOn];
    } else if (sender == mReadHexadecimalSwitch) {
        [self updateReceivedText];
    } else if (sender == mWriteHexadecimalSwitch) {
        if ([mWriteHexadecimalSwitch isOn]) {
            NSData *data = [[mOutTextView text] dataUsingEncoding:NSUTF8StringEncoding];
            
            [mOutTextView setText:[data hexadecimalString]];
            
            if (nil == mKeyboard) {
                mKeyboard = [DOKeyboard keyboardWithType:DOKeyboardTypeHex];
            }
            [mKeyboard setInput:mOutTextView];
        } else {
            [mOutTextView setText:@""];
            [mOutTextView setInputView:nil];
        }
        [mOutTextView resignFirstResponder];
        [mOutTextView becomeFirstResponder];
    }
}

- (void)startWriting {
    if (mTimer) {
        [self stopWriting];
        return;
    }
    NSString *text = [mOutTextView text];
    
    if ([text length] > 0) {
        if ([mWriteHexadecimalSwitch isOn]) {
            mSendingData = [text hexadecimalData];
        } else {
            mSendingData = [text dataUsingEncoding:NSUTF8StringEncoding];
        }
        
        if ([mTimeSwitch isOn]) {
            if (nil == mTimer) {
                [mSendButton setTitle:LS(@"STOP") forState:UIControlStateNormal];
                mTimer = [NSTimer scheduledTimerWithTimeInterval:([[mTimeTextField text] doubleValue] / 1000.f) target:self selector:@selector(finishWriting) userInfo:nil repeats:YES];
            }
        } else {
            [self finishWriting];
        }
        
        [mOutTextView resignFirstResponder];
    }
}

- (void)stopWriting {
    if (mTimer) {
        [mSendButton setTitle:LS(@"SEND") forState:UIControlStateNormal];
        STOP_TIMER(mTimer);
    }
}

- (void)onSendFile {
    FBFileBrowserViewController *viewController = [[FBFileBrowserViewController alloc] init];
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewController];
    
    [viewController setDelegate:self];
    [[self navigationController] presentViewController:navController animated:YES completion:NULL];
}

- (void)finishWriting {
    if ([mSession sendData:mSendingData withoutResponse:!mResponseSwitch.isOn]) {
        mSentBytes += [mSendingData length];
        mSentCount ++;
        [self updateStatistics];
    }
}

- (void)calculateLayout {
    CGRect frame = { 0, 0, kScreenWidth, kScreenHeight - kDefaultStatusBarHeight - kNavBarHeight };
    
    if (mActiveView) {
        frame.origin.y -= mKeyboardHeight;
    }
    [mContentView setFrame:frame];
}

- (void)onClear {
    [mReceivedData setLength:0];
    mReceivedBytes = 0;
    mReceivedCount = 0;
    mSentBytes = 0;
    mSentCount = 0;
    [self updateReceivedText];
    [self updateStatistics];
}

- (void)quit {
    [mSession setDelegate:nil];
    [mSession close];
    
    UINavigationController *navigationController = [self navigationController];
    
    if ([navigationController topViewController] == self) {
        [navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - Notification

- (void)keyboardWillChangeFrame:(NSNotification *)notification {
    NSDictionary *userInfo = [notification userInfo];
    NSNumber *rectNumber = [userInfo objectForKey:@"UIKeyboardBoundsUserInfoKey"];
    
    if (rectNumber) {
        const CGFloat newHeight = rectNumber.CGRectValue.size.height;
        
        if (fabs(newHeight - mKeyboardHeight) >= 0.5f) {
            mKeyboardHeight = newHeight;
            
            if (mActiveView) {
                [self calculateLayout];
            }
        }
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [mActiveView resignFirstResponder];
}

@end
