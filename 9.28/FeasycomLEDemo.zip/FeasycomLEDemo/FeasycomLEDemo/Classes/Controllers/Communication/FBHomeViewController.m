//
//  FBBluetoothBrowserViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBHomeViewController.h"
#import "FBCommunicationViewController.h"
#import "FBRefreshControl.h"
#import "FBPeripheralCell.h"
#import <CoreBluetooth/CoreBluetooth.h>

@interface FBHomeViewController () {
}

@end

@implementation FBHomeViewController

- (id)init {
    self = [super init];
    if (self) {
        NSString *title = LS(@"COMMUNICATION");
        
        [self setTitle:title];
        
        UITabBarItem *tabBarItem = [[UITabBarItem alloc] initWithTabBarSystemItem:UITabBarSystemItemSearch tag:1];
        
        [tabBarItem setTitle:title];
        //        [self setTabBarItem:tabBarItem];
    }
    return self;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    FBCommunicationViewController *viewController = [[FBCommunicationViewController alloc] initWithPeripheralItem:mPeripheralItems[indexPath.row]];
    
    [[self navigationController] pushViewController:viewController animated:YES];
}

@end
