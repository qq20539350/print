//
//  FBBluetoothBrowserViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBViewController.h"
#import "FBRefreshControl.h"

@class FBSession;
@class FBPacket;

@interface FBBluetoothBrowserViewController : FBViewController <UITableViewDataSource, UITableViewDelegate, FBBluetoothBrowserDelegate> {
    UITableView *mTableView;
    FBRefreshControl *mRefreshControl;
    NSMutableArray *mPeripheralItems;
}

@property (nonatomic, strong, readonly) NSArray *peripheralItems;

- (void)deselect:(BOOL)animated;
- (void)reloadData;

@end
