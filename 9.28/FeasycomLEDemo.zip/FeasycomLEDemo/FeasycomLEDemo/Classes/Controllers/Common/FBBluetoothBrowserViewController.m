//
//  FBBluetoothBrowserViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBBluetoothBrowserViewController.h"
#import "FBRefreshControl.h"
#import "FBPeripheralCell.h"
#import <CoreBluetooth/CoreBluetooth.h>

@interface FBBluetoothBrowserViewController () <FBRefreshControlDelegate> {
    FBBluetoothBrowser *mBluetoothBrowser;
    NSTimer *mUpdateTimer;
}

@end

@implementation FBBluetoothBrowserViewController

@synthesize peripheralItems = mPeripheralItems;

- (id)init {
    self = [super init];
    if (self) {
        mBluetoothBrowser = [[FBBluetoothBrowser alloc] init];
        [mBluetoothBrowser setDelegate:self];
        mPeripheralItems = [[NSMutableArray alloc] initWithCapacity:16];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *view = [self view];
    
    if (nil == mTableView) {
        const CGRect frame = [view bounds];
        
        mTableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
        [mTableView setDataSource:self];
        [mTableView setDelegate:self];
        [mTableView setRowHeight:90];
        [mTableView setBackgroundColor:UIColorWhite];
        [mTableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        [mTableView setAllowsSelection:YES];
        
        mRefreshControl = [[FBRefreshControl alloc] initWithFrame:RECT(0, -kRefreshControlHeight, frame.size.width, kRefreshControlHeight)];
        [mRefreshControl setBackgroundColor:[UIColor lightGrayColor]];
        [mRefreshControl setDelegate:self];
        [mTableView addSubview:mRefreshControl];
    }
    
    [view addSubview:mTableView];
}

- (void)releaseUI {
    mTableView = nil;
    mRefreshControl = nil;
}

- (void)dealloc {
    [mUpdateTimer invalidate];
    [mBluetoothBrowser setDelegate:nil];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self deselect:animated];
    [mBluetoothBrowser startScanningWithServices:nil];
    if (nil == mUpdateTimer) {
        mUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(reloadData) userInfo:nil repeats:YES];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [mBluetoothBrowser stopScanning];
    if (mUpdateTimer) {
        [mUpdateTimer invalidate];
        mUpdateTimer = nil;
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [mPeripheralItems count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  {
    const NSInteger row = [indexPath row];
    static NSString *CellIdentifier = @"Cell";
    FBPeripheralCell *cell = (FBPeripheralCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (nil == cell) {
        cell = [[FBPeripheralCell alloc] initWithReuseIdentifier:CellIdentifier];
    }
    
    [cell setPeripheralItem:mPeripheralItems[row]];
    
    return cell;
}

#pragma mark - FBRefreshControlDelegate

- (void)refreshControlDidBeginRefresh:(FBRefreshControl *)refreshControl {
    [mPeripheralItems removeAllObjects];
    [mTableView reloadData];
    [mBluetoothBrowser stopScanning];
    [mBluetoothBrowser startScanningWithServices:nil];
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [mRefreshControl scrollViewDidScroll:scrollView];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [mRefreshControl scrollViewDidEndDragging:scrollView];
}

#pragma mark - FBBluetoothBrowserDelegate

- (void)bluetoothBrowserDidStartScanning:(FBBluetoothBrowser *)bluetoothBrowser {
    [mRefreshControl beginRefreshing:mTableView];
}

- (void)bluetoothBrowserDidStopScanning:(FBBluetoothBrowser *)bluetoothBrowser {
    [mRefreshControl stopRefreshing:mTableView];
}

- (void)bluetoothBrowser:(FBBluetoothBrowser *)bluetoothBrowser didFindPeripheralItem:(FBPeripheralItem *)peripheralItem {
    const NSUInteger newIndex = [mPeripheralItems count];
    NSIndexPath *newIndexPath = [NSIndexPath indexPathForRow:newIndex inSection:0];
    
    [mPeripheralItems insertObject:peripheralItem atIndex:newIndex];
    [mTableView insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationLeft];
    [mRefreshControl stopRefreshing:mTableView];
}

- (void)bluetoothBrowser:(FBBluetoothBrowser *)bluetoothBrowser didRemovePeripheralItem:(FBPeripheralItem *)peripheralItem {
    const NSUInteger index = [mPeripheralItems indexOfObject:peripheralItem];
    
    if (NSNotFound != index) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        
        [mPeripheralItems removeObjectAtIndex:index];
        [mTableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationRight];
    }
}

- (void)bluetoothBrowser:(FBBluetoothBrowser *)bluetoothBrowser didUpdatePeripheralItems:(NSArray *)peripheralItems {
    if (0 < [peripheralItems count]) {
        [mRefreshControl stopRefreshing:mTableView];
    }
    [mPeripheralItems setArray:peripheralItems];
    [mTableView reloadData];
}

#pragma mrak - Actions 

- (void)deselect:(BOOL)animated {
    NSIndexPath *selectedIndexPath = [mTableView indexPathForSelectedRow];
    
    if (selectedIndexPath) {
        [mTableView deselectRowAtIndexPath:selectedIndexPath animated:animated];
    }
}

- (void)reloadData {
    [mTableView reloadData];
}

@end
