//
//  FBAboutViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 4/17/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBAboutViewController.h"
#import "FBAboutCell.h"

#define kNumberOfRows 5

@interface FBAboutViewController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *mTableView;
}

@end

@implementation FBAboutViewController

- (id)init {
    self = [super init];
    if (self) {
        NSString *title = LS(@"ABOUT");
        
        [self setTitle:title];
        
        UITabBarItem *tabBarItem = [[UITabBarItem alloc] initWithTabBarSystemItem:UITabBarSystemItemMore tag:3];
        
        [tabBarItem setTitle:title];
//        [self setTabBarItem:tabBarItem];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *view = [self view];
    
    if (nil == mTableView) {
        const CGRect frame = [view bounds];
        
        mTableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
        [mTableView setDataSource:self];
        [mTableView setDelegate:self];
        [mTableView setRowHeight:44];
        [mTableView setBackgroundColor:UIColorWhite];
        [mTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        [mTableView setSeparatorColor:UIColorClear];
        [mTableView setAllowsSelection:NO];
        
        UIImageView *logoView = [[UIImageView alloc] initWithFrame:(CGRect){ 0, 0, kScreenWidth, 160 }];
        
        [mTableView setTableHeaderView:logoView];
        
    }
    [view addSubview:mTableView];
}

- (void)deselect:(BOOL)animated {
    NSIndexPath *selectedIndexPath = [mTableView indexPathForSelectedRow];
    
    if (selectedIndexPath) {
        [mTableView deselectRowAtIndexPath:selectedIndexPath animated:animated];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self deselect:animated];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return kNumberOfRows;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  {
    const NSInteger row = [indexPath row];
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    UILabel *textLabel = nil;
    UILabel *detailLabel = nil;
    
    if (nil == cell) {
        cell = [[FBAboutCell alloc] initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:CellIdentifier];
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        [cell setAccessoryType:UITableViewCellAccessoryNone];
        
        textLabel = [cell textLabel];
        detailLabel = [cell detailTextLabel];
        [detailLabel setAdjustsFontSizeToFitWidth:YES];
        [detailLabel setMinimumScaleFactor:0.75];
    } else {
        textLabel = [cell textLabel];
        detailLabel = [cell detailTextLabel];
    }
    
    static NSString *titleKeys[kNumberOfRows] = { @"VERSION", @"COMPANY", @"TEL", @"WEBSITE", @"EMAIL" };
    static NSString *contents[kNumberOfRows] = { @"FSC-BTTEST_V1.0", @"Shenzhen Feasycom Technology Co.,Ltd.", @"0755-23725562", @"www.feasycom.com", @"support@feasycom.com" };
    
    [textLabel setText:LS(titleKeys[row])];
    
    if (3 == row) {
        NSNumber *styleValue = [[NSNumber alloc] initWithInteger:NSUnderlineStyleSingle];
        NSDictionary *attributes = [[NSDictionary alloc] initWithObjectsAndKeys:styleValue, NSUnderlineStyleAttributeName, nil];
        NSAttributedString *attributedWebsite = [[NSAttributedString alloc] initWithString:contents[row] attributes:attributes];
        
        [detailLabel setAttributedText:attributedWebsite];
    } else {
        [detailLabel setText:contents[row]];
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
