//
//  FBTestingSessionViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 6/23/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBTestingSessionViewController.h"
#import "FBFunctionSettings.h"
#import "DQAlertView.h"
#import <FeasycomLE/FBError.h>

@interface FBTestingSessionViewController () <DQAlertViewDelegate> {
    FBFunctionSettings *mFunctionSettings;
    DQAlertView *mAlertView;
    int mSerialNumber;
    BOOL mEnded;
}

@end

@implementation FBTestingSessionViewController

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem {
    if (self = [super initWithPeripheralItem:peripheralItem sessionMode:FBSessionModeUnsafe reportHeight:(kScreenHeight - kDefaultStatusBarHeight - kNavBarHeight)]) {
        mFunctionSettings = [FBFunctionSettings sharedInstance];
    }
    return self;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if ([mFunctionSettings deviceNameSpecified]) {
        if ([[[mSession peripheralItem] name] hasPrefix:[mFunctionSettings deviceName]]) {
            [self appendReport:@"设备名测试通过"];
        } else {
            [self appendError:@"设备名测试失败"];
            [[NSNotificationCenter defaultCenter] postNotificationName:FBPeripheralItemDidFailUpdateNotification object:[mSession peripheralItem]];
            return;
        }
    }
    if ([mFunctionSettings RSSISpecified]) {
        DLog(@"setting rssi: %d", (int)[[mFunctionSettings RSSI] intValue]);
        DLog(@"session rssi: %d", (int)[[mSession peripheralItem] RSSI]);
        if (-[[mFunctionSettings RSSI] intValue] <= [[mSession peripheralItem] RSSI]) {
            [self appendReport:@"RSSI测试通过"];
        } else {
            [self appendError:@"RSSI测试失败"];
            [[NSNotificationCenter defaultCenter] postNotificationName:FBPeripheralItemDidFailUpdateNotification object:[mSession peripheralItem]];
            return;
        }
    }
    [self connect];
}

- (void)sessionDidOpen:(FBSession *)session {
    [super sessionDidOpen:session];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(matchingUUIDsTimeout) object:nil];
    
    if ([mFunctionSettings UUIDSpecified] && [[mFunctionSettings notifyUUID] length] > 0 && [[mFunctionSettings writeUUID] length] > 0) {
        [self appendReport:@"UUID测试通过"];
    }
    [self test];
}

- (void)sessionDidClose:(FBSession *)session error:(NSError *)error {
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    
    if (FBPeripheralItemErrorDiscoveringTimeout == [error code]) {
        [self appendError:@"找不到指定的UUID"];
        [[NSNotificationCenter defaultCenter] postNotificationName:FBPeripheralItemDidFailUpdateNotification object:[mSession peripheralItem]];
    } else {
        [self performSelector:@selector(quit) withObject:nil afterDelay:0.5];
    }
}

- (void)session:(FBSession *)session didReceiveData:(NSData *)data {
    NSLog(@"data:\n%@", data);
    
    if (mEnded) {
        return;
    }
    
    if ([mFunctionSettings readDataSpecified]) {
        NSString *specifiedData = [mFunctionSettings readData];
        
        if ([specifiedData length] > 0) {
            NSString *expectedData = [NSString stringWithFormat:@"AT$APP=%d,%03d,%@\r\n", mSerialNumber, (int)[specifiedData length], specifiedData];
            NSString *receivedData = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
            
            NSLog(@"receivedData:\n%@", receivedData);
            NSLog(@"expectedData:\n%@", expectedData);
            
            if ([receivedData isEqualToString:expectedData]) {
                [mSession sendData:[[NSString stringWithFormat:@"\r\n$APP=%d\r\n", (++ mSerialNumber)] dataUsingEncoding:NSASCIIStringEncoding]];
                [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(readDataTimeout) object:nil];
                [self appendReport:@"接收数据与设置一致"];
                [self appendReport:@"测试成功"];
                mEnded = YES;
                [[NSNotificationCenter defaultCenter] postNotificationName:FBPeripheralItemDidFinishUpdateNotification object:[mSession peripheralItem]];
            } else {
                [mSession sendData:[@"\r\n$APP=0\r\n" dataUsingEncoding:NSASCIIStringEncoding]];
                [self appendError:@"接收到的数据与指定数据不一致"];
            }
        }
    }
}

- (void)peripheralItemDidClose:(FBPeripheralItem *)peripheralItem error:(NSError *)error {
    [self appendError:[error localizedDescription]];
}

- (void)connect {
    NSArray *characteristicUUIDs = nil;
    
    if ([mFunctionSettings UUIDSpecified]) {
        NSString *notifyUUID = [mFunctionSettings notifyUUID];
        NSString *writeUUID = [mFunctionSettings writeUUID];
        
        if ([notifyUUID length] > 0 && [writeUUID length] > 0) {
            characteristicUUIDs = [[NSArray alloc] initWithObjects:notifyUUID, writeUUID, nil];
            
            [self performSelector:@selector(matchingUUIDsTimeout) withObject:nil afterDelay:3];
        }
    }
    if ([[mSession peripheralItem] connectWithCharacteristics:characteristicUUIDs]) {
    }
}

- (void)test {
    if ([mFunctionSettings writeDataSpecified]) {
        NSString *writeData = [mFunctionSettings writeData];
        
        if (nil == writeData) {
            writeData = @"";
        }
        
        NSString *wrappedData = [NSString stringWithFormat:@"\r\n$APP=%d,%02d,%03d,%@\r\n", (++ mSerialNumber), (int)fabs((double)[[mSession peripheralItem] RSSI]), (int)[writeData length], writeData];
        
        NSLog(@"wrappedData:\n%@", wrappedData);
        if ([mSession sendData:[wrappedData dataUsingEncoding:NSASCIIStringEncoding]]) {
            [self appendReport:@"数据已发送......"];
        } else {
            [self appendError:@"数据发送失败"];
        }
        
        if ([mFunctionSettings readDataSpecified] && [[mFunctionSettings readData] length] > 0) {
            [self performSelector:@selector(readDataTimeout) withObject:nil afterDelay:kTimeoutInterval];
            return;
        }
    } else {
    }
    mEnded = YES;
    [self appendReport:@"测试成功" font:UIFontBold16 textColor:[UIColor greenColor]];
    [[NSNotificationCenter defaultCenter] postNotificationName:FBPeripheralItemDidFinishUpdateNotification object:[mSession peripheralItem]];
}

- (void)matchingUUIDsTimeout {
    [self appendError:@"测试UUID超时"];
    [[NSNotificationCenter defaultCenter] postNotificationName:FBPeripheralItemDidFailUpdateNotification object:[mSession peripheralItem]];
}

- (void)readDataTimeout {
    [self appendError:@"接收数据超时"];
    [[NSNotificationCenter defaultCenter] postNotificationName:FBPeripheralItemDidFailUpdateNotification object:[mSession peripheralItem]];
}

extern BOOL mPuaseAutoConnection;

- (void)appendError:(NSString *)error {
    mPuaseAutoConnection = YES;
    [self appendReport:error font:UIFontBold16 textColor:[UIColor redColor]];
    if (nil == mAlertView) {
        mAlertView = [[DQAlertView alloc] initWithTitle:error message:nil cancelButtonTitle:@"确定" otherButtonTitle:nil];
        [mAlertView.titleLabel setTextColor:[UIColor redColor]];
        [mAlertView.titleLabel setFont:UIFontBold16];
        [mAlertView setDelegate:self];
        [mAlertView showInView:self.view];
    }
}

- (void)cancelButtonClickedOnAlertView:(DQAlertView *)alertView {
    mAlertView = nil;
    [self quit];
}

@end
