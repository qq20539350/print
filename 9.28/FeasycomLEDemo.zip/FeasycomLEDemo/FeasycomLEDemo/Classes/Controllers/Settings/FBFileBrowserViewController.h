//
//  FBFileBrowserViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 3/23/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBViewController.h"

extern NSString * const FBFileBrowserDidChooseFileNotification;

@class FBFileItem;
@class FBFileBrowserViewController;

@protocol FBFileBrowserViewControllerDelegate <NSObject>

- (void)fileBrowserViewController:(FBFileBrowserViewController *)viewController didSelectFileAtPath:(NSString *)path;

@end

@interface FBFileBrowserViewController : FBViewController

@property (nonatomic, strong, readonly) FBFileItem *fileItem;
@property (nonatomic, weak) id<FBFileBrowserViewControllerDelegate> delegate;

- (void)refresh;

@end