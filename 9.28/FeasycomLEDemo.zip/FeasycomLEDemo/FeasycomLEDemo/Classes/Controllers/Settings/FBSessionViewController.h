//
//  FBSessionViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 6/22/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBViewController.h"

@interface FBSessionViewController : FBViewController <FBSessionDelegate> {
    FBSession *mSession;
}

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem sessionMode:(FBSessionMode)sessionMode reportHeight:(CGFloat)reportHeight;
- (void)appendReport:(NSString *)report;
- (void)appendReport:(NSString *)report font:(UIFont *)font textColor:(UIColor *)textColor;
- (void)quit;
- (void)clearReport;

@end
