//
//  FBSettingsViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 14-2-24.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import "FBViewController.h"

@interface FBSettingsViewController : FBViewController

@end
