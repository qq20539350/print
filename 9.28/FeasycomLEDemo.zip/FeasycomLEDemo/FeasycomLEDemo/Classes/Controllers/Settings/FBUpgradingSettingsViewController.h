//
//  FBUpgradingSettingsViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 3/28/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBViewController.h"

@interface FBUpgradingSettingsViewController : FBViewController

@end
