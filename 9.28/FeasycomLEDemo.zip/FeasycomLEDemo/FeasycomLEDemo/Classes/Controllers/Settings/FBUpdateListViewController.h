//
//  FBUpdateListViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBBluetoothBrowserViewController.h"

@interface FBUpdateListViewController : FBBluetoothBrowserViewController {
    NSMutableArray *mFinishedPeripheralItems;
    NSMutableArray *mFailedPeripheralItems;
    FBSettingMode mSettingMode;
    BOOL mButtonClicked;
}

@property (nonatomic, assign) BOOL updateButtonHidden;

- (id)initWithSettingsMode:(FBSettingMode)mode;
- (void)reloadData;

@end
