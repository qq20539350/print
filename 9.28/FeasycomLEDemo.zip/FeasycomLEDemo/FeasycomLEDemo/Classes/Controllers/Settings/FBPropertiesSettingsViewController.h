//
//  FBPropertiesSettingsViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 4/24/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBSessionViewController.h"

@class FBPeripheralITem;

@interface FBPropertiesSettingsViewController : FBSessionViewController

- (id)initWithPeripheralItem:(FBPeripheralITem *)peripheralITem updateManually:(BOOL)updateManually;

@end
