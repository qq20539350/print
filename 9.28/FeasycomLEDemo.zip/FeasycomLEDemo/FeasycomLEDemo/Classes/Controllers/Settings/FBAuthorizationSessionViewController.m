//
//  FBAuthorizationSessionViewController.m
//  FeasycomLEDemo
//
//  Created by LIDONG on 7/29/15.
//  Copyright (c) 2015 Feasycom. All rights reserved.
//

#import "FBAuthorizationSessionViewController.h"
#import "NSString+Hexadecimal.h"

@interface FBAuthorizationSessionViewController () {
    NSString *mLicense;
    FBPacket *mAddressRequest;
    FBPacket *mKeyRequest;
}

@end

@implementation FBAuthorizationSessionViewController

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem license:(NSString *)license {
    if (self = [super initWithPeripheralItem:peripheralItem sessionMode:FBSessionModeSettings reportHeight:(kScreenHeight - kDefaultStatusBarHeight - kNavBarHeight)]) {
        [self setTitle:@"生产授权"];
        mLicense = license;
        
        DLog(@"license:\n%@", mLicense);
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[mSession peripheralItem] connect];
}

#pragma mrak - FBSessionDelegate


- (void)sessionDidFinishAuthorizing:(FBSession *)session {
    [super sessionDidFinishAuthorizing:session];
    
    mAddressRequest = [[FBPacket alloc] initWithID:0x10];
    
    [mAddressRequest beginEncoding];
    [mAddressRequest endEncoding];
    [mSession sendPacket:mAddressRequest timeoutInterval:3.f];
}

- (void)session:(FBSession *)session didReceiveResponse:(FBResponse *)response forRequest:(FBPacket *)request {
    if (request == mAddressRequest) {
        UInt8 bytes[6];
        
        [response beginDecoding];
        [response decodeBytes:bytes length:sizeof(bytes)];
        [response endDecoding];
        
        NSString *expectedddress = [[NSString alloc] initWithFormat:@"%02x%02x%02x%02x%02x%02x", bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5]];
        NSRange range = { 0, 4 };
        const int expectedCount = [[mLicense substringWithRange:range] intValue];
        const int actualCount = ((int)[mLicense length] - 4) / 56;
        const int count = MIN(expectedCount, actualCount);
        
        for (int i = 0; i < count; ++ i) {
            range.location = 4 + 56 * i;
            range.length = 12;
            
            NSString *startAddress = [mLicense substringWithRange:range];
            
            range.location += 12;
            
            NSString *endAddress = [mLicense substringWithRange:range];
            
            if (NSOrderedDescending != [startAddress compare:expectedddress options:NSCaseInsensitiveSearch] && NSOrderedDescending != [expectedddress compare:endAddress options:NSCaseInsensitiveSearch]) {
                range.location += 12;
                range.length = 32;
                
                NSString *key = [mLicense substringWithRange:range];
                
                mKeyRequest = [[FBPacket alloc] initWithID:0x10];
                
                [mKeyRequest beginEncoding];
                
                range.length = 2;
                
                for (int j = 0; j < 16; ++ j) {
                    range.location = j * 2;
                    
                    const UInt8 v = (UInt8)[[key substringWithRange:range] hexadecimalIntValue];
                    [mKeyRequest encodeInt8:v];
                }
                [mKeyRequest endEncoding];
                [mSession sendPacket:mKeyRequest timeoutInterval:7.f];
                [self appendReport:@"正在授权"];
                return;
            }
        }
        [self appendReport:@"非法地址"];
    } else if (request == mKeyRequest) {
        if (0 == [response statusCode]) {
            [self appendReport:@"授权成功"];
        } else {
            [self appendReport:@"授权失败"];
        }
        [self performSelector:@selector(quit) withObject:nil afterDelay:1.8];
    }
}

- (void)session:(FBSession *)session requestDidTimeout:(FBPacket *)request {
    if (request == mAddressRequest) {
        [self appendReport:@"授权超时"];
        [self performSelector:@selector(quit) withObject:nil afterDelay:1.8];
    }
}

- (void)session:(FBSession *)session requestDidFail:(FBPacket *)request error:(NSError *)error {
    if (request == mAddressRequest) {
        [self appendReport:@"请求地址失败"];
    } else if (request == mKeyRequest) {
        [self appendReport:@"授权失败"];
    }
    [self performSelector:@selector(quit) withObject:nil afterDelay:1.8];
}

- (void)session:(FBSession *)session didFailToWriteWithError:(NSError *)error {
    
}

- (void)session:(FBSession *)session didReceiveData:(NSData *)data {
    
}

@end
