//
//  FBPropertiesSettingsViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 4/24/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBPropertiesSettingsViewController.h"
#import "FBTextInputCell.h"
#import "FBTextInputGroupCell.h"
#import "FBSwitchCell.h"
#import "FBDetectingView.h"
#import "FBReportView.h"
#import "DOKeyboard.h"
#import "FBPropertySettings.h"
#import "NSString+Hexadecimal.h"

typedef enum __PropertyTag {
    kPropertyTagDeviceName,
    kPropertyTagPin,
    kPropertyTagBaud,
    kPropertyTagFeatures,
    kPropertyTagPairAdv,
    kPropertyTagSniffConn,
    kNumberOfProperties
} PropertyTag;

#define kCellHeight 44
#define kReportViewHeight 120

@interface FBPropertiesSettingsViewController () <UITextFieldDelegate, UIPickerViewDataSource, UIPickerViewDelegate> {
    UIView *mHeaderView;
    UIButton *mQueryButton;
    UIButton *mUpdateButton;
    UIScrollView *mScrollView;
    NSMutableArray *mTextFields;
    NSMutableArray *mSwitchs;
    NSMutableArray *mPickerViews;
    NSArray *mFeatureTextFields;
    NSArray *mPairAdvTextFields;
    NSArray *mSniffConnTextFields;
    id mActiveTextField;
    CGFloat mContentHeight;
    CGFloat mKeyboardHeight;
    FBPropertySettings *mPropertySettings;
    NSMutableArray *mUnsentRequests;
    NSMutableArray *mRoutingRequests;
    BOOL mUpdateManually;
    BOOL mQuerying;
}

@end

@implementation FBPropertiesSettingsViewController

static NSString * const titleKeys[kNumberOfProperties] = { @"DEVICE_NAME", @"PIN", @"BAUD", @"FEATURES", @"PAIR_ADV", @"SNIFF_CONN" };
static NSString * const FBBaudRates[9] = { @"1200", @"2400", @"4800", @"9600", @"19200", @"38400", @"57600", @"115200", @"230400" };
/*
static NSString * const FBReconnectionModes[4] = { @"OFF", @"SPP", @"HID", @"SPP+HID" };
static NSString * const FBModes[4] = { @"SPP", @"GATT", @"HID", @"SPP+GATT" };
static NSString * const FBOutputPorts[12] = { @"PIO0", @"PIO1", @"PIO2", @"PIO3", @"PIO4", @"PIO5", @"PIO6", @"PIO7", @"PIO8", @"PIO9", @"PIO10", @"PIO11" };
 */


- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem updateManually:(BOOL)updateManually {
    self = [super initWithPeripheralItem:peripheralItem sessionMode:FBSessionModeSettings reportHeight:kReportViewHeight];
    if (self) {
        mUpdateManually = updateManually;
        
        mUnsentRequests = [[NSMutableArray alloc] init];
        mRoutingRequests = [[NSMutableArray alloc] init];
        
        NSString *title = LS(@"PROPERTIES_DEFINING");
        
        [self setTitle:title];
        [self setHidesBottomBarWhenPushed:YES];
        
        UITabBarItem *tabBarItem = [[UITabBarItem alloc] initWithTabBarSystemItem:UITabBarSystemItemFavorites tag:2];
        
        [tabBarItem setTitle:title];
        //        [self setTabBarItem:tabBarItem];
        
        mPropertySettings = [FBPropertySettings sharedInstance];
        
        mContentHeight = 0.f;
        mKeyboardHeight = kDefaultKeyboardHeight;
        
        mTextFields = [[NSMutableArray alloc] initWithCapacity:7];
        mSwitchs = [[NSMutableArray alloc] initWithCapacity:7];
        mPickerViews = [[NSMutableArray alloc] initWithCapacity:4];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:@"UIKeyboardWillChangeFrameNotification" object:nil];
    }
    return self;
}

- (int)indexOfString:(NSString *)value inArray:(NSString * const __unsafe_unretained *)anArray count:(int)count {
    for (int i = 0; i < count; ++ i){
        if ([value isEqualToString:anArray[i]]) {
            return i;
        }
    }
    return 0;
}

- (void)updateControlStates {
    const BOOL isIdle = (0 == [mUnsentRequests count] && 0 == [mRoutingRequests count]);
    BOOL canUpdate = NO;
    
    for (UISwitch *aSwitch in mSwitchs) {
        if ([aSwitch isOn]) {
            canUpdate = YES;
        }
        [aSwitch setEnabled:isIdle];
    }
    
    [mQueryButton setEnabled:(mUpdateManually && isIdle)];
    [mUpdateButton setEnabled:(mUpdateManually && isIdle && canUpdate)];
}

- (FBTextInputCell *)addTextInputCellWithKeyboardType:(UIKeyboardType)keyboardType returnKeyType:(UIReturnKeyType)returnKeyType pickerInputView:(BOOL)pickerInputView tag:(NSUInteger)tag {
    FBTextInputCell *cell = [[FBTextInputCell alloc] initWithFrame:RECT(0, mContentHeight, kScreenWidth, kCellHeight)];
    
    [[cell titleLabel] setText:LS(titleKeys[tag])];
    
    UIPickerView *pickerView = nil;
    UITextField *textField = [cell textField];
    
    [textField setKeyboardType:keyboardType];
    [textField setReturnKeyType:returnKeyType];
    [textField setTag:tag];
    [textField setDelegate:self];
    
    if (pickerInputView) {
        pickerView = [[UIPickerView alloc] initWithFrame:RECT(0, 0, kScreenWidth, 216)];
        [pickerView setShowsSelectionIndicator:YES];
        [pickerView setDataSource:self];
        [pickerView setDelegate:self];
        [pickerView setTag:tag];
        [textField setInputView:pickerView];
        [mPickerViews addObject:pickerView];
    }
    
    [mTextFields addObject:textField];
    
    UISwitch *settingSwitch = [cell settingSwitch];
    
    [settingSwitch setTag:tag];
    [settingSwitch addTarget:self action:@selector(onValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    [mScrollView addSubview:cell];
    
#define TEXT(x) [NSString stringWithFormat:@"%d", x]
    
    if (kPropertyTagDeviceName == tag) {
        [textField setText:[mPropertySettings deviceName]];
        [settingSwitch setOn:[mPropertySettings deviceNameEnabled]];
    } else if (kPropertyTagPin == tag) {
        [textField setText:[mPropertySettings pin]];
        [settingSwitch setOn:[mPropertySettings pinEnabled]];
    } else if (kPropertyTagBaud == tag) {
        [textField setText:TEXT([mPropertySettings baudRate])];
        
        const NSUInteger index = [self indexOfString:[textField text] inArray:FBBaudRates count:9];
        
        if (NSNotFound != index) {
            [pickerView selectRow:index inComponent:0 animated:NO];
        }
        [settingSwitch setOn:[mPropertySettings baudEnabled]];
    }
    [textField setEnabled:[settingSwitch isOn]];
    [mSwitchs addObject:settingSwitch];
    mContentHeight += cell.frame.size.height;
    
    return cell;
}

- (FBTextInputCell *)addTextInputCellWithKeyboardType:(UIKeyboardType)keyboardType returnKeyType:(UIReturnKeyType)returnKeyType tag:(NSUInteger)tag {
    return [self addTextInputCellWithKeyboardType:keyboardType returnKeyType:returnKeyType pickerInputView:NO tag:tag];
}

- (FBTextInputGroupCell *)addTextInputGroupCellWithKeyboardType:(UIKeyboardType)keyboardType returnKeyType:(UIReturnKeyType)returnKeyType tag:(NSUInteger)tag {
    NSUInteger numberOfTextFields = 0;
    
    if (kPropertyTagFeatures == tag) {
        numberOfTextFields = kNumberOfFeatures;
    } else if (kPropertyTagPairAdv == tag) {
        numberOfTextFields = kNumberOfPairAdv;
    } else if (kPropertyTagSniffConn == tag) {
        numberOfTextFields = kNumberOfSniffConn;
    }
    
    FBTextInputGroupCell *cell = [[FBTextInputGroupCell alloc] initWithFrame:RECT(0, mContentHeight, kScreenWidth, kCellHeight * 2.f) numberOfTextFieds:numberOfTextFields];
    
    [[cell titleLabel] setText:LS(titleKeys[tag])];
    
    UISwitch *settingSwitch = [cell settingSwitch];
    
    [settingSwitch setTag:tag];
    [settingSwitch addTarget:self action:@selector(onValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    NSArray *textFields = [cell textFields];
    BOOL enabled = NO;
    NSArray *values = nil;
    
    if (kPropertyTagFeatures == tag) {
        mFeatureTextFields = textFields;
        enabled = [mPropertySettings featuresEnabled];
        values = [mPropertySettings features];
    } else if (kPropertyTagPairAdv == tag) {
        mPairAdvTextFields = textFields;
        enabled = [mPropertySettings pairAdvEnabled];
        values = [mPropertySettings pairAdv];
    } else if (kPropertyTagSniffConn == tag) {
        mSniffConnTextFields = textFields;
        enabled = [mPropertySettings sniffConnEnabled];
        values = [mPropertySettings sniffConn];
    }
    
    const NSUInteger numberOfValues = [values count];
    
    [settingSwitch setOn:enabled];
    
    for (NSUInteger i = 0; i < numberOfTextFields; ++ i) {
        UITextField *textField = textFields[i];
        UInt16 value = 0;
        
        if (i < numberOfValues) {
            value = [values[i] intValue];
        }
        [textField setReturnKeyType:returnKeyType];
        [textField setTag:tag];
        [textField setDelegate:self];
        [textField setText:[NSString stringWithFormat:@"%04X", value]];
        [textField setEnabled:enabled];
        
        DOKeyboard *keyboard = [DOKeyboard keyboardWithType:DOKeyboardTypeHex];
        
        [keyboard setInput:textField];
    }
    
    [mScrollView addSubview:cell];
    [mSwitchs addObject:settingSwitch];
    mContentHeight += cell.frame.size.height;
    
    return cell;
}

- (FBSwitchCell *)addSwitchCellWithDescription:(NSString *)description tag:(NSUInteger)tag {
    FBSwitchCell *cell = [[FBSwitchCell alloc] initWithFrame:RECT(0, mContentHeight, kScreenWidth, kCellHeight)];
    
    [[cell titleLabel] setText:LS(titleKeys[tag])];
    [[cell detailLabel] setText:description];
    
    UISwitch *settingSwitch = [cell settingSwitch];
    
    [settingSwitch setTag:tag];
    [settingSwitch addTarget:self action:@selector(onValueChanged:) forControlEvents:UIControlEventValueChanged];
    
//    if (kPropertyTagSuffix == tag) {
//        [settingSwitch setOn:[mPropertySettings suffixEnabled]];
//    }
    [mScrollView addSubview:cell];
    [mSwitchs addObject:settingSwitch];
    
    mContentHeight += kCellHeight;
    
    return cell;
}

- (void)addSeparator {
    UIView *separatorView = [[UIView alloc] initWithFrame:RECT(0, mContentHeight, kScreenWidth, 1)];
    
    [separatorView setBackgroundColor:UIColorSeparator];
    
    mContentHeight += 1;
    
    [mScrollView addSubview:separatorView];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *view = [self view];
    
    if (nil == mScrollView) {
        mScrollView = [[UIScrollView alloc] initWithFrame:RECT(0, kNavBarHeight, kScreenWidth, kScreenHeight - kNavBarHeight * 2 - kReportViewHeight - kDefaultStatusBarHeight)];
        [mScrollView setBackgroundColor:UIColorBackground];
        [mScrollView setDecelerationRate:UIScrollViewDecelerationRateNormal];
        [mScrollView setShowsVerticalScrollIndicator:YES];
        [mScrollView setShowsHorizontalScrollIndicator:NO];
        [mScrollView setPagingEnabled:NO];
        [mScrollView setDirectionalLockEnabled:YES];
        [mScrollView setBounces:YES];
        [mScrollView setAlwaysBounceHorizontal:NO];
        [mScrollView setAlwaysBounceVertical:YES];
        [mScrollView setBouncesZoom:NO];
        [mScrollView setScrollEnabled:YES];
        
        FBTextInputCell *textInputCell;
        
        [self addSeparator];
        textInputCell = [self addTextInputCellWithKeyboardType:UIKeyboardTypeASCIICapable returnKeyType:UIReturnKeyNext tag:kPropertyTagDeviceName];
        [self addSeparator];
        textInputCell = [self addTextInputCellWithKeyboardType:UIKeyboardTypeNumberPad returnKeyType:UIReturnKeyNext tag:kPropertyTagPin];
        [self addSeparator];
        textInputCell = [self addTextInputCellWithKeyboardType:UIKeyboardTypeNumberPad returnKeyType:UIReturnKeyNext pickerInputView:YES tag:kPropertyTagBaud];
        [self addSeparator];
        [self addTextInputGroupCellWithKeyboardType:UIKeyboardTypeNumberPad returnKeyType:UIReturnKeyNext tag:kPropertyTagFeatures];
        [self addSeparator];
        [self addTextInputGroupCellWithKeyboardType:UIKeyboardTypeNumberPad returnKeyType:UIReturnKeyNext tag:kPropertyTagPairAdv];
        [self addSeparator];
        [self addTextInputGroupCellWithKeyboardType:UIKeyboardTypeNumberPad returnKeyType:UIReturnKeyNext tag:kPropertyTagSniffConn];
        [self addSeparator];
        
        UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(resignFirstResponder)];
        
        [gestureRecognizer setCancelsTouchesInView:YES];
        [mScrollView addGestureRecognizer:gestureRecognizer];
        [mScrollView setContentSize:SZ(kScreenWidth, mContentHeight)];
    }
    
    if (nil == mHeaderView) {
        mHeaderView = [[UIView alloc] initWithFrame:RECT(0, 0, kScreenWidth, kNavBarHeight)];
        [mHeaderView setBackgroundColor:UIColorBackground];
        
        if (nil == mQueryButton) {
            mQueryButton = [[UIButton alloc] initWithFrame:RECT((kScreenWidth - 180) / 3, 2, 90, 40)];
            [mQueryButton setBackgroundImage:[IMG(@"button.png") resizableImageWithCapInsets:UIEdgeInsetsMake(16, 16, 16, 16)] forState:UIControlStateNormal];
            [mQueryButton.titleLabel setFont:UIFont16];
            [mQueryButton setTitleColor:UIColorMainText forState:UIControlStateNormal];
            [mQueryButton setTitle:LS(@"QUERY") forState:UIControlStateNormal];
            [mQueryButton addTarget:self action:@selector(onQuery) forControlEvents:UIControlEventTouchUpInside];
        }
        [mHeaderView addSubview:mQueryButton];
        
        if (nil == mUpdateButton) {
            mUpdateButton = [[UIButton alloc] initWithFrame:RECT(kScreenWidth - 90 -(kScreenWidth - 180) / 3, 2, 90, 40)];
            [mUpdateButton setBackgroundImage:[IMG(@"button.png") resizableImageWithCapInsets:UIEdgeInsetsMake(16, 16, 16, 16)] forState:UIControlStateNormal];
            [mUpdateButton.titleLabel setFont:UIFont16];
            [mUpdateButton setTitleColor:UIColorMainText forState:UIControlStateNormal];
            [mUpdateButton setTitle:LS(@"UPDATE") forState:UIControlStateNormal];
            [mUpdateButton addTarget:self action:@selector(onUpdate) forControlEvents:UIControlEventTouchUpInside];
        }
        [mHeaderView addSubview:mUpdateButton];
    }
    
    [view insertSubview:mHeaderView atIndex:1];
    
    [self updateControlStates];
    
    [view insertSubview:mScrollView atIndex:0];
}

- (void)releaseUI {
    mScrollView = nil;
    [mTextFields removeAllObjects];
    [mSwitchs removeAllObjects];
    [mPickerViews removeAllObjects];
    mFeatureTextFields = nil;
    mPairAdvTextFields = nil;
    mSniffConnTextFields = nil;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    DLog(@"mSession: %@", mSession);
    DLog(@"[mSession peripheralItem]: %@", [mSession peripheralItem]);
    
    if ([[mSession peripheralItem] connect]) {
        [self startWaiting];
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self resignFirstResponder];
}

- (void)drawBack {
    const CGRect bounds = [[self view] bounds];
    const CGRect tableFrame = { 0, kNavBarHeight, bounds.size.width, bounds.size.height - mKeyboardHeight - kNavBarHeight - kReportViewHeight };
    
    [mScrollView setFrame:tableFrame];
}

- (UITextField *)textFieldForTag:(NSUInteger)tag {
    for (UITextField *textField in mTextFields) {
        if ([textField tag] == tag) {
            return textField;
        }
    }
    return nil;
}

- (UISwitch *)switchControlForTag:(NSUInteger)tag {
    for (UISwitch *aSwitch in mSwitchs) {
        if ([aSwitch tag] == tag) {
            return aSwitch;
        }
    }
    return nil;
}

- (UIPickerView *)pickerViewForTag:(NSUInteger)tag {
    for (UIPickerView *pickerView in mSwitchs) {
        if ([pickerView tag] == tag) {
            return pickerView;
        }
    }
    return nil;
}

#pragma mark - UITextViewFieldDelegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (nil != [textField inputView]) {
        const NSUInteger tag = textField.tag;
        
        if (kPropertyTagFeatures == tag || kPropertyTagPairAdv == tag || kPropertyTagSniffConn == tag) {
            if ([string length] > 0 && !NSStringIsHexNumber(string)) {
                return NO;
            }
            const NSRange textRange = { 0, textField.text.length };
            const NSRange insertRange = { range.location, string.length };
            const NSRange newRange = NSUnionRange(textRange, insertRange);
            
            if (4 < newRange.length) {
                return NO;
            }
            return YES;
        }
        return NO;
    }
    if (UIKeyboardTypeNumberPad == [textField keyboardType] && [string length] > 0) {
        if (!NSStringIsNumber(string)) {
            return NO;
        }
        if (kPropertyTagPin == textField.tag) {
            const NSRange textRange = { 0, textField.text.length };
            const NSRange insertRange = { range.location, string.length };
            const NSRange newRange = NSUnionRange(textRange, insertRange);
            
            if (4 < newRange.length) {
                return NO;
            }
        }
    }
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    DLog(@"%s", __PRETTY_FUNCTION__);
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    DLog(@"%s", __PRETTY_FUNCTION__);
    mActiveTextField = textField;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationCurve:NSKeyboardAnimationCurve];
    [UIView setAnimationDuration:NSKeyboardAnimationDuration];
    [self drawBack];
    [mScrollView scrollRectToVisible:[[mActiveTextField superview] frame] animated:NO];
    [UIView commitAnimations];
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    DLog(@"%s", __PRETTY_FUNCTION__);
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [self resignFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    const NSUInteger nextIndex = [mTextFields indexOfObject:textField] + 1;
    
    if (nextIndex < [mTextFields count]) {
        [mTextFields[nextIndex] becomeFirstResponder];
    } else {
        [self resignFirstResponder];
    }
    return YES;
}

#pragma mark - UIPickerViewDelegate

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    const NSUInteger tag = [pickerView tag];
    
    if (kPropertyTagBaud == tag) {
        return 9;
    }
    return 0;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    if (0 == component) {
        return 150.f;
    }
    return 0.f;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    const NSUInteger tag = [pickerView tag];
    
    if (kPropertyTagBaud == tag) {
        return FBBaudRates[row];
    }
    return @"";
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    const NSUInteger tag = [pickerView tag];
    
    [[self textFieldForTag:tag] setText:[self pickerView:pickerView titleForRow:row forComponent:component]];
}

#pragma mark - FBSessionDelegate

- (void)sessionDidFinishAuthorizing:(FBSession *)session {
    [super sessionDidFinishAuthorizing:session];
    
    if (session == mSession) {
        if (!mUpdateManually) {
            [self startUpdating];
        }
    }
}

- (void)session:(FBSession *)session didReceiveResponse:(FBResponse *)response forRequest:(FBPacket *)request {
    if (session == mSession) {
        if ([mRoutingRequests containsObject:request]) {
            [mRoutingRequests removeObject:request];
        }
        
        const UInt8 code = [response responseID];
        NSString *log = nil;
        
        if (0 == [response statusCode]) {
            if (0x01 == code) {
                log = mQuerying ? @"查询设备名成功。" : @"更新设备名成功。";
                if (mQuerying) {
                    NSString *content = [[NSString alloc] initWithData:[response bodyData] encoding:NSUTF8StringEncoding];
                    
                    [mPropertySettings setDeviceName:content];
                    [[self textFieldForTag:kPropertyTagDeviceName] setText:content];
                }
            } else if (0x02 == code) {
                log = mQuerying ? @"查询PIN成功。" : @"更新PIN成功。";
                
                if (mQuerying) {
                    char values[5] = { 0 };
                    
                    [response beginDecoding];
                    [response decodeBytes:(UInt8 *)values length:4];
                    [response endDecoding];
                    
                    NSString *pin = [NSString stringWithCString:values encoding:NSASCIIStringEncoding];
                    
                    [mPropertySettings setPin:pin];
                    
                    [[self textFieldForTag:kPropertyTagPin] setText:pin];
                }
            } else if (0x03 == code) {
                log = mQuerying ? @"查询波特率成功。" : @"更新波特率成功。";
                
                if (mQuerying) {
                    UInt32 value = 0;
                    
                    [response beginDecoding];
                    [response decodeInt32:&value];
                    [response endDecoding];
                    
                    [[self textFieldForTag:kPropertyTagBaud] setText:[NSString stringWithFormat:@"%u", (unsigned)value]];
                }
            } else if (0x04 == code) {
                log = mQuerying ? @"查询Feature(s)成功。" : @"更新Feature(s)成功。";
                
                if (mQuerying) {
                    NSMutableArray *features = [[NSMutableArray alloc] initWithCapacity:5];
                    
                    [response beginDecoding];
                    
                    for (int i = 0; i < 5; ++ i) {
                        UInt16 value = 0;
                        
                        [response decodeInt16:&value];
                        [features addObject:@(value)];
                        [mFeatureTextFields[i] setText:[NSString stringWithFormat:@"%04X", value]];
                    }
                    
                    [response endDecoding];
                    
                    if ([features count] == 5) {
                        [mPropertySettings setFeatures:features];
                    }
                }
            } else if (0x05 == code) {
                log = mQuerying ? @"查询Pair/Adv成功。" : @"更新Pair/Adv成功。";
                
                if (mQuerying) {
                    NSMutableArray *pairAdv = [[NSMutableArray alloc] initWithCapacity:5];
                    
                    [response beginDecoding];
                    
                    for (int i = 0; i < 4; ++ i) {
                        UInt16 value = 0;
                        
                        [response decodeInt16:&value];
                        [pairAdv addObject:@(value)];
                        [mPairAdvTextFields[i] setText:[NSString stringWithFormat:@"%04X", value]];
                    }
                    
                    [response endDecoding];
                    
                    if ([pairAdv count] == 4) {
                        [mPropertySettings setPairAdv:pairAdv];
                    }
                }
            } else if (0x06 == code) {
                log = mQuerying ? @"查询Sniff/Conn成功。" : @"更新Sniff/Conn成功。";
                
                if (mQuerying) {
                    NSMutableArray *sniffConn = [[NSMutableArray alloc] initWithCapacity:5];
                    
                    [response beginDecoding];
                    
                    for (int i = 0; i < 4; ++ i) {
                        UInt16 value = 0;
                        
                        [response decodeInt16:&value];
                        [sniffConn addObject:@(value)];
                        [mSniffConnTextFields[i] setText:[NSString stringWithFormat:@"%04X", value]];
                    }
                    
                    [response endDecoding];
                    
                    if ([sniffConn count] == 4) {
                        [mPropertySettings setSniffConn:sniffConn];
                    }
                }
            }
            
            [self appendReport:log];
            
            if (0 < [mUnsentRequests count]) {
                [self sendNextRequest];
            } else {
                [self appendReport:(mQuerying ? @"完成查询。" : @"完成更新。")];
                [[NSNotificationCenter defaultCenter] postNotificationName:FBPeripheralItemDidFinishUpdateNotification object:[mSession peripheralItem]];
                
                if (!mUpdateManually) {
                    [self performSelector:@selector(quit) withObject:nil afterDelay:1.8];
                } else {
                    [self cleanup];
                }
            }
        } else {
            if (0x01 == code) {
                log = mQuerying ? @"查询设备名失败。" : @"更新设备名失败。";
            } else if (0x02 == code) {
                log = mQuerying ? @"查询PIN失败。" : @"更新PIN失败。";
            } else if (0x03 == code) {
                log = mQuerying ? @"查询波特率失败。" : @"更新波特率失败。";
            } else if (0x04 == code) {
                log = mQuerying ? @"查询Feature(s)失败。" : @"更新Feature(s)失败。";
            } else if (0x05 == code) {
                log = mQuerying ? @"查询Pair/Adv失败。" : @"更新Pair/Adv失败。";
            } else if (0x06 == code) {
                log = mQuerying ? @"查询Sniff/Conn失败。" : @"更新Sniff/Conn失败。";
            }
            [self appendReport:[log stringByAppendingFormat:@" (error=%u)", (unsigned)code]];
            [[NSNotificationCenter defaultCenter] postNotificationName:FBPeripheralItemDidFailUpdateNotification object:[mSession peripheralItem]];
        }
    }
}

- (void)session:(FBSession *)session requestDidTimeout:(FBPacket *)request {
    if (session == mSession) {
        NSString *message = [NSString stringWithFormat:@"command: %x", [request packetID]];
        
        ALERT(LS(@"REQUEST_TIMEOUT"), message);
        [self cleanup];
    }
}

- (void)session:(FBSession *)session requestDidFail:(FBPacket *)request error:(NSError *)error {
    if (session == mSession) {
        ALERT(LS(@"REQUEST_FAILED"), [error localizedDescription]);
        [self cleanup];
    }
}

- (void)session:(FBSession *)session didFailToWriteWithError:(NSError *)error {
    
}

- (void)session:(FBSession *)session didReceiveData:(NSData *)data {
    
}

#pragma mark -

- (void)keyboardWillChangeFrame:(NSNotification *)notification {
    NSDictionary *userInfo = [notification userInfo];
    NSNumber *rectNumber = [userInfo objectForKey:@"UIKeyboardBoundsUserInfoKey"];
    
    if (rectNumber) {
        const CGFloat newHeight = rectNumber.CGRectValue.size.height;
        
        if (fabs(newHeight - mKeyboardHeight) >= 0.5f) {
            mKeyboardHeight = newHeight;
            
            if (mActiveTextField) {
                [self drawBack];
                [mScrollView scrollRectToVisible:[[mActiveTextField superview] frame] animated:NO];
            }
        }
    }
}

- (void)onValueChanged:(UISwitch *)sender {
    const NSUInteger tag = [sender tag];
    const BOOL isOn = [sender isOn];
    NSArray *textFields = nil;
    UITextField *textField = nil;
    
    if (kPropertyTagDeviceName == tag) {
        [mPropertySettings setDeviceNameEnabled:isOn];
    } else if (kPropertyTagPin == tag) {
        [mPropertySettings setPinEnabled:isOn];
    } else if (kPropertyTagBaud == tag) {
        [mPropertySettings setBaudEnabled:isOn];
    } else if (kPropertyTagFeatures == tag) {
        [mPropertySettings setFeaturesEnabled:isOn];
        textFields = mFeatureTextFields;
    } else if (kPropertyTagPairAdv == tag) {
        [mPropertySettings setPairAdvEnabled:isOn];
        textFields = mPairAdvTextFields;
    } else if (kPropertyTagSniffConn == tag) {
        [mPropertySettings setSniffConnEnabled:isOn];
        textFields = mSniffConnTextFields;
    }
    
    if (textFields) {
        for (textField in textFields) {
            [textField setEnabled:isOn];
        }
        
        [textFields[0] becomeFirstResponder];
    }
    
    const BOOL isIdle = (0 == [mUnsentRequests count] && 0 == [mRoutingRequests count]);
    
    if (isOn) {
        [[self textFieldForTag:tag] setEnabled:isOn];
        [[self textFieldForTag:tag] becomeFirstResponder];
        [mUpdateButton setEnabled:(mUpdateManually && isIdle && isOn)];
    } else {
        [self resignFirstResponder];
        [[self textFieldForTag:tag] setEnabled:isOn];
        
        for (UISwitch *aSwitch in mSwitchs) {
            if ([aSwitch isOn]) {
                [mUpdateButton setEnabled:(mUpdateManually && isIdle)];
                break;
            }
        }
    }
}

- (BOOL)resignFirstResponder {
    if (mActiveTextField) {
        UITextField *activeTextField = mActiveTextField;
        CGPoint contentOffset = [mScrollView contentOffset];
        
        mActiveTextField = nil;
        
        [activeTextField resignFirstResponder];
        
        CGRect tableFrame = [[self view] bounds];
        
        tableFrame.origin.y = kNavBarHeight;
        tableFrame.size.height -= (kNavBarHeight + kReportViewHeight);
        
        [mScrollView setFrame:tableFrame];
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationCurve:NSKeyboardAnimationCurve];
        [UIView setAnimationDuration:NSKeyboardAnimationDuration];
        
        const CGFloat maxContentOffsetY = mScrollView.contentSize.height - tableFrame.size.height;
        
        if (maxContentOffsetY < contentOffset.y) {
            contentOffset.y = (0 < maxContentOffsetY) ? maxContentOffsetY : 0;
        }
        [mScrollView setContentOffset:contentOffset animated:NO];
        [UIView commitAnimations];
        return YES;
    }
    return NO;
}

- (void)startUpdating {
    mQuerying = NO;
    [mUpdateButton setTitle:LS(@"UPDATING") forState:UIControlStateNormal];
    [mQueryButton setEnabled:NO];
    [mUpdateButton setEnabled:NO];
    [self clearReport];
    [self generateUpdateRequests];
    [self sendFirstRequest];
}

- (void)onQuery {
    mQuerying = YES;
    [mQueryButton setTitle:LS(@"QUERYING") forState:UIControlStateNormal];
    
    [self generateQueryRequests];
    [self sendFirstRequest];
}

- (void)onUpdate {
    BOOL shouldUpdate = NO;
    
    if ([[self switchControlForTag:kPropertyTagPin] isOn]) {
        NSString *pin = [[self textFieldForTag:kPropertyTagPin] text];
        
        if (4 != [pin length] || !NSStringIsNumber(pin)) {
            ALERT(LS(@"PIN_INVALID_TIP"), nil);
            return;
        }
        [mPropertySettings setPinEnabled:YES];
        [mPropertySettings setPin:pin];
        shouldUpdate = YES;
    } else {
        [mPropertySettings setPinEnabled:NO];
    }
    
    if ([[self switchControlForTag:kPropertyTagDeviceName] isOn]) {
        [mPropertySettings setDeviceNameEnabled:YES];
        [mPropertySettings setDeviceName:[[self textFieldForTag:kPropertyTagDeviceName] text]];
        shouldUpdate = YES;
    } else {
        [mPropertySettings setDeviceNameEnabled:NO];
    }
    
    if ([[self switchControlForTag:kPropertyTagBaud] isOn]) {
        [mPropertySettings setBaudEnabled:YES];
        [mPropertySettings setBaudRate:[[[self textFieldForTag:kPropertyTagBaud] text] intValue]];
        shouldUpdate = YES;
    } else {
        [mPropertySettings setBaudEnabled:NO];
    }
    
    UITextField *textField;
    
    if ([[self switchControlForTag:kPropertyTagFeatures] isOn]) {
        [mPropertySettings setFeaturesEnabled:YES];
        
        NSMutableArray *features = [[NSMutableArray alloc] initWithCapacity:kNumberOfFeatures];
        
        for (textField in mFeatureTextFields) {
            [features addObject:@([[textField text] hexadecimalIntValue])];
        }
        [mPropertySettings setFeatures:features];
        shouldUpdate = YES;
    } else {
        [mPropertySettings setFeaturesEnabled:NO];
    }
    
    if ([[self switchControlForTag:kPropertyTagPairAdv] isOn]) {
        [mPropertySettings setPairAdvEnabled:YES];
        
        NSMutableArray *pairAdv = [[NSMutableArray alloc] initWithCapacity:kNumberOfPairAdv];
        
        for (textField in mPairAdvTextFields) {
            [pairAdv addObject:@([[textField text] hexadecimalIntValue])];
        }
        [mPropertySettings setPairAdv:pairAdv];
        shouldUpdate = YES;
    } else {
        [mPropertySettings setPairAdvEnabled:NO];
    }
    
    if ([[self switchControlForTag:kPropertyTagSniffConn] isOn]) {
        [mPropertySettings setSniffConnEnabled:YES];
        
        NSMutableArray *sniffConn = [[NSMutableArray alloc] initWithCapacity:kNumberOfSniffConn];
        
        for (textField in mSniffConnTextFields) {
            [sniffConn addObject:@([[textField text] hexadecimalIntValue])];
        }
        [mPropertySettings setSniffConn:sniffConn];
        shouldUpdate = YES;
    } else {
        [mPropertySettings setSniffConnEnabled:NO];
    }
    
    if (shouldUpdate) {
        [mPropertySettings save];
        [self startUpdating];
    }
}

- (void)generateQueryRequests {
    if (0 < [mUnsentRequests count]) {
        return;
    }
    
    for (UInt8 code = 0x01; code <= 0x06; ++ code) {
        FBPacket *packet = [[FBPacket alloc] initWithID:code];
        [packet beginEncoding];
        [packet endEncoding];
        [mUnsentRequests addObject:packet];
    }
}

- (void)generateUpdateRequests {
    if (0 < [mUnsentRequests count]) {
        return;
    }
    
    FBPacket *packet;
    
    NSString *deviceName = [mPropertySettings deviceName];
    const NSUInteger nameSize = [deviceName lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
    
    if ([mPropertySettings deviceNameEnabled] && nameSize > 0) {
        packet = [[FBPacket alloc] initWithID:0x01];
        [packet beginEncoding];
        [packet encodeBytes:[deviceName UTF8String] length:nameSize];
        [packet endEncoding];
        [mUnsentRequests addObject:packet];
    }
    
    NSString *pin = [mPropertySettings pin];
    const NSUInteger pinSize = [pin lengthOfBytesUsingEncoding:NSASCIIStringEncoding];
    
    if ([mPropertySettings pinEnabled] && 4 == pinSize) {
        packet = [[FBPacket alloc] initWithID:0x02];
        [packet beginEncoding];
        [packet encodeBytes:[pin cStringUsingEncoding:NSASCIIStringEncoding] length:4];
        [packet endEncoding];
        [mUnsentRequests addObject:packet];
    }
    if ([mPropertySettings baudEnabled]) {
        packet = [[FBPacket alloc] initWithID:0x03];
        [packet beginEncoding];
        [packet encodeInt32:[mPropertySettings baudRate]];
        [packet endEncoding];
        [mUnsentRequests addObject:packet];
    }
    if ([mPropertySettings featuresEnabled]) {
        NSArray *features = [mPropertySettings features];
        
        packet = [[FBPacket alloc] initWithID:0x04];
        [packet beginEncoding];
        
        for (NSNumber *feature in features) {
            const UInt16 value = (UInt16)[feature unsignedIntValue];
            
            [packet encodeInt16:value];
        }
        [packet endEncoding];
        [mUnsentRequests addObject:packet];
    }
    if ([mPropertySettings pairAdvEnabled]) {
        NSArray *pairAdv = [mPropertySettings pairAdv];
        
        packet = [[FBPacket alloc] initWithID:0x05];
        [packet beginEncoding];
        
        for (NSNumber *param in pairAdv) {
            const UInt16 value = (UInt16)[param unsignedIntValue];
            
            [packet encodeInt16:value];
        }
        [packet endEncoding];
        [mUnsentRequests addObject:packet];
    }
    if ([mPropertySettings sniffConnEnabled]) {
        NSArray *sniffConn = [mPropertySettings sniffConn];
        
        packet = [[FBPacket alloc] initWithID:0x06];
        [packet beginEncoding];
        
        for (NSNumber *param in sniffConn) {
            const UInt16 value = (UInt16)[param unsignedIntValue];
            
            [packet encodeInt16:value];
        }
        [packet endEncoding];
        [mUnsentRequests addObject:packet];
    }
}

- (void)sendNextRequest {
        FBPacket *request = mUnsentRequests[0];
        const UInt8 code = [request packetID];
        
        [mSession sendPacket:request timeoutInterval:kTimeoutInterval];
        
        NSString *text = nil;
        
        if (0x01 == code) {
            text = mQuerying ? @"正在查询设备名..." : @"正在更新设备名...";
        } else if (0x02 == code) {
            text = mQuerying ? @"正在查询PIN..." : @"正在更新PIN...";
        } else if (0x03 == code) {
            text = mQuerying ? @"正在查询波特率..." : @"正在更新波特率...";
        } else if (0x04 == code) {
            text = mQuerying ? @"正在查询Feature(s)..." : @"正在更新Feature(s)...";
        } else if (0x05 == code) {
            text = mQuerying ? @"正在查询Pair/Adv..." : @"正在更新Pair/Adv...";
        } else if (0x06 == code) {
            text = mQuerying ? @"正在查询Sniff/Conn..." : @"正在更新Sniff/Conn...";
        }
        
        [self appendReport:text];
        [mRoutingRequests addObject:request];
        [mUnsentRequests removeObjectAtIndex:0];
}

- (void)sendFirstRequest {
    if (0 < [mUnsentRequests count]) {
        [self resignFirstResponder];
        [self updateControlStates];
        [self sendNextRequest];
    }
}

- (void)cleanup {
    [mUnsentRequests removeAllObjects];
    [mRoutingRequests removeAllObjects];
    [mQueryButton setTitle:LS(@"QUERY") forState:UIControlStateNormal];
    [mUpdateButton setTitle:LS(@"UPDATE") forState:UIControlStateNormal];
    [self updateControlStates];
}

@end
