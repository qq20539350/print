//
//  FBUpdateListViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 5/3/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBUpdateListViewController.h"
#import "FBPropertiesSettingsViewController.h"
#import "FBTestingSessionViewController.h"
#import "FBDFUSessionViewController.h"
#import "FBUpgradingSessionViewController.h"
#import "FBAuthorizationSessionViewController.h"
#import "FBRefreshControl.h"
#import "FBUpdatingSettingsCell.h"
#import "FBPropertySettings.h"
#import "FBFunctionSettings.h"
#import <CoreBluetooth/CoreBluetooth.h>

@interface FBUpdateListViewController () {
    FBFunctionSettings *mFunctionSettings;
    NSMutableArray *mFilteredPeripheralItems;
    int mConnectedTimes;
}

@end

@implementation FBUpdateListViewController

BOOL mPuaseAutoConnection = NO;

- (id)initWithSettingsMode:(FBSettingMode)mode {
    if (self = [super init]) {
        mSettingMode = mode;
        mFunctionSettings = [FBFunctionSettings sharedInstance];
        
        NSString *formatters[4] = { @"DEFINING_MODE", @"TESTING_MODE", @"AUTHORIZING_MODE", @"UPGRADING_MODE" };
        
        [self setTitle:LS(formatters[mSettingMode])];
        [self setHidesBottomBarWhenPushed:YES];
        
        mFilteredPeripheralItems = [[NSMutableArray alloc] init];
        mFinishedPeripheralItems = [[NSMutableArray alloc] init];
        mFailedPeripheralItems = [[NSMutableArray alloc] init];
        
        NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
        
        [notificationCenter addObserver:self selector:@selector(updateDidFinish:) name:FBPeripheralItemDidFinishUpdateNotification object:nil];
        [notificationCenter addObserver:self selector:@selector(updateDidFail:) name:FBPeripheralItemDidFailUpdateNotification object:nil];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (FBSettingModeFunctionTesting == mSettingMode) {
        [mTableView setAllowsSelection:NO];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [mTableView reloadData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - UITableViewDataSource

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  {
    const NSInteger row = [indexPath row];
    static NSString *CellIdentifier = @"Cell";
    FBUpdatingSettingsCell *cell = (FBUpdatingSettingsCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    UIButton *updateButton;
    
    if (nil == cell) {
        cell = [[FBUpdatingSettingsCell alloc] initWithReuseIdentifier:CellIdentifier];
        updateButton = [cell updateButton];
        [updateButton addTarget:self action:@selector(onUpdate:) forControlEvents:UIControlEventTouchUpInside];
    } else {
        updateButton = [cell updateButton];
    }
    
    if (FBSettingModePropertiesDefining == mSettingMode) {
        [updateButton setHidden:![[FBPropertySettings sharedInstance] isAvailable]];
    }
    
    static NSString *formatters[4] = { @"DEFINE", @"TEST", @"AUTHORIZE", @"ENTER_DFU_MODE" };
    FBPeripheralItem *peripheralItem = mPeripheralItems[row];
    
    [cell setPeripheralItem:peripheralItem];
    [updateButton setTag:row];
    
    if ([mFinishedPeripheralItems containsObject:peripheralItem]) {
        [updateButton setTitle:LS(@"DONE") forState:UIControlStateNormal];
    } else if ([mFailedPeripheralItems containsObject:peripheralItem]) {
        [updateButton setTitle:LS(@"FAILED") forState:UIControlStateNormal];
    } else {
        [updateButton setTitle:LS(formatters[mSettingMode]) forState:UIControlStateNormal];
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UIViewController *viewController = nil;
    
    if (FBSettingModePropertiesDefining == mSettingMode) {
        viewController = [[FBPropertiesSettingsViewController alloc] initWithPeripheralItem:mPeripheralItems[indexPath.row] updateManually:YES];
    } else if (FBSettingModeFunctionTesting == mSettingMode) {
        viewController = [[FBTestingSessionViewController alloc] initWithPeripheralItem:mPeripheralItems[indexPath.row]];
    } else if (FBSettingModeDFUUpgrading == mSettingMode) {
        viewController = [[FBUpgradingSessionViewController alloc] initWithPeripheralItem:mPeripheralItems[indexPath.row]];
    }
    
    if (viewController) {
        mPuaseAutoConnection = NO;
        [[self navigationController] pushViewController:viewController animated:YES];
    } else {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
}

#pragma mark - FBBluetoothBrowserDelegate

- (void)bluetoothBrowser:(FBBluetoothBrowser *)bluetoothBrowser didFindPeripheralItem:(FBPeripheralItem *)peripheralItem {
    if (FBSettingModeFunctionTesting == mSettingMode) {
        if ([mFunctionSettings deviceNameSpecified]) {
            NSString *currentName = [[peripheralItem name] lowercaseString];
            NSString *specifiedName = [[mFunctionSettings deviceName] lowercaseString];
            
            if (![currentName hasPrefix:specifiedName]) {
                [mRefreshControl stopRefreshing:mTableView];
                return;
            }
        }
        if ([mFunctionSettings RSSISpecified] && -[[mFunctionSettings RSSI] intValue] > [peripheralItem RSSI]) {
            if (![mFilteredPeripheralItems containsObject:peripheralItem]) {
                [mFilteredPeripheralItems addObject:peripheralItem];
            }
            [mRefreshControl stopRefreshing:mTableView];
            return;
        }
    }
    [super bluetoothBrowser:bluetoothBrowser didFindPeripheralItem:peripheralItem];
    
    if (FBSettingModeFunctionTesting == mSettingMode && [mFunctionSettings autoConnectionSpecified] && !mPuaseAutoConnection) {
        const NSUInteger row = [mPeripheralItems indexOfObject:peripheralItem];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
        
        [mTableView selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionNone];
        [self tableView:mTableView didSelectRowAtIndexPath:indexPath];
    }
}

- (void)bluetoothBrowser:(FBBluetoothBrowser *)bluetoothBrowser didUpdatePeripheralItems:(NSArray *)peripheralItems {
    if (FBSettingModeFunctionTesting == mSettingMode && [mFunctionSettings RSSISpecified]) {
        NSMutableArray *newPeripheralItems = [[NSMutableArray alloc] init];
        
        [mFilteredPeripheralItems removeAllObjects];
        
        for (FBPeripheralItem *peripheralItem in peripheralItems) {
            if (-[[mFunctionSettings RSSI] intValue] <= [peripheralItem RSSI]) {
                [newPeripheralItems addObject:peripheralItem];
            } else {
                [mFilteredPeripheralItems addObject:peripheralItem];
            }
        }
        peripheralItems = newPeripheralItems;
    }
    
    [super bluetoothBrowser:bluetoothBrowser didUpdatePeripheralItems:peripheralItems];
    
    if (FBSettingModeFunctionTesting == mSettingMode && [mFunctionSettings autoConnectionSpecified] && !mPuaseAutoConnection && 0 < [peripheralItems count]) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
        
        [mTableView selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionNone];
        [self tableView:mTableView didSelectRowAtIndexPath:indexPath];
    }
}

#pragma mark - Actions

- (void)onUpdate:(UIButton *)sender {
    UIViewController *viewController = nil;
    
    if (FBSettingModePropertiesDefining == mSettingMode) {
        viewController = [[FBPropertiesSettingsViewController alloc] initWithPeripheralItem:mPeripheralItems[sender.tag] updateManually:NO];
    } else if (FBSettingModeFunctionTesting == mSettingMode) {
        viewController = [[FBTestingSessionViewController alloc] initWithPeripheralItem:mPeripheralItems[sender.tag]];
    } else if (FBSettingModeDFUUpgrading == mSettingMode) {
        viewController = [[FBDFUSessionViewController alloc] initWithPeripheralItem:mPeripheralItems[sender.tag]];
    } else if (FBSettingModeProductionAuthorizing == mSettingMode) {
        NSArray *paths = [[NSFileManager defaultManager] subpathsAtPath:FSDocumentsDirectory];
        NSString *licensePath = nil;
        
        DLog(@"paths:\n%@", paths);
        
        for (NSString *path in paths) {
            if ([[path lastPathComponent] hasPrefix:@"Feasycom_License_"]) {
                if (nil == licensePath) {
                    licensePath = path;
                } else {
                    ALERT(@"存在多个授权文件", nil);
                    return;
                }
            }
        }
        
        if (licensePath) {
            viewController = [[FBAuthorizationSessionViewController alloc] initWithPeripheralItem:mPeripheralItems[sender.tag] license:[[NSString alloc] initWithContentsOfFile:licensePath encoding:NSUTF8StringEncoding error:NULL]];
        } else {
            ALERT(@"未找到授权文件", nil);
        }
    }
    
    if (viewController) {
        mPuaseAutoConnection = NO;
        [[self navigationController] pushViewController:viewController animated:YES];
    }
}

- (void)reloadData {
    if (FBSettingModeFunctionTesting == mSettingMode && [mFunctionSettings RSSISpecified]) {
        DLog(@"mPeripheralItems:\n%@", mPeripheralItems);
        NSMutableArray *newPeripheralItems = [[NSMutableArray alloc] init];
        
        for (FBPeripheralItem *peripheralItem in mPeripheralItems) {
            if (-[[mFunctionSettings RSSI] intValue] <= [peripheralItem RSSI]) {
                if (![newPeripheralItems containsObject:peripheralItem]) {
                    [newPeripheralItems addObject:peripheralItem];
                }
            }
        }
        for (FBPeripheralItem *peripheralItem in mFilteredPeripheralItems) {
            if (-[[mFunctionSettings RSSI] intValue] <= [peripheralItem RSSI]) {
                if (![newPeripheralItems containsObject:peripheralItem]) {
                    [newPeripheralItems addObject:peripheralItem];
                }
            }
        }
        
        mPeripheralItems = newPeripheralItems;
        DLog(@"newPeripheralItems:\n%@", newPeripheralItems);
    }
    [mTableView reloadData];
}

- (void)updateDidFinish:(NSNotification *)notification {
    FBPeripheralITem *peripheralItem = [notification object];
    
    if ([mPeripheralItems containsObject:peripheralItem] && ![mFinishedPeripheralItems containsObject:peripheralItem]) {
        [mFinishedPeripheralItems addObject:peripheralItem];
        [mTableView reloadData];
    }
}

- (void)updateDidFail:(NSNotification *)notification {
    FBPeripheralITem *peripheralItem = [notification object];
    
    if ([mPeripheralItems containsObject:peripheralItem] && ![mFailedPeripheralItems containsObject:peripheralItem]) {
        [mFailedPeripheralItems addObject:peripheralItem];
        [mTableView reloadData];
    }
}

@end
