//
//  FBTestingSessionViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 6/23/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBSessionViewController.h"

@interface FBTestingSessionViewController : FBSessionViewController

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem;

@end
