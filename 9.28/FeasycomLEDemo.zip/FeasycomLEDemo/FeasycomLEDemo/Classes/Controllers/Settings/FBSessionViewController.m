//
//  FBSessionViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 6/22/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBSessionViewController.h"
#import "FBReportView.h"

@interface FBSessionViewController () {
    FBReportView *mReportView;
    FBSessionMode mSessionMode;
    CGFloat mReportHeight;
}

@end

@implementation FBSessionViewController

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem sessionMode:(FBSessionMode)sessionMode reportHeight:(CGFloat)reportHeight {
    if (self = [super init]) {
        [self setHidesBottomBarWhenPushed:YES];
        mSession = [[FBSession alloc] initWithPeripheralItem:peripheralItem];
        mSessionMode = sessionMode;
//        mSessionMode = FBSessionModeUnsafe;
        mReportHeight = reportHeight;
        
        DLog(@"mSession mode: %d", mSessionMode);
        DLog(@"[mSession peripheralItem]: %@", [mSession peripheralItem]);
        
        [mSession setDelegate:self];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (nil == mReportView) {
        mReportView = UI(FBReportView, RECT(0, kScreenHeight - kDefaultStatusBarHeight - kNavBarHeight - mReportHeight, kScreenWidth, mReportHeight));
    }
    [[self view] addSubview:mReportView];
    DLog(@"mSession: %@", mSession);
    DLog(@"[mSession peripheralItem]: %@", [mSession peripheralItem]);
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    DLog(@"mSession: %@", mSession);
    DLog(@"[mSession peripheralItem]: %@", [mSession peripheralItem]);
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [mSession setDelegate:nil];
    [mSession close];
}

- (void)dealloc {
    [mSession setDelegate:nil];
    [mSession close];
}

#pragma mrak - FBSessionDelegate

- (void)sessionDidFinishAuthorizing:(FBSession *)session {
    NSString *title = LS(@"AUTHORIZATION_SUCCEEDED");
    
    if (FBSessionModeUnsafe < mSessionMode) {
        [mReportView appendDescription:title];
        [self stopWaitingWithTitle:title];
    } else {
        [self stopWaiting];
    }
}

- (void)sessionAuthorizingDidTimeout:(FBSession *)session {
    [mSession close];
    if (FBSessionModeUnsafe < mSessionMode) {
        NSString *title = LS(@"AUTHORIZATION_TIMEOUT");
        
        [mReportView appendDescription:title];
        [self stopWaitingWithTitle:title];
    } else {
        [self stopWaiting];
    }
}

- (void)session:(FBSession *)session authorizationDidFailWithError:(NSError *)error {
    if (FBSessionModeUnsafe < mSessionMode) {
        NSString *title = LS(@"AUTHORIZATION_FAILED");
        NSString *reason = [error localizedFailureReason];
        
        [mReportView appendDescription:[NSString stringWithFormat:@"%@。%@", title, reason]];
        [self stopWaitingWithTitle:title];
    } else {
        [self stopWaiting];
    }
    [mSession performSelector:@selector(close) withObject:nil afterDelay:1.5];
}

- (void)sessionDidOpen:(FBSession *)session {
    if (FBSessionModeUnsafe < mSessionMode) {
        [mReportView appendDescription:@"正在验证..."];
    }
    [mSession authorizeWithMode:mSessionMode timeoutInterval:kTimeoutInterval];
}

- (void)sessionDidClose:(FBSession *)session error:(NSError *)error {
    UINavigationController *navigationController = [self navigationController];
    
    if ([navigationController topViewController] == self) {
        [navigationController popViewControllerAnimated:YES];
    }
    [self stopWaiting];
}

- (void)session:(FBSession *)session didReceiveResponse:(FBResponse *)response forRequest:(FBPacket *)request {
    
}

- (void)session:(FBSession *)session requestDidTimeout:(FBPacket *)request {
    
}

- (void)session:(FBSession *)session requestDidFail:(FBPacket *)request error:(NSError *)error {
    
}

- (void)session:(FBSession *)session didFailToWriteWithError:(NSError *)error {
    
}

- (void)session:(FBSession *)session didReceiveData:(NSData *)data {
    
}

#pragma mrak - Actions

- (void)appendReport:(NSString *)report {
    [mReportView appendDescription:report];
}

- (void)appendReport:(NSString *)report font:(UIFont *)font textColor:(UIColor *)textColor {
    [mReportView appendDescription:report font:font textColor:textColor];
}

- (void)quit {
    [self stopWaiting];
    
    UINavigationController *navigationController = [self navigationController];
    
    if ([navigationController topViewController] == self) {
        [navigationController popViewControllerAnimated:YES];
    }
}

- (void)clearReport {
    [mReportView clear];
}

@end
