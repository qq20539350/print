//
//  FBDFUSessionViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 6/22/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBDFUSessionViewController.h"

@implementation FBDFUSessionViewController

#pragma mrak - FBSessionDelegate

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem {
    if (self = [super initWithPeripheralItem:peripheralItem sessionMode:FBSessionModeSettings reportHeight:(kScreenHeight - kDefaultStatusBarHeight - kNavBarHeight)]) {
        [self setTitle:LS(@"ENTER_DFU_MODE")];
        [self setHidesBottomBarWhenPushed:YES];
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if ([[mSession peripheralItem] connect]) {
        [self startWaiting];
    }
}

- (void)sessionDidFinishAuthorizing:(FBSession *)session {
    [super sessionDidFinishAuthorizing:session];
    
    [self appendReport:@"正在切换DFU模式..."];
    FBPacket *packet = [[FBPacket alloc] initWithID:0x08];
    
    [packet beginEncoding];
    [packet encodeInt8:0x00];
    [packet endEncoding];
    
    [mSession sendPacket:packet timeoutInterval:kTimeoutInterval];
}

- (void)session:(FBSession *)session didReceiveResponse:(FBResponse *)response forRequest:(FBPacket *)request {
    const UInt8 code = [response responseID];
    
    if (0x08 == code) {
        if (0 == [response statusCode]) {
            NSString *title = @"设备成功切换DFU模式";
            
            [self appendReport:title];
            [self performSelector:@selector(quit) withObject:nil afterDelay:1.8];
        } else {
            NSString *title = [NSString stringWithFormat:@"设备切换DFU模式失败(status=%d)", (int)[response statusCode]];
            
            [self appendReport:title];
        }
    }
}

@end
