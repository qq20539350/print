//
//  FBFileBrowserViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 3/23/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBFileBrowserViewController.h"
#import "FBFileItemCell.h"
#import "FBFileItem.h"
#import "FBUpgradingSettings.h"

#define refresh() { [mFileItem clearSubitems]; [mTableView reloadData]; }

NSString * const FBFileBrowserDidChooseFileNotification = @"FBFileBrowserDidChooseFileNotification";

@interface FBFileBrowserViewController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *mTableView;
    FBFileItem *mFileItem;
    NSIndexPath *mSelectedIndexPath;
}

@end

@implementation FBFileBrowserViewController

@synthesize fileItem = mFileItem;
@synthesize delegate = mDelegate;

- (id)initWithFileItem:(FBFileItem *)fileItem {
    if (self = [super init]) {
        if (nil == fileItem) {
            return nil;
        }
        
        mFileItem = fileItem;
        
        UIBarButtonItem *doneItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(onDone)];
        
        [doneItem setEnabled:NO];
        [[self navigationItem] setRightBarButtonItem:doneItem];
        
        UIBarButtonItem *flexibleItem, *tempItem;
        
        flexibleItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:NULL];
        
        NSMutableArray *toolbarItems = [[NSMutableArray alloc] initWithCapacity:2];
        
#define ADD_SYSTEM_ITEM(systemItem, method) {\
tempItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:systemItem target:self action:@selector(method)]; \
[toolbarItems addObject:tempItem]; }
        
        [toolbarItems addObject:flexibleItem];
        ADD_SYSTEM_ITEM(UIBarButtonSystemItemRefresh, refresh);
        
        [self setTitle:[mFileItem fileName]];
        [self setToolbarItems:toolbarItems];
    }
    return self;
}

- (id)init {
    FBFileItem *fileItem = [[FBFileItem alloc] initWithPath:FSDocumentsDirectory];
    
    if (self = [self initWithFileItem:fileItem]) {
        UIBarButtonItem *cancelItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(onCancel)];
        
        [[self navigationItem] setLeftBarButtonItem:cancelItem];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *view = [self view];
    
    if (nil == mTableView) {
        mTableView = [[UITableView alloc] initWithFrame:[view bounds] style:UITableViewStylePlain];
        [mTableView setDataSource:self];
        [mTableView setDelegate:self];
        [mTableView setRowHeight:54];
        [mTableView setAllowsMultipleSelection:NO];
        [mTableView setAllowsSelectionDuringEditing:YES];
    }
    
    [view addSubview:mTableView];
}

- (void)releaseUI {
    mTableView = nil;
}

- (void)deselect:(BOOL)animated {
    NSIndexPath *selectedIndexPath = [mTableView indexPathForSelectedRow];
    
    if (selectedIndexPath) {
        [mTableView deselectRowAtIndexPath:selectedIndexPath animated:animated];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [self deselect:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[mFileItem subitems] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"FBFileItemCell";
    FBFileItemCell *cell = (FBFileItemCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (nil == cell) {
        cell = [[FBFileItemCell alloc] initWithReuseIdentifier:CellIdentifier];
    }
    
    [cell setFileItem:[[mFileItem subitems] objectAtIndex:[indexPath row]]];
    [cell setAccessoryType:([mSelectedIndexPath isEqual:indexPath] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone)];
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    FBFileItem *fileItem = [[mFileItem subitems] objectAtIndex:[indexPath row]];
    
    if (mSelectedIndexPath) {
        [[mTableView cellForRowAtIndexPath:mSelectedIndexPath] setAccessoryType:UITableViewCellAccessoryNone];
        mSelectedIndexPath = nil;
    }
    
    if ([fileItem isDirectory]) {
        FBFileBrowserViewController *viewController = [[FBFileBrowserViewController alloc] initWithFileItem:fileItem];
        
        [viewController setDelegate:mDelegate];
        
        [[self navigationController] pushViewController:viewController animated:YES];
    } else {
        mSelectedIndexPath = indexPath;
        [[mTableView cellForRowAtIndexPath:mSelectedIndexPath] setAccessoryType:UITableViewCellAccessoryCheckmark];
        [mTableView deselectRowAtIndexPath:indexPath animated:YES];
    }
    
    [[[self navigationItem] rightBarButtonItem] setEnabled:(nil != mSelectedIndexPath)];
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleNone;
}

#pragma mark -

- (void)refresh {
    [mFileItem clearSubitems];
    [mTableView reloadData];
}

- (void)onDone {
    if (mSelectedIndexPath) {
        FBFileItem *fileItem = [[mFileItem subitems] objectAtIndex:[mSelectedIndexPath row]];
        
        [mDelegate fileBrowserViewController:self didSelectFileAtPath:[fileItem path]];
        
        DLog(@"FILE_PATH: %@", [fileItem path]);
        /*
        FBUpgradingSettings *settings = [FBUpgradingSettings sharedInstance];
        
        [settings setFirmwarePath:[fileItem path]];
        [settings save];*/
    }
    [[self navigationController] dismissViewControllerAnimated:YES completion:NULL];
}

- (void)onCancel {
    [[self navigationController] dismissViewControllerAnimated:YES completion:NULL];
}

@end

