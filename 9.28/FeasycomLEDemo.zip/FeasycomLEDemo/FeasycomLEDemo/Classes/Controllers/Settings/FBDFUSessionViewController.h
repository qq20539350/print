//
//  FBDFUSessionViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 6/22/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBSessionViewController.h"

@interface FBDFUSessionViewController : FBSessionViewController

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem;

@end
