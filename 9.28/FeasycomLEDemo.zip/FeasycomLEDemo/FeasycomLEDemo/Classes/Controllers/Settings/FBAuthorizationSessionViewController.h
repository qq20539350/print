//
//  FBAuthorizationSessionViewController.h
//  FeasycomLEDemo
//
//  Created by LIDONG on 7/29/15.
//  Copyright (c) 2015 Feasycom. All rights reserved.
//

#import "FBSessionViewController.h"

@interface FBAuthorizationSessionViewController : FBSessionViewController

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem license:(NSString *)license;

@end
