//
//  FBUpgradingSettingsViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 3/28/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBUpgradingSettingsViewController.h"
#import "FBFileBrowserViewController.h"
#import "FBUpdateListViewController.h"
#import "FBUpgradingSettings.h"

@interface FBUpgradingSettingsViewController () <UITextFieldDelegate, UIPickerViewDataSource, UIPickerViewDelegate, FBFileBrowserViewControllerDelegate> {
    UIView *mContentView;
    UITextField *mFrameSizeTextField;
    UITextField *mRetryTimeTextField;
    UITextField *mRetryDurationTextField;
    UITextField *mPasswordTextField;
    UIPickerView *mPickerView;
    UILabel *mFileNameLabel;
    UIButton *mBrowserButton;
    UIBarButtonItem *mStartItem;
    NSString *mSelectedPath;
}

@end

@implementation FBUpgradingSettingsViewController

static UITextField* UITextFieldCreate(CGRect frame, id<UITextFieldDelegate> delegate) {
    UITextField *textField = [[UITextField alloc] initWithFrame:frame];
    
    [textField setBackgroundColor:UIColorWhite];
    [textField setTextColor:UIColorMainText];
    [textField setDelegate:delegate];
    [textField setBorderStyle:UITextBorderStyleRoundedRect];
    [textField setTextAlignment:NSTextAlignmentLeft];
    [textField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [textField setContentHorizontalAlignment:UIControlContentHorizontalAlignmentCenter];
    [textField setFont:UIFont16];
    [textField setKeyboardAppearance:UIKeyboardAppearanceDefault];
    [textField setKeyboardType:UIKeyboardTypeNumberPad];
    [textField setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [textField setAutocorrectionType:UITextAutocorrectionTypeNo];
    [textField setReturnKeyType:UIReturnKeyDone];
    [textField setClearButtonMode:UITextFieldViewModeWhileEditing];
    
    return textField;
}

static UILabel *UILabelCreate(CGRect frame, NSString *text) {
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    
    [label setTextAlignment:NSTextAlignmentRight];
    [label setBackgroundColor:UIColorClear];
    [label setTextColor:UIColorMainText];
    [label setFont:UIFont16];
    [label setText:text];
    
    return label;
}

- (id)init {
    if (self = [super init]) {
        [self setTitle:LS(@"UPGRADING_SETTINGS")];
        [self setHidesBottomBarWhenPushed:YES];
        
        mSelectedPath = [[FBUpgradingSettings sharedInstance] firmwarePath];
        
        UINavigationItem *navgationItem = [self navigationItem];
        
        mStartItem = [[UIBarButtonItem alloc] initWithTitle:LS(@"START") style:UIBarButtonItemStylePlain target:self action:@selector(onDone)];
        
        [navgationItem setRightBarButtonItem:mStartItem];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *view = [self view];
    
    if (nil == mContentView) {
        mContentView = [[UIView alloc] initWithFrame:[view bounds]];
        [mContentView setBackgroundColor:[UIColor lightGrayColor]];
        [mContentView setAutoresizesSubviews:NO];
        
        [mContentView addSubview:UILabelCreate(RECT(10, 21, 120, 20), @"数据帧长(字节):")];
        [mContentView addSubview:UILabelCreate(RECT(10, 63, 120, 20), @"联机次数:")];
        [mContentView addSubview:UILabelCreate(RECT(10, 105, 120, 20), @"重试周期(ms):")];
//        [mContentView addSubview:UILabelCreate(RECT(10, 146, 120, 20), @"随机密码HEX:")];
        
        const CGFloat textFieldWidth = kScreenWidth - 150;
        
        mFrameSizeTextField = UITextFieldCreate(RECT(140, 15, textFieldWidth, 32), self);
        mRetryTimeTextField = UITextFieldCreate(RECT(140, 57, textFieldWidth, 32), self);
        mRetryDurationTextField = UITextFieldCreate(RECT(140, 99, textFieldWidth, 32), self);
//        mPasswordTextField = UITextFieldCreate(RECT(140, 141, textFieldWidth, 32), self);
        
        mPickerView = [[UIPickerView alloc] initWithFrame:RECT(0, 0, kScreenWidth, 216)];
        [mPickerView setShowsSelectionIndicator:YES];
        [mPickerView setDataSource:self];
        [mPickerView setDelegate:self];
        
        [mFrameSizeTextField setInputView:mPickerView];
        
//        [mPasswordTextField setText:@"43"];
        //        [mPasswordTextField setEnabled:NO];
        
        mFileNameLabel = [[UILabel alloc] initWithFrame:RECT(20, 203, kScreenWidth - 40, 20)];
        [mFileNameLabel setTextAlignment:NSTextAlignmentCenter];
        [mFileNameLabel setTextColor:UIColorMainText];
        [mFileNameLabel setAdjustsFontSizeToFitWidth:YES];
        [mFileNameLabel setMinimumScaleFactor:0.75];
        [mFileNameLabel setFont:UIFont16];
        
        mBrowserButton = [[UIButton alloc] initWithFrame:RECT(20, 233, kScreenWidth - 40, 32)];
        [mBrowserButton setBackgroundImage:[[UIImage imageNamed:@"button.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(16, 16, 16, 16)] forState:UIControlStateNormal];
        [mBrowserButton.titleLabel setFont:UIFontBold16];
        [mBrowserButton setTitleColor:UIColorMainText forState:UIControlStateNormal];
        [mBrowserButton setTitle:@"选择固件" forState:UIControlStateNormal];
        [mBrowserButton addTarget:self action:@selector(onBrowser) forControlEvents:UIControlEventTouchUpInside];
        
        [mContentView addSubview:mFrameSizeTextField];
        [mContentView addSubview:mRetryTimeTextField];
        [mContentView addSubview:mRetryDurationTextField];
        //        [mContentView addSubview:mPasswordTextField];
        [mContentView addSubview:mFileNameLabel];
        [mContentView addSubview:mBrowserButton];
    }
    
    FBUpgradingSettings *settings = [FBUpgradingSettings sharedInstance];
    
    [mFrameSizeTextField setText:[NSString stringWithFormat:@"%d", (int)[settings frameSize]]];
    [mRetryTimeTextField setText:[NSString stringWithFormat:@"%d", (int)[settings retryTimes]]];
    [mRetryDurationTextField setText:[NSString stringWithFormat:@"%d", (int)[settings retryDuration]]];
    
    mSelectedPath = [settings firmwarePath];
    
    [mFileNameLabel setText:[mSelectedPath lastPathComponent]];
    
    [view addSubview:mContentView];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return 2;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    if (0 == component) {
        return 120.f;
    }
    return 0.f;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (1 == row) {
        return @"1024";
    }
    return @"128";
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    [mFrameSizeTextField setText:((1 == row) ? @"1024" : @"128")];
}


#pragma mark - FBFileBrowserViewControllerDelegate

- (void)fileBrowserViewController:(FBFileBrowserViewController *)viewController didSelectFileAtPath:(NSString *)path {
    if ([NSMainFileManager fileExistsAtPath:path]) {
        mSelectedPath = path;
    } else {
        mSelectedPath = nil;
    }
    [mFileNameLabel setText:[mSelectedPath lastPathComponent]];
}

#pragma mark - Actions

- (void)onBrowser {
    FBFileBrowserViewController *viewController = [[FBFileBrowserViewController alloc] init];
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewController];
    
    [viewController setDelegate:self];
    [[self navigationController] presentViewController:navController animated:YES completion:NULL];
}

- (void)onCancel {
    [[self navigationController] dismissViewControllerAnimated:YES completion:NULL];
}

- (void)onDone {
    if (mSelectedPath && [NSMainFileManager fileExistsAtPath:mSelectedPath]) {
        FBUpgradingSettings *settings = [FBUpgradingSettings sharedInstance];
        
        [settings setFrameSize:[[mFrameSizeTextField text] integerValue]];
        [settings setRetryTimes:[[mRetryTimeTextField text] integerValue]];
        [settings setRetryDuration:[[mRetryDurationTextField text] integerValue]];
        [settings setFirmwarePath:mSelectedPath];
        [settings save];
        
        FBUpdateListViewController *viewController = [[FBUpdateListViewController alloc] initWithSettingsMode:FBSettingModeDFUUpgrading];
        
        [[self navigationController] pushViewController:viewController animated:YES];
    } else {
        ALERT(@"请选择升级所需要的固件", nil);
    }
}

@end
