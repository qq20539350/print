//
//  FBFunctionSettingsViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 5/12/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBFunctionSettingsViewController.h"
#import "FBUpdateListViewController.h"
#import "FBTextInputCell.h"
#import "FBSwitchCell.h"
#import "FBSubTextInputCell.h"
#import "FBDetectingView.h"
#import "FBFunctionSettings.h"


typedef enum __PropertyTag {
    kFunctionTagNameSpecified,
    kFunctionTagUUIDSpecified,
    kFunctionTagServiceUUID,
    kFunctionTagNotifyUUID,
    kFunctionTagWriteUUID,
    kFunctionTagWriteData,
    kFunctionTagReadData,
    kFunctionTagRSSI,
    kFunctionTagAutoConnection,
    kNumberOfTags
} PropertyTag;


#define kCellHeight 44


@interface FBFunctionSettingsViewController () <UITextFieldDelegate> {
    UIScrollView *mScrollView;
    NSMutableArray *mTextFields;
    NSMutableArray *mSwitchs;
    UIBarButtonItem *mStartItem;
    id mActiveTextField;
    CGFloat mContentHeight;
    CGFloat mKeyboardHeight;
    FBFunctionSettings *mFunctionSettings;
}

@end

@implementation FBFunctionSettingsViewController

static NSString * const titleKeys[kNumberOfTags] = { @"DEVICE_NAME_SPECIFIED", @"UUID_SPECIFIED", @"SERVICE_UUID", @"NOTIFY_UUID", @"WRITE_UUID", @"SENDING_DATA", @"RECEIVING_DATA", @"RSSI_PROMPT", @"AUTO_CONNECTION" };

- (id)init {
    self = [super init];
    if (self) {
        NSString *title = LS(@"FUNCTION_TESTING");
        
        [self setTitle:title];
        [self setHidesBottomBarWhenPushed:YES];
        
        UITabBarItem *tabBarItem = [[UITabBarItem alloc] initWithTabBarSystemItem:UITabBarSystemItemFavorites tag:2];
        
        [tabBarItem setTitle:title];
        //        [self setTabBarItem:tabBarItem];
        
        mFunctionSettings = [FBFunctionSettings sharedInstance];
        
        mContentHeight = 0.f;
        mKeyboardHeight = kDefaultKeyboardHeight;
        
        mStartItem = [[UIBarButtonItem alloc] initWithTitle:LS(@"START") style:UIBarButtonItemStylePlain target:self action:@selector(onStart)];
        
        [[self navigationItem] setRightBarButtonItem:mStartItem];
        
        mTextFields = [[NSMutableArray alloc] initWithCapacity:7];
        mSwitchs = [[NSMutableArray alloc] init];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:@"UIKeyboardWillChangeFrameNotification" object:nil];
    }
    return self;
}

- (NSUInteger)indexOfString:(NSString *)value inArray:(NSString * const __unsafe_unretained *)anArray count:(NSUInteger)count {
    for (NSUInteger i = 0; i < count; ++ i){
        if ([value isEqualToString:anArray[i]]) {
            return i;
        }
    }
    return 0;
}

- (FBTextInputCell *)addTextInputCellWithKeyboardType:(UIKeyboardType)keyboardType returnKeyType:(UIReturnKeyType)returnKeyType tag:(NSUInteger)tag {
    FBTextInputCell *cell = [[FBTextInputCell alloc] initWithFrame:RECT(0, mContentHeight, kScreenWidth, kCellHeight)];
    
    [[cell titleLabel] setText:LS(titleKeys[tag])];
    
    UITextField *textField = [cell textField];
    
    [textField setKeyboardType:keyboardType];
    [textField setReturnKeyType:returnKeyType];
    [textField setTag:tag];
    [textField setDelegate:self];
    
    [mTextFields addObject:textField];
    
    UISwitch *settingSwitch = [cell settingSwitch];
    
    [settingSwitch setTag:tag];
    [settingSwitch addTarget:self action:@selector(onValueChanged:) forControlEvents:UIControlEventValueChanged];
    [mSwitchs addObject:settingSwitch];
    
    [mScrollView addSubview:cell];
    
#define TEXT(x) [NSString stringWithFormat:@"%d", x]
    
    if (kFunctionTagNameSpecified == tag) {
        [textField setText:[mFunctionSettings deviceName]];
        [settingSwitch setOn:[mFunctionSettings deviceNameSpecified]];
    } else if (kFunctionTagWriteData == tag) {
        [textField setText:[mFunctionSettings writeData]];
        [settingSwitch setOn:[mFunctionSettings writeDataSpecified]];
    } else if (kFunctionTagReadData == tag) {
        [textField setText:[mFunctionSettings readData]];
        [settingSwitch setOn:[mFunctionSettings readDataSpecified]];
    } else if (kFunctionTagRSSI == tag) {
        [textField setText:[mFunctionSettings RSSI]];
        [settingSwitch setOn:[mFunctionSettings RSSISpecified]];
    }
    [textField setEnabled:[settingSwitch isOn]];
    mContentHeight += kCellHeight;
    
    return cell;
}

- (FBSubTextInputCell *)addTextSubInputCellWithKeyboardType:(UIKeyboardType)keyboardType returnKeyType:(UIReturnKeyType)returnKeyType tag:(NSUInteger)tag {
    FBSubTextInputCell *cell = [[FBSubTextInputCell alloc] initWithFrame:RECT(0, mContentHeight, kScreenWidth, kCellHeight)];
    
    [[cell titleLabel] setText:LS(titleKeys[tag])];
    
    UITextField *textField = [cell textField];
    
    [textField setKeyboardType:keyboardType];
    [textField setReturnKeyType:returnKeyType];
    [textField setTag:tag];
    [textField setDelegate:self];
    
    [mTextFields addObject:textField];
    [mScrollView addSubview:cell];
    
#define TEXT(x) [NSString stringWithFormat:@"%d", x]
    
    if (kFunctionTagServiceUUID == tag) {
        [textField setText:[mFunctionSettings serviceUUID]];
    } else if (kFunctionTagNotifyUUID == tag) {
        [textField setText:[mFunctionSettings notifyUUID]];
    } else if (kFunctionTagWriteUUID == tag) {
        [textField setText:[mFunctionSettings writeUUID]];
    }
    [textField setEnabled:[mFunctionSettings UUIDSpecified]];
    mContentHeight += kCellHeight;
    
    return cell;
}

- (FBSwitchCell *)addSwitchCellWithTag:(NSUInteger)tag {
    FBSwitchCell *cell = [[FBSwitchCell alloc] initWithFrame:RECT(0, mContentHeight, kScreenWidth, kCellHeight)];
    UILabel *titleLabel = [cell titleLabel];
    
    [titleLabel setFont:UIFont14];
    [titleLabel setTextColor:UIColorMainText];
    [titleLabel setText:LS(titleKeys[tag])];
    
    UISwitch *settingSwitch = [cell settingSwitch];
    
    [settingSwitch setTag:tag];
    [settingSwitch addTarget:self action:@selector(onValueChanged:) forControlEvents:UIControlEventValueChanged];
    [mSwitchs addObject:settingSwitch];
    
    if (kFunctionTagUUIDSpecified == tag) {
        [settingSwitch setOn:[mFunctionSettings UUIDSpecified]];
    } else if (kFunctionTagAutoConnection == tag) {
        [settingSwitch setOn:[mFunctionSettings autoConnectionSpecified]];
    }
    [mScrollView addSubview:cell];
    
    mContentHeight += kCellHeight;
    
    return cell;
}

- (void)addSeparator {
    UIView *separatorView = [[UIView alloc] initWithFrame:RECT(0, mContentHeight, kScreenWidth, 1)];
    
    [separatorView setBackgroundColor:UIColorSeparator];
    
    mContentHeight += 1;
    
    [mScrollView addSubview:separatorView];
}

- (UITextField *)textFieldForTag:(NSUInteger)tag {
    for (UITextField *textField in mTextFields) {
        if ([textField tag] == tag) {
            return textField;
        }
    }
    return nil;
}

- (UISwitch *)switchControlForTag:(NSUInteger)tag {
    for (UISwitch *aSwitch in mSwitchs) {
        if ([aSwitch tag] == tag) {
            return aSwitch;
        }
    }
    return nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *view = [self view];
    
    if (nil == mScrollView) {
        const CGRect frame = [view bounds];
        
        mScrollView = [[UIScrollView alloc] initWithFrame:frame];
        [mScrollView setBackgroundColor:UIColorBackground];
        [mScrollView setDecelerationRate:UIScrollViewDecelerationRateNormal];
        [mScrollView setShowsVerticalScrollIndicator:YES];
        [mScrollView setShowsHorizontalScrollIndicator:NO];
        [mScrollView setPagingEnabled:NO];
        [mScrollView setDirectionalLockEnabled:YES];
        [mScrollView setBounces:YES];
        [mScrollView setAlwaysBounceHorizontal:NO];
        [mScrollView setAlwaysBounceVertical:YES];
        [mScrollView setBouncesZoom:NO];
        [mScrollView setScrollEnabled:YES];
        
        FBTextInputCell *textInputCell;
        
        [self addSeparator];
        [self addTextInputCellWithKeyboardType:UIKeyboardTypeASCIICapable returnKeyType:UIReturnKeyNext tag:kFunctionTagNameSpecified];
        [self addSeparator];
        [self addSwitchCellWithTag:kFunctionTagUUIDSpecified];
        [self addTextSubInputCellWithKeyboardType:UIKeyboardTypeASCIICapable returnKeyType:UIReturnKeyNext tag:kFunctionTagServiceUUID];
        [self addTextSubInputCellWithKeyboardType:UIKeyboardTypeASCIICapable returnKeyType:UIReturnKeyNext tag:kFunctionTagNotifyUUID];
        [self addTextSubInputCellWithKeyboardType:UIKeyboardTypeASCIICapable returnKeyType:UIReturnKeyNext tag:kFunctionTagWriteUUID];
        [self addSeparator];
        [self addTextInputCellWithKeyboardType:UIKeyboardTypeASCIICapable returnKeyType:UIReturnKeyNext tag:kFunctionTagWriteData];
        [self addSeparator];
        [self addTextInputCellWithKeyboardType:UIKeyboardTypeASCIICapable returnKeyType:UIReturnKeyNext tag:kFunctionTagReadData];
        [self addSeparator];
        
        textInputCell = [self addTextInputCellWithKeyboardType:UIKeyboardTypeNumberPad returnKeyType:UIReturnKeyNext tag:kFunctionTagRSSI];
        
        UITextField *textField = [textInputCell textField];
        CGRect textFrame = [textField frame];
        
        UILabel *label = [[UILabel alloc] initWithFrame:RECT(textFrame.origin.x, textFrame.origin.y, 35, textFrame.size.height)];
        
        [label setTextAlignment:NSTextAlignmentRight];
        [label setTextColor:UIColorMainText];
        [label setFont:UIFont14];
        [label setText:@"-"];
        [textInputCell addSubview:label];
        
        textFrame.size.width -= 40;
        textFrame.origin.x += 40;
        
        [textField setFrame:textFrame];
        
        [self addSeparator];
        [self addSwitchCellWithTag:kFunctionTagAutoConnection];
        [self addSeparator];
        
        UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(resignFirstResponder)];
        
        [gestureRecognizer setCancelsTouchesInView:YES];
        [mScrollView addGestureRecognizer:gestureRecognizer];
        [mScrollView setContentSize:SZ(kScreenWidth, mContentHeight)];
    }
    
    [view addSubview:mScrollView];
}

- (void)releaseUI {
    mScrollView = nil;
    [mTextFields removeAllObjects];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self resignFirstResponder];
}

- (void)drawBack {
    const CGRect bounds = [[self view] bounds];
    const CGRect tableFrame = { 0, 0, bounds.size.width, bounds.size.height - mKeyboardHeight };
    
    [mScrollView setFrame:tableFrame];
}

#pragma mark - UITextViewFieldDelegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (nil != [textField inputView]) {
        return NO;
    }
    if (UIKeyboardTypeNumberPad == [textField keyboardType]) {
        if (0 < [string length] && ![string isEqualToString:[NSString stringWithFormat:@"%d", [string intValue]]]) {
            return NO;
        }
    }
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    DLog(@"%s", __PRETTY_FUNCTION__);
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    DLog(@"%s", __PRETTY_FUNCTION__);
    mActiveTextField = textField;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationCurve:NSKeyboardAnimationCurve];
    [UIView setAnimationDuration:NSKeyboardAnimationDuration];
    [self drawBack];
    [mScrollView scrollRectToVisible:[[mActiveTextField superview] frame] animated:NO];
    [UIView commitAnimations];
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    DLog(@"%s", __PRETTY_FUNCTION__);
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField == mActiveTextField) {
        mActiveTextField = nil;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    const NSUInteger nextIndex = [mTextFields indexOfObject:textField] + 1;
    
    if (nextIndex < [mTextFields count]) {
        [mTextFields[nextIndex] becomeFirstResponder];
    } else {
        [self resignFirstResponder];
    }
    return YES;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
//    const NSUInteger tag = [pickerView tag];
    
}

#pragma mark -

- (void)keyboardWillChangeFrame:(NSNotification *)notification {
    NSDictionary *userInfo = [notification userInfo];
    NSNumber *rectNumber = [userInfo objectForKey:@"UIKeyboardBoundsUserInfoKey"];
    
    if (rectNumber) {
        const CGFloat newHeight = rectNumber.CGRectValue.size.height;
        
        if (fabs(newHeight - mKeyboardHeight) >= 0.5f) {
            mKeyboardHeight = newHeight;
            
            if (mActiveTextField) {
                [self drawBack];
                [mScrollView scrollRectToVisible:[[mActiveTextField superview] frame] animated:NO];
            }
        }
    }
}

- (void)onValueChanged:(UISwitch *)sender {
    const NSUInteger tag = [sender tag];
    const BOOL isOn = [sender isOn];
    
    if (kFunctionTagUUIDSpecified == tag) {
        if (isOn) {
            [[self textFieldForTag:kFunctionTagServiceUUID] setEnabled:isOn];
            [[self textFieldForTag:kFunctionTagNotifyUUID] setEnabled:isOn];
            [[self textFieldForTag:kFunctionTagWriteUUID] setEnabled:isOn];
            [[self textFieldForTag:kFunctionTagServiceUUID] becomeFirstResponder];
        } else {
            [self resignFirstResponder];
            [[self textFieldForTag:kFunctionTagServiceUUID] setEnabled:isOn];
            [[self textFieldForTag:kFunctionTagNotifyUUID] setEnabled:isOn];
            [[self textFieldForTag:kFunctionTagWriteUUID] setEnabled:isOn];
        }
    } else if (kFunctionTagAutoConnection != tag) {
        if (isOn) {
            [[self textFieldForTag:tag] setEnabled:isOn];
            [[self textFieldForTag:tag] becomeFirstResponder];
        } else {
            [self resignFirstResponder];
            [[self textFieldForTag:tag] setEnabled:isOn];
        }
    }
}

- (BOOL)resignFirstResponder {
    if (mActiveTextField) {
        UITextField *activeTextField = mActiveTextField;
        CGPoint contentOffset = [mScrollView contentOffset];
        
        mActiveTextField = nil;
        
        [activeTextField resignFirstResponder];
        
        const CGRect tableFrame = [[self view] bounds];
        
        [mScrollView setFrame:tableFrame];
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationCurve:NSKeyboardAnimationCurve];
        [UIView setAnimationDuration:NSKeyboardAnimationDuration];
        
        const CGFloat maxContentOffsetY = mScrollView.contentSize.height - tableFrame.size.height;
        
        if (maxContentOffsetY < contentOffset.y) {
            contentOffset.y = (0 < maxContentOffsetY) ? maxContentOffsetY : 0;
        }
        [mScrollView setContentOffset:contentOffset animated:NO];
        [UIView commitAnimations];
        return YES;
    }
    return NO;
}

- (void)onStart {
    if ([[self switchControlForTag:kFunctionTagNameSpecified] isOn]) {
        [mFunctionSettings setDeviceNameSpecified:YES];
        [mFunctionSettings setDeviceName:[[self textFieldForTag:kFunctionTagNameSpecified] text]];
    } else {
        [mFunctionSettings setDeviceNameSpecified:NO];
    }
    if ([[self switchControlForTag:kFunctionTagUUIDSpecified] isOn]) {
        [mFunctionSettings setUUIDSpecified:YES];
        [mFunctionSettings setServiceUUID:[[self textFieldForTag:kFunctionTagServiceUUID] text]];
        [mFunctionSettings setNotifyUUID:[[self textFieldForTag:kFunctionTagNotifyUUID] text]];
        [mFunctionSettings setWriteUUID:[[self textFieldForTag:kFunctionTagWriteUUID] text]];
    } else {
        [mFunctionSettings setUUIDSpecified:NO];
    }
    if ([[self switchControlForTag:kFunctionTagWriteData] isOn]) {
        [mFunctionSettings setWriteDataSpecified:YES];
        [mFunctionSettings setWriteData:[[self textFieldForTag:kFunctionTagWriteData] text]];
    } else {
        [mFunctionSettings setWriteDataSpecified:NO];
    }
    if ([[self switchControlForTag:kFunctionTagReadData] isOn]) {
        [mFunctionSettings setReadDataSpecified:YES];
        [mFunctionSettings setReadData:[[self textFieldForTag:kFunctionTagReadData] text]];
    } else {
        [mFunctionSettings setReadDataSpecified:NO];
    }
    if ([[self switchControlForTag:kFunctionTagRSSI] isOn]) {
        [mFunctionSettings setRSSISpecified:YES];
        [mFunctionSettings setRSSI:[[self textFieldForTag:kFunctionTagRSSI] text]];
    } else {
        [mFunctionSettings setRSSISpecified:NO];
    }
    
    if ([[self switchControlForTag:kFunctionTagAutoConnection] isOn]) {
        [mFunctionSettings setAutoConnectionSpecified:YES];
    } else {
        [mFunctionSettings setAutoConnectionSpecified:NO];
    }
    
    [mFunctionSettings save];
    
    if ([mFunctionSettings isAvailable]) {
        FBUpdateListViewController *viewController = [[FBUpdateListViewController alloc] initWithSettingsMode:FBSettingModeFunctionTesting];
        
        [[self navigationController] pushViewController:viewController animated:YES];
    } else {
        ALERT(@"请设置测试选项", nil);
    }
}

@end
