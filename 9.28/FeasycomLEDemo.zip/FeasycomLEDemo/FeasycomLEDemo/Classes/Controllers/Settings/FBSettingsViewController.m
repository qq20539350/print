//
//  FBSettingsViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 14-2-24.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import "FBSettingsViewController.h"
#import "FBUpdateListViewController.h"
#import "FBPropertiesSettingsViewController.h"
#import "FBFunctionSettingsViewController.h"
#import "FBUpgradingSettingsViewController.h"

@interface FBSettingsViewController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *mTableView;
}

@end

@implementation FBSettingsViewController

- (id)init {
    self = [super init];
    if (self) {
        NSString *title = LS(@"SETTING");
        
        [self setTitle:title];
        
        UITabBarItem *tabBarItem = [[UITabBarItem alloc] initWithTabBarSystemItem:UITabBarSystemItemFavorites tag:2];
        
        [tabBarItem setTitle:title];
//        [self setTabBarItem:tabBarItem];
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *view = [self view];
    const CGRect frame = [view bounds];
    
    mTableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    [mTableView setDataSource:self];
    [mTableView setDelegate:self];
    [mTableView setRowHeight:85];
    [mTableView setBackgroundColor:UIColorWhite];
    [mTableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    [mTableView setAllowsSelection:YES];
    
    [view addSubview:mTableView];
}

- (void)deselect:(BOOL)animated {
    NSIndexPath *selectedIndexPath = [mTableView indexPathForSelectedRow];
    
    if (selectedIndexPath) {
        [mTableView deselectRowAtIndexPath:selectedIndexPath animated:animated];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self deselect:animated];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  {
    const NSInteger row = [indexPath row];
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    UILabel *textLabel = nil;
    
    if (nil == cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
        [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
        
        textLabel = [cell textLabel];
        [textLabel setTextAlignment:NSTextAlignmentCenter];
        [textLabel setTextColor:UIColorMainText];
        [textLabel setFont:UIFont16];
    } else {
        textLabel = [cell textLabel];
    }
    
    static NSString *keys[4] = { @"PROPERTIES_DEFINING", @"FUNCTION_TESTING", @"PRODUCTION_AUTHORITIES", @"DFU_UPGRADING" };
    
    [textLabel setText:LS(keys[row])];
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    const NSUInteger row = [indexPath row];
    UIViewController *viewController = nil;
    
    if (0 == row) {
        viewController = [[FBUpdateListViewController alloc] initWithSettingsMode:FBSettingModePropertiesDefining];
    } else if (1 == row) {
        viewController = [[FBFunctionSettingsViewController alloc] init];
    } else if (2 == row) {
        viewController = [[FBUpdateListViewController alloc] initWithSettingsMode:FBSettingModeProductionAuthorizing];
    } else if (3 == row) {
        viewController = [[FBUpgradingSettingsViewController alloc] init];
    }
    
    if (viewController) {
        [[self navigationController] pushViewController:viewController animated:YES];
    }
}

@end
