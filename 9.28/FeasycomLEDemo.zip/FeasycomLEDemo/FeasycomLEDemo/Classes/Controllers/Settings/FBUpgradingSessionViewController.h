//
//  FBUpgradingSessionViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 3/27/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBViewController.h"

@class FBPeripheralItem;

@interface FBUpgradingSessionViewController : FBViewController

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem;

@end
