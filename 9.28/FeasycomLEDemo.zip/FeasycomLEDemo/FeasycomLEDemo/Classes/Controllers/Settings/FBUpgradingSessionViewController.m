//
//  FBUpgradingSessionViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 3/27/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBUpgradingSessionViewController.h"
#import "FBFileBrowserViewController.h"
#import "FBUpgradingSettingsViewController.h"
#import "FBUpgradingSettings.h"
#import "crc16.h"
#import <CoreBluetooth/CoreBluetooth.h>


#define SOH  0x01
#define STX  0x02
#define EOT  0x04
#define ACK  0x06
#define NAK  0x15
#define CAN  0x18
#define CTRLZ 0x1A

#define DLY_1S 1000
#define MAXRETRANS 25


@interface FBUpgradingSessionViewController () <FBPeripheralItemDelegate> {
    UIView *mContentView;
    UILabel *mFilePathLabel;
    UIProgressView *mProgressView;
    UILabel *mProgressLabel;
    NSThread *mTransferThread;
    NSMutableData *mCachingData;
    NSMutableData *mWritingData;
    FBPeripheralItem *mPeripheralItem;
    int mReadOffset;
    int mSentBytes;
    int mReceivedBytes;
    int mFileSize;
    int mSentFileBytes;
    int mFrameSize;
    int mRetryTimes;
    int mRetryDuration;
    BOOL mTransfering;
}

@end

@implementation FBUpgradingSessionViewController

- (id)initWithPeripheralItem:(FBPeripheralItem *)peripheralItem {
    if (self = [super init]) {
        [self setTitle:@"升级"];
        [self setHidesBottomBarWhenPushed:YES];
        
        mPeripheralItem = peripheralItem;
        [mPeripheralItem attachDelegate:self];
        
        mCachingData = [[NSMutableData alloc] initWithCapacity:1030];
        mWritingData = [[NSMutableData alloc] initWithCapacity:1030];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if (nil == mContentView) {
        UIColor *clearColor = UIColorClear;
        UIColor *textColor = UIColorMainText;
        const CGFloat contentHeight = kScreenHeight - kDefaultStatusBarHeight - kNavBarHeight;
        
        mContentView = [[UIView alloc] initWithFrame:(CGRect){ 0, 0, kScreenWidth, contentHeight }];
        [mContentView setBackgroundColor:UIColorWhite];
        [mContentView setAutoresizesSubviews:NO];
        
        mFilePathLabel = [[UILabel alloc] initWithFrame:RECT(20, 20, kScreenWidth - 40, 20)];
        [mFilePathLabel setTextAlignment:NSTextAlignmentCenter];
        [mFilePathLabel setBackgroundColor:clearColor];
        [mFilePathLabel setTextColor:textColor];
        [mFilePathLabel setFont:UIFont16];
        [mContentView addSubview:mFilePathLabel];
        
        mProgressView = [[UIProgressView alloc] initWithFrame:RECT(10, 60, kScreenWidth - 20, 15)];
        [mProgressView setHidden:YES];
        [mContentView addSubview:mProgressView];
        
        mProgressLabel = [[UILabel alloc] initWithFrame:RECT(10, 84, kScreenWidth - 20, 40)];
        [mProgressLabel setTextAlignment:NSTextAlignmentCenter];
        [mProgressLabel setBackgroundColor:clearColor];
        [mProgressLabel setTextColor:textColor];
        [mProgressLabel setFont:[UIFont systemFontOfSize:14]];
        [mProgressLabel setNumberOfLines:2];
        [mContentView addSubview:mProgressLabel];
        
        UIView *separatorView = [[UIView alloc] initWithFrame:(CGRect){ 0, contentHeight - 1, kScreenWidth, 1 }];
        
        [separatorView setBackgroundColor:[UIColor colorWithWhite:0.85 alpha:1.f]];
        [mContentView addSubview:separatorView];
    }
    
    [[self view] addSubview:mContentView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    FBUpgradingSettings *settings = [FBUpgradingSettings sharedInstance];
    NSString *filePath = [settings firmwarePath];
    
    if ([filePath length] > 0) {
        [mFilePathLabel setText:[filePath lastPathComponent]];
    } else {
        [mFilePathLabel setText:@""];
    }
    
    mRetryTimes = (int)[settings retryTimes];
    mRetryDuration = (int)[settings retryDuration];
    mFrameSize = (int)[settings frameSize];
    
    if ([mPeripheralItem connect]) {
        [self startWaiting];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [mTransferThread cancel];
}

- (void)dealloc {
    [mPeripheralItem disconnect];
}

- (NSString *)stringFromBytes:(NSInteger)bytes {
    if (1024 * 1024 <= bytes) {
        return [NSString stringWithFormat:@"%.1fMB", (CGFloat)bytes / (CGFloat)(1024 * 1024)];
    } else if (1024 <= bytes) {
        return [NSString stringWithFormat:@"%.1fKB", (CGFloat)bytes / 1024.f];
    }
    return [NSString stringWithFormat:@"%uB", (unsigned)bytes];
}

- (void)updateStatistics {
    const float percent = (float)mSentFileBytes / (float)mFileSize;
    
    [mProgressView setProgress:percent];
    [mProgressLabel setText:[NSString stringWithFormat:@"文件大小：%@  已发送：%@  %d%%\r\n接收：%d", [self stringFromBytes:mFileSize], [self stringFromBytes:mSentFileBytes], (int)(percent * 100.f + 0.5), mReceivedBytes]];
}

- (BOOL)readByte:(unsigned char *)byte timeout:(int)timeout {
    NSUInteger cachingLength = 0;
    
    for (int t = 0; t < timeout; t += 50) {
        @synchronized(mCachingData) {
            cachingLength = [mCachingData length];
        }
        if (cachingLength > mReadOffset) {
            break;
        }
        [NSThread sleepForTimeInterval:0.05];
    }
    
    if (cachingLength > mReadOffset) {
        @synchronized(mCachingData) {
            const unsigned char *bytes = (const unsigned char *)[mCachingData bytes];;
            
            *byte = bytes[mReadOffset ++];
        }
        return YES;
    }
    *byte = -1;
    return NO;
}

- (void)flushInput {
    @synchronized(mCachingData) {
        [mCachingData setLength:0];
    }
    mReadOffset = 0;
}

- (int)sendData {
    const int length = (int)[mWritingData length];
    
    if (0 < length) {
        NSData *data = [mWritingData copy];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            const int length = (int)[data length];
            
            DLog(@"send bytes: %d", (int)length);
            
            const int count = length / 100;
            NSData *subData;
            
            for (int i = 0; i < count; ++ i) {
                subData = [data subdataWithRange:NSMakeRange(i * 100, 100)];
                [mPeripheralItem writeData:subData];
            }
            
            const int offset = count * 100;
            
            if (length - offset > 0) {
                subData = [data subdataWithRange:NSMakeRange(offset, length - offset)];
                [mPeripheralItem writeData:subData];
            }
        });
        
        [mWritingData setLength:0];
        mSentBytes += length;
    }
    return length;
}

#pragma mark -

- (void)peripheralItemDidOpen:(FBPeripheralItem *)peripheralItem {
    if (nil == mTransferThread) {
        mTransferThread = [[NSThread alloc] initWithTarget:self selector:@selector(transferFileAtPath:) object:[[FBUpgradingSettings sharedInstance] firmwarePath]];
        [mTransferThread setThreadPriority:1.f];
        [mTransferThread start];
    }
    [self updateStatistics];
    [self stopWaiting];
}

- (void)peripheralItemDidClose:(FBPeripheralItem *)peripheralItem error:(NSError *)error {
    [self stopWaiting];
    [[self navigationController] popViewControllerAnimated:YES];
}

- (void)peripheralItem:(FBPeripheralItem *)peripheralItem didReceiveData:(NSData *)data {
    mReceivedBytes += [data length];
    [self updateStatistics];
    
    if (mTransferThread && data) {
        @synchronized(mCachingData) {
            [mCachingData appendData:data];
        }
    }
}

- (void)peripheralItemDidWrite:(FBPeripheralItem *)peripheralItem {
    
}

- (void)peripheralItem:(FBPeripheralItem *)peripheralItem didFailToWriteWithError:(NSError *)error {
    
}

- (void)onBrowser {
    FBFileBrowserViewController *viewController = [[FBFileBrowserViewController alloc] init];
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewController];
    
    [[self navigationController] presentViewController:navController animated:YES completion:NULL];
}

- (void)writeByte:(char)byte {
    [mWritingData appendBytes:&byte length:1];
}

- (int)sendBytes:(const char *)src size:(const int)src_size {
    unsigned char xbuff[1030]; /* 1024 for XModem 1k + 3 head chars + 2 crc + nul */
    int crc = -1;
    unsigned char packetno = 1;
    unsigned char c;
    const int retryTimes = mRetryTimes;
    const int retryDuration = mRetryDuration;
    const int frame_size = mFrameSize;
    const unsigned char packet_hdr = (1024 <= frame_size) ? STX : SOH;
    int i, sent_size = 0;
    int retry;
    
    NSThread *currentThread = [NSThread currentThread];
    
    for (;;) {
        for (retry = 0; retry < retryTimes; ++retry) {
            if ([self readByte:&c timeout:retryDuration]) {
                switch (c) {
                    case 'C':
                        crc = 1;
                        goto start_trans;
                    case NAK:
                        crc = 0;
                        goto start_trans;
                    case CAN:
                        if ([self readByte:&c timeout:DLY_1S] && CAN == c) {
                            [self writeByte:ACK];
                            [self sendData];
                            [self flushInput];
                            return -1; /* canceled by remote */
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        [self writeByte:CAN];
        [self writeByte:CAN];
        [self writeByte:CAN];
        [self sendData];
        [self flushInput];
        return -2; /* no sync */
        
        while (true) {
        start_trans:
            if ([currentThread isCancelled]) {
                [self writeByte:CAN];
                [self writeByte:CAN];
                [self writeByte:CAN];
                [self sendData];
                [self flushInput];
                return -6;
            }
            xbuff[0] = packet_hdr;
            xbuff[1] = packetno;
            xbuff[2] = ~packetno;
            
            const int unsent_size = src_size - sent_size;
            const int packet_size = (unsent_size < frame_size) ? unsent_size : frame_size;
            
            if (packet_size >= 0) {
                memset(&xbuff[3], 0, frame_size);
                if (0 == packet_size) {
                    xbuff[3] = CTRLZ;
                } else {
                    memcpy(&xbuff[3], &src[sent_size], packet_size);
                    if (packet_size < frame_size) {
                        xbuff[3+packet_size] = CTRLZ;
                    }
                }
                
                if (crc) {
                    unsigned short ccrc = crc16_ccitt(&xbuff[3], frame_size);
                    
                    DLog(@"ccrc: %d", (int)ccrc);
                    
                    xbuff[frame_size+3] = (ccrc>>8) & 0xFF;
                    xbuff[frame_size+4] = ccrc & 0xFF;
                }
                else {
                    unsigned char ccks = 0;
                    for (i = 3; i < frame_size+3; ++i) {
                        ccks += xbuff[i];
                    }
                    xbuff[frame_size+3] = ccks;
                }
                
                for (retry = 0; retry < MAXRETRANS && ![currentThread isCancelled]; ++retry) {
                    [mWritingData appendBytes:xbuff length:frame_size+4+(crc?1:0)];
                    [self sendData];
                    if ([self readByte:&c timeout:DLY_1S]) {
                        printf("C: %02x", c);
                        switch (c) {
                            case ACK:
                                ++packetno;
                                sent_size += frame_size;
                                if (0 == packet_size || (sent_size - mSentFileBytes) >= 4096) {
                                    mSentFileBytes = (0 == packet_size) ? src_size : sent_size;
                                    [self performSelectorOnMainThread:@selector(updateStatistics) withObject:nil waitUntilDone:NO];
                                }
                                goto start_trans;
                            case CAN:
                                if ([self readByte:&c timeout:DLY_1S] && CAN == c) {
                                    [self writeByte:ACK];
                                    [self sendData];
                                    [self flushInput];
                                    return -1; /* canceled by remote */
                                }
                                break;
                            case NAK:
                                printf("\n src_size: %.02fKB\n sent_size: %.02fKB\n unsent_size: %.02fKB\n frame_size: %dB\n packet_size: %dB\n", (float)src_size / 1024.f, (float)sent_size / 1024.f, (float)unsent_size / 1024.f, frame_size, packet_size);
                            default:
                                break;
                        }
                    }
                }
                DLog(@"end");
                [self writeByte:CAN];
                [self writeByte:CAN];
                [self writeByte:CAN];
                [self sendData];
                [self flushInput];
                return -4; /* xmit error */
            }
            else {
                for (retry = 0; retry < 10; ++ retry) {
                    [self writeByte:EOT];
                    [self sendData];
                    if ([self readByte:&c timeout:((DLY_1S)<<1)] && ACK == c) break;
                }
                [self flushInput];
                return (ACK == c) ? sent_size : -5;
            }
        }
    }
}

- (void)transferFileAtPath:(NSString *)path {
    @autoreleasepool {
        [mCachingData setLength:0];
        [mWritingData setLength:0];
        mReadOffset = 0;
        mSentBytes = 0;
        mSentFileBytes = 0;
        
        NSLog(@"path: %@", path);
        
        NSData *srcData = [[NSData alloc] initWithContentsOfFile:path];
        
        mFileSize = (int)[srcData length];
        
        [self performSelectorOnMainThread:@selector(updateStatistics) withObject:nil waitUntilDone:NO];
        
        const int result = [self sendBytes:[srcData bytes] size:mFileSize];
        
        DLog(@"result: %d", result);
        
        if (result >= mFileSize) {
            [self performSelectorOnMainThread:@selector(transferDidFinish) withObject:nil waitUntilDone:NO];
        } else {
            [self performSelectorOnMainThread:@selector(transferDidAbort) withObject:nil waitUntilDone:NO];
        }
    }
}

- (void)transferDidFinish {
    ALERT(@"UPGRADE_SUCCEEDED", nil);
    mTransferThread = nil;
    [mPeripheralItem disconnect];
}

- (void)transferDidAbort {
    ALERT(@"UPGRADE_FAILED", nil);
    [mProgressView setHidden:YES];
    mTransferThread = nil;
    [mPeripheralItem disconnect];
}

@end
