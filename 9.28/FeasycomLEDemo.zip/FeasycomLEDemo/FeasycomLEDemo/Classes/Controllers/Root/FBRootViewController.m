//
//  FBRootViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 14-2-28.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import "FBRootViewController.h"
#import "FBHomeViewController.h"
#import "FBSettingsViewController.h"
#import "FBAboutViewController.h"

@interface FBRootViewController () {
    
}

@end

@implementation FBRootViewController

- (id)init {
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
	NSMutableArray *viewControllers = [[NSMutableArray alloc] initWithCapacity:5];
	UIViewController *viewController;
	UINavigationController *navController;
    
#define ADD_VIEW_CONTROLLER(ViewControllerClass) do { \
viewController = [[ViewControllerClass alloc] init]; \
navController = [[UINavigationController alloc] initWithRootViewController:viewController]; \
[viewControllers addObject:navController]; \
} while(0)
    
    ADD_VIEW_CONTROLLER(FBHomeViewController);
    ADD_VIEW_CONTROLLER(FBSettingsViewController);
    ADD_VIEW_CONTROLLER(FBAboutViewController);
    
    [self setViewControllers:viewControllers];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return (UIInterfaceOrientationPortrait == toInterfaceOrientation);
}

- (BOOL)shouldAutorotate {
    return NO;
}

- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

@end
