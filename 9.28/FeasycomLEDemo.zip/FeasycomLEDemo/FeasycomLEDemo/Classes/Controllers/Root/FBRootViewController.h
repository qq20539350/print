//
//  FBRootViewController.h
//  FeasycomLE
//
//  Created by LIDONG on 14-2-28.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FBRootViewController : UITabBarController

@end
