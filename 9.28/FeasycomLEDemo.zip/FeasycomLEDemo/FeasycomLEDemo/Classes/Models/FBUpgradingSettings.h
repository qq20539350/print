//
//  FBUpgradingSettings.h
//  FeasycomLE
//
//  Created by LIDONG on 3/27/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "BaseModel.h"

@interface FBUpgradingSettings : BaseModel

@property (nonatomic, assign) NSInteger frameSize;
@property (nonatomic, assign) NSInteger retryTimes;
@property (nonatomic, assign) NSInteger retryDuration;
@property (nonatomic, strong) NSString *firmwarePath;

@end
