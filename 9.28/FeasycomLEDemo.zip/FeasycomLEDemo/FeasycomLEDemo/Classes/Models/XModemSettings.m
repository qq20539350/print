//
//  XModemSettings.m
//  FeasycomWatch
//
//  Created by LIDONG on 3/27/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "XModemSettings.h"

@implementation XModemSettings

@synthesize frameSize = _frameSize;
@synthesize retryTimes = _retryTimes;
@synthesize retryDuration = _retryDuration;
@synthesize filePath = _filePath;

#define kXModemFrameSize        @"XModemFrameSize"
#define kXModemRetryTimes       @"XModemRetryTimes"
#define kXModemRetryDuration    @"XModemRetryDuration"
#define kXModemFilePath         @"XModemFilePath"

static XModemSettings *_sharedInstance = nil;

+ (XModemSettings *)sharedInstance {
    if (nil == _sharedInstance) {
        _sharedInstance = [[XModemSettings alloc] init];
    }
    return _sharedInstance;
}

- (id)init {
    if (self = [super init]) {
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        
        [self setFrameSize:[userDefaults integerForKey:kXModemFrameSize]];
        [self setRetryTimes:[userDefaults integerForKey:kXModemRetryTimes]];
        [self setRetryDuration:[userDefaults integerForKey:kXModemRetryDuration]];
        [self setFilePath:[userDefaults stringForKey:kXModemFilePath]];
    }
    return self;
}

- (void)save {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    [userDefaults setInteger:((1024 == _frameSize) ? 1024 : 128) forKey:kXModemFrameSize];
    [userDefaults setInteger:_retryTimes forKey:kXModemRetryTimes];
    [userDefaults setInteger:_retryDuration forKey:kXModemRetryDuration];
    [userDefaults setObject:_filePath forKey:kXModemFilePath];
    [userDefaults synchronize];
}

- (void)setFrameSize:(NSInteger)frameSize {
    _frameSize = (1024 == frameSize) ? 1024 : 128;
}

- (void)setRetryTimes:(NSInteger)retryTimes {
    _retryTimes = (1 > retryTimes) ? 16 : retryTimes;
}

- (void)setRetryDuration:(NSInteger)retryDuration {
    _retryDuration = (50 <= retryDuration) ? retryDuration : 1000;
}

- (void)setFilePath:(NSString *)filePath {
    _filePath = ([filePath length] > 0) ? filePath : nil;
    DLog(@"SET: %@", _filePath);
}

+ (void)save {
    [_sharedInstance save];
}

@end
