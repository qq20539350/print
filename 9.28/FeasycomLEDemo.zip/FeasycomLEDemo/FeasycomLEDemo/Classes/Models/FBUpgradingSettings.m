//
//  FBUpgradingSettings.m
//  FeasycomLE
//
//  Created by LIDONG on 3/27/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBUpgradingSettings.h"

@implementation FBUpgradingSettings

@synthesize frameSize = _frameSize;
@synthesize retryTimes = _retryTimes;
@synthesize retryDuration = _retryDuration;
@synthesize firmwarePath = _firmwarePath;

- (NSInteger)frameSize {
    return (128 == _frameSize) ? 128 : 1024;
}

- (NSInteger)retryTimes {
    return (8 > _retryTimes) ? 8 : _retryTimes;
}

- (NSInteger)retryDuration {
    return (50 <= _retryDuration) ? _retryDuration : 1000;
}

- (NSString *)firmwarePath {
    return [NSMainFileManager fileExistsAtPath:_firmwarePath] ? _firmwarePath : nil;;
}

- (void)setFrameSize:(NSInteger)frameSize {
    _frameSize = (128 == frameSize) ? 128 : 1024;
}

- (void)setRetryTimes:(NSInteger)retryTimes {
    _retryTimes = (8 > retryTimes) ? 8 : retryTimes;
}

- (void)setRetryDuration:(NSInteger)retryDuration {
    _retryDuration = (50 <= retryDuration) ? retryDuration : 1000;
}

- (void)setFirmwarePath:(NSString *)filePath {
    _firmwarePath = [NSMainFileManager fileExistsAtPath:filePath] ? filePath : nil;
}

@end
