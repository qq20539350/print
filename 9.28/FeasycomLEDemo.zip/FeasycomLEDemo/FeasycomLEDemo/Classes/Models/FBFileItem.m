//
//  FBFileItem.m
//  FeasycomLE
//
//  Created by LIDONG on 3/23/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBFileItem.h"

@implementation FBFileItem

@synthesize path = _path;
@synthesize fileName = _fileName;
@synthesize displayName = _displayName;
@synthesize statistic = _statistic;
@synthesize extension = _extension;
@synthesize creationTime = _creationTime;
@synthesize iconName = _iconName;
@synthesize subitems = _subitems;
@synthesize fileSize = _fileSize;
@dynamic fileCategory;
@dynamic isDirectory;
@dynamic selected;
@dynamic cut;

- (id)initWithParentPath:(NSString *)parentPath fileName:(NSString *)fileName {
    if (self = [super init]) {
        if ([fileName hasPrefix:@"."]) {
            return nil;
        }
        
        _fileName = [fileName copy];
        _path = [parentPath stringByAppendingPathComponent:_fileName];
        
        NSDictionary *attributes = [NSMainFileManager attributesOfItemAtPath:_path error:NULL];
        NSString *fileType = [attributes valueForKey:NSFileType];
        
        _fileSize = [[attributes valueForKey:NSFileSize] doubleValue];
        
        if ([fileType isEqualToString:NSFileTypeRegular]) {
            _extension = [[_fileName pathExtension] lowercaseString];
        } else if ([fileType isEqualToString:NSFileTypeDirectory]) {
            _flags.directory = YES;
            DLog(@"%@\n%@", _fileName, attributes);
            
            if ([_fileName isEqualToString:@"Inbox"]) {
                DLog(@"%@", [NSMainFileManager destinationOfSymbolicLinkAtPath:_path error:NULL]);
            }
        } else {
            return nil;
        }
        
        _fileNumber = (UInt32)[[attributes valueForKey:NSFileSystemFileNumber] unsignedLongValue];
        _creationTime = [NSMainDateFormatter stringFromDate:[attributes valueForKey:NSFileCreationDate]];
    }
    return self;
}

- (id)initWithPath:(NSString *)path {
    NSString *parentPath = [path stringByDeletingLastPathComponent];
    NSString *fileName = [path lastPathComponent];
    
    return [self initWithParentPath:parentPath fileName:fileName];
}

- (void)loadAttributesIfNeeded {
    if (FC_UNKNOWN == _flags.fileCategory) {
        const char *cIconName = NULL;
        
        if (_flags.directory) {
            _flags.fileCategory = FC_DIRECTORY;
            _displayName = _fileName;
            cIconName = "folder";
        } else {
            _displayName = _fileName;
            _statistic = FSStringCreateWithFileSize(_fileSize);
            
            const char *cExtenstion = [_extension UTF8String];
            
            if (0 == strcmp(cExtenstion, "txt")) {
                _flags.fileCategory = FC_PLAIN_TEXT;
                cIconName = "txt";
            } else if (0 == strcmp(cExtenstion, "h")) {
                _flags.fileCategory = FC_SOURCE_CODE;
                cIconName = "h";
            } else if (0 == strcmp(cExtenstion, "hpp")) {
                _flags.fileCategory = FC_SOURCE_CODE;
                cIconName = "h";
            } else if (0 == strcmp(cExtenstion, "c")) {
                _flags.fileCategory = FC_SOURCE_CODE;
                cIconName = "c";
            } else if (0 == strcmp(cExtenstion, "cpp")) {
                _flags.fileCategory = FC_SOURCE_CODE;
                cIconName = "cpp";
            } else if (0 == strcmp(cExtenstion, "m")) {
                _flags.fileCategory = FC_SOURCE_CODE;
                cIconName = "m";
            } else if (0 == strcmp(cExtenstion, "mm")) {
                _flags.fileCategory = FC_SOURCE_CODE;
                cIconName = "m";
            } else if (0 == strcmp(cExtenstion, "java")) {
                _flags.fileCategory = FC_SOURCE_CODE;
                cIconName = "java";
            } else if (0 == strcmp(cExtenstion, "js")) {
                _flags.fileCategory = FC_JAVASCRIPT;
                cIconName = "js";
            } else if (0 == strcmp(cExtenstion, "rtf")) {
                _flags.fileCategory = FC_RICH_TEXT;
                cIconName = "rtf";
            } else if (0 == strcmp(cExtenstion, "doc")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "doc";
            } else if (0 == strcmp(cExtenstion, "docx")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "doc";
            } else if (0 == strcmp(cExtenstion, "dot")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "doc";
            } else if (0 == strcmp(cExtenstion, "dotx")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "doc";
            } else if (0 == strcmp(cExtenstion, "xls")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "xls";
            } else if (0 == strcmp(cExtenstion, "xlsx")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "xls";
            } else if (0 == strcmp(cExtenstion, "xlt")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "xls";
            } else if (0 == strcmp(cExtenstion, "xltx")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "xls";
            } else if (0 == strcmp(cExtenstion, "htm")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "html";
            } else if (0 == strcmp(cExtenstion, "html")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "html";
            } else if (0 == strcmp(cExtenstion, "xhtml")) {
                _flags.fileCategory = FC_OFFICE;
                cIconName = "html";
            } else if (0 == strcmp(cExtenstion, "pdf")) {
                _flags.fileCategory = FC_PDF;
                cIconName = "pdf";
            } else if (0 == strcmp(cExtenstion, "tif")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "tif";
            } else if (0 == strcmp(cExtenstion, "tiff")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "tif";
            } else if (0 == strcmp(cExtenstion, "jpg")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "jpg";
            } else if (0 == strcmp(cExtenstion, "jpeg")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "jpg";
            } else if (0 == strcmp(cExtenstion, "gif")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "gif";
            } else if (0 == strcmp(cExtenstion, "png")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "png";
            } else if (0 == strcmp(cExtenstion, "bmp")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "bmp";
            } else if (0 == strcmp(cExtenstion, "bmpf")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "bmp";
            } else if (0 == strcmp(cExtenstion, "xbm")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "bmp";
            } else if (0 == strcmp(cExtenstion, "ico")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "ico";
            } else if (0 == strcmp(cExtenstion, "cur")) {
                _flags.fileCategory = FC_PHOTO;
                cIconName = "image";
            } else if (0 == strcmp(cExtenstion, "mp3")) {
                _flags.fileCategory = FC_AUDIO;
                cIconName = "mp3";
            } else if (0 == strcmp(cExtenstion, "wav")) {
                _flags.fileCategory = FC_AUDIO;
                cIconName = "wav";
            } else if (0 == strcmp(cExtenstion, "m4v")) {
                _flags.fileCategory = FC_AUDIO;
                cIconName = "mpeg";
            } else if (0 == strcmp(cExtenstion, "m4a")) {
                _flags.fileCategory = FC_AUDIO;
                cIconName = "mpeg";
            } else if (0 == strcmp(cExtenstion, "acc")) {
                _flags.fileCategory = FC_AUDIO;
                cIconName = "acc";
            } else if (0 == strcmp(cExtenstion, "caf")) {
                _flags.fileCategory = FC_AUDIO;
                cIconName = "audio";
            } else if (0 == strcmp(cExtenstion, "mov")) {
                _flags.fileCategory = FC_VIDEO;
                cIconName = "video";
            } else if (0 == strcmp(cExtenstion, "mp4")) {
                _flags.fileCategory = FC_VIDEO;
                cIconName = "mpeg";
            } else if (0 == strcmp(cExtenstion, "mpv")) {
                _flags.fileCategory = FC_VIDEO;
                cIconName = "mpv";
            } else if (0 == strcmp(cExtenstion, "3gp")) {
                _flags.fileCategory = FC_VIDEO;
                cIconName = "3gp";
            } else if (0 == strcmp(cExtenstion, "sqlite")) {
                _flags.fileCategory = FC_SQLITE;
                cIconName = "sqlite";
            } else if (0 == strcmp(cExtenstion, "sqlite3")) {
                _flags.fileCategory = FC_SQLITE;
                cIconName = "sqlite";
            } else if (0 == strcmp(cExtenstion, "zip")) {
                _flags.fileCategory = FC_COMPRESSED;
                cIconName = "zip";
            } else if (0 == strcmp(cExtenstion, "bz2")) {
                _flags.fileCategory = FC_COMPRESSED;
                cIconName = "bz2";
            } else if (0 == strcmp(cExtenstion, "tar")) {
                _flags.fileCategory = FC_COMPRESSED;
                cIconName = "tar";
            } else if (0 == strcmp(cExtenstion, "tbz2")) {
                _flags.fileCategory = FC_COMPRESSED;
                cIconName = "tbz2";
            } else if (0 == strcmp(cExtenstion, "tgz")) {
                _flags.fileCategory = FC_COMPRESSED;
                cIconName = "tgz";
            } else if (0 == strcmp(cExtenstion, "xib")) {
                _flags.fileCategory = FC_XIB;
                cIconName = "xib";
            } else {
                _flags.fileCategory = FC_OTHERS;
                cIconName = "unknown";
            }
        }
        
        _iconName = [[NSString alloc] initWithFormat:@"fs/%s.png", cIconName];
    }
}

- (BOOL)isEqual:(FBFileItem *)otherItem {
    return (otherItem && otherItem->_fileNumber == _fileNumber);
}

- (NSArray *)subitems {
    if (_flags.directory && nil == _subitems) {
        @autoreleasepool {
            NSArray *fileNames = [NSMainFileManager contentsOfDirectoryAtPath:_path error:NULL];
            const NSInteger numberOfFiles = [fileNames count];
            NSMutableArray *subDirectories = [[NSMutableArray alloc] initWithCapacity:numberOfFiles];
            NSMutableArray *subFiles = [[NSMutableArray alloc] initWithCapacity:numberOfFiles];
            
            _subitems = [[NSMutableArray alloc] initWithCapacity:numberOfFiles];
            
            for (NSInteger i = numberOfFiles - 1; i >= 0; -- i) {
                NSString *name = [fileNames objectAtIndex:i];
                FBFileItem *newFileItem = [[FBFileItem alloc] initWithParentPath:_path fileName:name];
                
                if (newFileItem) {
                    [(newFileItem->_flags.directory ? subDirectories : subFiles) addObject:newFileItem];
                }
            }
            
            [_subitems addObjectsFromArray:subDirectories];
            [_subitems addObjectsFromArray:subFiles];
        }
    }
    return _subitems;
}

- (NSString *)statistic {
    if (_flags.directory && nil == _statistic) {
        _statistic = [[NSString alloc] initWithFormat:@"%u %@", (unsigned)[[self subitems] count], LS(@"Items")];
    }
    return _statistic;
}

- (void)clearSubitems {
    if (_flags.directory) {
        _subitems = nil;
        _statistic = nil;
    }
}

- (void)invertSelection {
    _flags.selected = !_flags.selected;
}

- (BOOL)isInboxDirectory {
    if ([_path hasPrefix:FSDocumentsDirectory]) {
        const NSRange range = { 0, [FSDocumentsDirectory length] };
        NSString *relativePath = [_path stringByReplacingCharactersInRange:range withString:NSStringEmpty];
        
        if (![relativePath isEqualToString:@"/Inbox"]) {
            return NO;
        }
    }
    return YES;
}

#pragma mark - Properties

- (FILE_CATEGORY)fileCategory {
    return _flags.fileCategory;
}

- (void)setFileCategory:(FILE_CATEGORY)fileCategory {
    _flags.fileCategory = fileCategory;
}

- (BOOL)isDirectory {
    return _flags.directory;
}

- (BOOL)isSelected {
    return _flags.selected;
}

- (void)setSelected:(BOOL)selected {
    _flags.selected = selected;
}

- (BOOL)isCut {
    return _flags.cut;
}

- (void)setCut:(BOOL)cut {
    _flags.cut = cut;
}

@end
