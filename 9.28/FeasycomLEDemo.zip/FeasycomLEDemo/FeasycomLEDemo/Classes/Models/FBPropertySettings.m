//
//  FBPropertySettings.m
//  FeasycomLE
//
//  Created by LIDONG on 4/29/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBPropertySettings.h"

@implementation FBPropertySettings

@synthesize deviceName = _deviceName;
@synthesize pin = _pin;
@synthesize features = _features;
@synthesize pairAdv = _pairAdv;
@synthesize sniffConn = _sniffConn;
@synthesize baudRate = _baudRate;
@synthesize deviceNameEnabled = _deviceNameEnabled;
@synthesize pinEnabled = _pinEnabled;
@synthesize baudEnabled = _baudEnabled;
@synthesize featuresEnabled = _featuresEnabled;
@synthesize pairAdvEnabled = _pairAdvEnabled;
@synthesize sniffConnEnabled = _sniffConnEnabled;
@synthesize queried = _queried;


+ (BMFileFormat)saveFormat {
    return BMFileFormatJSON;
}

- (void)setBaudRate:(int)baudRate {
    _baudRate = (1200 < baudRate) ? baudRate : 1200;
}

- (int)baudRate {
    return ((1200 < _baudRate) ? _baudRate : 1200);
}

- (BOOL)isAvailable {
    if (_deviceNameEnabled && [_deviceName length] > 0) {
        return YES;
    } else if (_pinEnabled && 4 == [_pin lengthOfBytesUsingEncoding:NSASCIIStringEncoding]) {
        return YES;
    } else if (_baudEnabled) {
        return YES;
    } else if (_featuresEnabled && kNumberOfFeatures == [_features count]) {
        return YES;
    } else if (_pairAdvEnabled && kNumberOfPairAdv == [_pairAdv count]) {
        return YES;
    } else if (_sniffConnEnabled && kNumberOfPairAdv == [_sniffConn count]) {
        return YES;
    }
    return NO;
}

@end
