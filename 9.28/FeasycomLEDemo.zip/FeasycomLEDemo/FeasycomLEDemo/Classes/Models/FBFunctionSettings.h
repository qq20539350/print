//
//  FBFunctionSettings.h
//  FeasycomLE
//
//  Created by LIDONG on 5/13/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "BaseModel.h"

@interface FBFunctionSettings : BaseModel

@property (nonatomic, strong) NSString *deviceName;
@property (nonatomic, strong) NSString *serviceUUID;
@property (nonatomic, strong) NSString *notifyUUID;
@property (nonatomic, strong) NSString *writeUUID;
@property (nonatomic, strong) NSString *writeData;
@property (nonatomic, strong) NSString *readData;
@property (nonatomic, strong) NSString *RSSI;
@property (nonatomic, assign) BOOL deviceNameSpecified;
@property (nonatomic, assign) BOOL UUIDSpecified;
@property (nonatomic, assign) BOOL writeDataSpecified;
@property (nonatomic, assign) BOOL readDataSpecified;
@property (nonatomic, assign) BOOL RSSISpecified;
@property (nonatomic, assign) BOOL autoConnectionSpecified;

- (BOOL)isAvailable;

@end
