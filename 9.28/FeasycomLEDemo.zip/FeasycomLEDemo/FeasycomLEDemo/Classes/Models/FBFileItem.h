//
//  FBFileItem.h
//  FeasycomLE
//
//  Created by LIDONG on 3/23/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum __FILE_CATEGORY : char {
    FC_INVALID = -1,
    FC_UNKNOWN = 0,
    FC_PLAIN_TEXT,
    FC_SOURCE_CODE,
    FC_JAVASCRIPT,
    FC_RICH_TEXT,
    FC_OFFICE,
    FC_HTML,
    FC_PDF,
    FC_PHOTO,
    FC_AUDIO,
    FC_VIDEO,
    FC_COMPRESSED,
    FC_SQLITE,
    FC_XIB,
    FC_OTHERS,
    FC_DIRECTORY = 0x7F
} FILE_CATEGORY;

@interface FBFileItem : NSObject {
    UInt32 _fileNumber;
    UInt16 _permissions;
    UInt64 _fileSize;
    NSString *_path;
    NSString *_fileName;
    NSString *_displayName;
    NSString *_statistic;
    NSString *_extension;
    NSString *_creationTime;
    NSString *_iconName;
    NSDictionary *_extendedAttributes;
    NSMutableArray *_subitems;
    
    struct {
        unsigned int fileCategory:8;
        unsigned int directory:1;
        unsigned int inbox;
        unsigned int selected:1;
        unsigned int cut:1;
        unsigned int reserved:21;
    } _flags;
}

@property (nonatomic, strong, readonly) NSString *path;
@property (nonatomic, strong, readonly) NSString *fileName;
@property (nonatomic, strong, readonly) NSString *displayName;
@property (nonatomic, strong, readonly) NSString *statistic;
@property (nonatomic, strong, readonly) NSString *extension;
@property (nonatomic, strong, readonly) NSString *creationTime;
@property (nonatomic, strong, readonly) NSString *iconName;
@property (nonatomic, strong, readonly) NSArray *subitems;
@property (nonatomic, assign, readonly) UInt64 fileSize;
@property (nonatomic, assign, readonly) FILE_CATEGORY fileCategory;
@property (nonatomic, assign, readonly) BOOL isDirectory;
@property (nonatomic, assign, getter = isSelected) BOOL selected;
@property (nonatomic, assign, getter = isCut) BOOL cut;

- (id)initWithParentPath:(NSString *)parentPath fileName:(NSString *)fileName;
- (id)initWithPath:(NSString *)path;
- (void)loadAttributesIfNeeded;
- (void)clearSubitems;
- (void)invertSelection;
- (BOOL)isInboxDirectory;

@end