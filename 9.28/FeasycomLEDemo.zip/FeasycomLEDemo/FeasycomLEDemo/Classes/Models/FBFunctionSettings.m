//
//  FBFunctionSettings.m
//  FeasycomLE
//
//  Created by LIDONG on 5/13/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "FBFunctionSettings.h"

@implementation FBFunctionSettings

@synthesize deviceName = _deviceName;
@synthesize serviceUUID = _serviceUUID;
@synthesize notifyUUID = _notifyUUID;
@synthesize writeUUID = _writeUUID;
@synthesize writeData = _writeData;
@synthesize readData = _readData;
@synthesize RSSI = _RSSI;
@synthesize deviceNameSpecified = _deviceNameSpecified;
@synthesize UUIDSpecified = _UUIDSpecified;
@synthesize writeDataSpecified = _writeDataSpecified;
@synthesize readDataSpecified = _readDataSpecified;
@synthesize RSSISpecified = _RSSISpecified;
@synthesize autoConnectionSpecified = _autoConnectionSpecified;

- (BOOL)isAvailable {
    if (_deviceNameSpecified && [_deviceName length] > 0) {
        return YES;
    } else if (_UUIDSpecified && ([_serviceUUID length] > 0 || [_notifyUUID length] > 0 || [_writeUUID length] > 0)) {
        return YES;
    } else if (_writeDataSpecified && [_writeData length] > 0) {
        return YES;
    } else if (_readDataSpecified && [_readData length] > 0) {
        return YES;
    } else if (_RSSISpecified && [_RSSI length] > 0) {
        return YES;
    } else if (_autoConnectionSpecified) {
        return YES;
    }
    return NO;
}

@end
