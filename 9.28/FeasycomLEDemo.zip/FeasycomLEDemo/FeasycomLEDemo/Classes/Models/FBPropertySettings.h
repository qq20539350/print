//
//  FBPropertySettings.h
//  FeasycomLE
//
//  Created by LIDONG on 4/29/15.
//  Copyright (c) 2015 LIDONG. All rights reserved.
//

#import "BaseModel.h"

#define kNumberOfFeatures 5
#define kNumberOfPairAdv 4
#define kNumberOfSniffConn 4

@interface FBPropertySettings : BaseModel

@property (nonatomic, strong) NSString *deviceName;
@property (nonatomic, strong) NSString *pin;
@property (nonatomic, strong) NSArray *features;
@property (nonatomic, strong) NSArray *pairAdv;
@property (nonatomic, strong) NSArray *sniffConn;
@property (nonatomic, assign) int baudRate;
@property (nonatomic, assign) BOOL deviceNameEnabled;
@property (nonatomic, assign) BOOL pinEnabled;
@property (nonatomic, assign) BOOL baudEnabled;
@property (nonatomic, assign) BOOL featuresEnabled;
@property (nonatomic, assign) BOOL pairAdvEnabled;
@property (nonatomic, assign) BOOL sniffConnEnabled;
@property (nonatomic, assign, getter = isQueried) BOOL queried;

- (BOOL)isAvailable;

@end
