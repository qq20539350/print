//
//  FBRefreshControl.h
//  FeasycomLE
//
//  Created by LIDONG on 14-1-7.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>


@class FBRefreshControl;

@protocol FBRefreshControlDelegate <NSObject>
- (void)refreshControlDidBeginRefresh:(FBRefreshControl *)refreshControl;
@end

#define kRefreshControlHeight 65

@interface FBRefreshControl : UIView {
}

@property (nonatomic, weak) id<FBRefreshControlDelegate> delegate;
@property (nonatomic, assign) NSTimeInterval lastUpdateTime;

- (id)initWithFrame:(CGRect)frame arrowImageName:(NSString *)arrow textColor:(UIColor *)textColor;

- (void)beginRefreshing:(UIScrollView *)scrollView;
- (void)stopRefreshing:(UIScrollView *)scrollView;
- (void)updateLastUpdateTime;
- (void)scrollViewDidScroll:(UIScrollView *)scrollView;
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView;

@end
