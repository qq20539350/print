//
//  FBDetectingView.h
//  DuoPai
//
//  Created by LIDONG on 14-1-6.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FBDetectingView;

@protocol IBDetectingViewDelegate <NSObject>
@required
- (void)detectingViewDidTouchDown:(FBDetectingView *)detectingView;
@end

@interface FBDetectingView : UIView

@property (nonatomic, weak) id<IBDetectingViewDelegate> delegate;

@end
