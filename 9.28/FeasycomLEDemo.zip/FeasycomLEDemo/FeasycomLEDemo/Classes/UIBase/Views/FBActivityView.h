//
//  FBActivityView.h
//  LIDONG
//
//  Created by LiDong on 13-7-12.
//  Copyright (c) 2013年 LIDONG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FBActivityView : UIView

+ (void)displayWithTitle:(NSString *)title view:(UIView *)view;
+ (void)displayInView:(UIView *)view;
+ (void)dismiss;
+ (void)dismissWithTitle:(NSString *)title;

@end
