//
//  FBActivityView.m
//  Guating
//
//  Created by LiDong on 13-7-12.
//  Copyright (c) 2013年 Jacky. All rights reserved.
//

#import "FBActivityView.h"
#import <QuartzCore/QuartzCore.h>
#import <sys/time.h>

#define kMinDisplayTimeInterval 1.f

@interface FBActivityView () {
    UIView *mContentView;
    UIActivityIndicatorView *mActivityIndicatorView;
    UILabel *mTextLabel;
    NSTimeInterval mAppearedTimestamp;
}

@end

@implementation FBActivityView

static FBActivityView *_sharedActivityView = nil;

- (id)init {
    if (self = [super initWithFrame:CGRectZero]) {
        [self setBackgroundColor:RGBA(0, 0, 0, 63)];
        [self setExclusiveTouch:NO];
        
        mContentView = [[UIView alloc] initWithFrame:CGRectZero];
        [mContentView setBackgroundColor:RGBA(0, 0, 0, 192)];
        
        CALayer *layer = [mContentView layer];
        
        [layer setMasksToBounds:YES];
        [layer setCornerRadius:5];
        
        [self addSubview:mContentView];
        
        mActivityIndicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        [mActivityIndicatorView setHidesWhenStopped:YES];
        [mActivityIndicatorView setCenter:PT(160, 220)];
        [self addSubview:mActivityIndicatorView];
        
        mTextLabel = [[UILabel alloc] initWithFrame:RECT(60, 240, 200, 20)];
        [mTextLabel setBackgroundColor:UIColorClear];
        [mTextLabel setTextColor:UIColorWhite];
        [mTextLabel setTextAlignment:NSTextAlignmentCenter];
        [mTextLabel setFont:UIFontBold16];
        [mTextLabel setNumberOfLines:0];
        [self addSubview:mTextLabel];
    }
    return self;
}

- (void)calculateLayoutForBounds:(const CGRect)bounds title:(NSString *)title {
    BOOL isAnimating = [mActivityIndicatorView isAnimating];
    BOOL hasTitle = (title && ![title isEqualToString:NSStringEmpty]) ? YES : NO;
    CGSize contentSize = { 80, 60 };
    
    if (hasTitle) {
        [mTextLabel setNumberOfLines:1];
        [mTextLabel sizeToFit];
        
        UIFont *font = [mTextLabel font];
        CGRect textFrame = CGRectZero;
        
        textFrame.size = [title sizeWithFont:font];
        
        if (textFrame.size.width > 240.f) {
            const CGSize constrainedSize = { 240, CGFLOAT_MAX };
            
            textFrame.size = [title sizeWithFont:font constrainedToSize:constrainedSize lineBreakMode:NSLineBreakByWordWrapping];
        }
        
        contentSize.height = textFrame.size.height + (isAnimating ? 67 : 40);
        
        const CGFloat newContentWidth = textFrame.size.width + 40;
        
        contentSize.width = (newContentWidth > contentSize.width) ? newContentWidth : contentSize.width;
        textFrame.origin.x = (bounds.size.width - textFrame.size.width) / 2;
        
        if (isAnimating) {
            textFrame.origin.y = bounds.size.height / 2 + 14;
        } else {
            textFrame.origin.y = (bounds.size.height - textFrame.size.height) / 2;
        }
        [mTextLabel setFrame:textFrame];
    }
    
    const CGRect contentFrame = { (bounds.size.width - contentSize.width) / 2, (bounds.size.height - contentSize.height) / 2, contentSize.width, contentSize.height };
    
    [mContentView setFrame:contentFrame];
    
    if (isAnimating) {
        const CGPoint indicatorCenter = { bounds.size.width / 2.f, contentFrame.origin.y + (hasTitle ? 30 : (contentSize.height / 2.f)) };
        
        [mActivityIndicatorView setCenter:indicatorCenter];
    }
}

- (void)showWithTitle:(NSString *)title inView:(UIView *)view {
    const CGRect bounds = [view bounds];
    struct timeval tv = { 0 };
    
    gettimeofday(&tv, 0);
    mAppearedTimestamp = (double)tv.tv_sec + (double)tv.tv_usec / 1000000.f;
    
    [self setAlpha:0];
    [self setFrame:FBScreenBounds];
    [mActivityIndicatorView startAnimating];
    [mTextLabel setText:title];
    [self calculateLayoutForBounds:bounds title:title];
    [self setExclusiveTouch:YES];
    [self setUserInteractionEnabled:YES];
    [view addSubview:self];
    
    [UIView animateWithDuration:0.25 animations:^{
        [self setAlpha:1];
    } completion:^(BOOL finished){
    }];
}

- (NSTimeInterval)delayTimeInterval {
    struct timeval tv = { 0 };
    
    gettimeofday(&tv, 0);
    const NSTimeInterval currentTime = (double)tv.tv_sec + (double)tv.tv_usec / 1000000.f;
    const NSTimeInterval interval = currentTime - mAppearedTimestamp;
    NSTimeInterval delay = 0.f;
    
    if (0.f <= interval && interval < kMinDisplayTimeInterval) {
        delay = kMinDisplayTimeInterval - interval;
    }
    DLog(@"delay: %f", delay);
    return delay;
}

- (void)dismiss {
    [UIView animateWithDuration:0.25 delay:[self delayTimeInterval] options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self setAlpha:0];
    } completion:^(BOOL finished) {
        [mActivityIndicatorView stopAnimating];
        [self removeFromSuperview];
        _sharedActivityView = nil;
    }];
}

- (void)dismissWithTitle:(NSString *)title {
    if ([title length] > 0) {
        [mActivityIndicatorView stopAnimating];
        [mTextLabel setText:title];
        [self calculateLayoutForBounds:[[self superview] bounds] title:title];
    }
    [self setExclusiveTouch:NO];
    [self setUserInteractionEnabled:NO];
    [self dismiss];
}

+ (void)displayWithTitle:(NSString *)title view:(UIView *)view {
    if (nil == _sharedActivityView) {
        _sharedActivityView = [[FBActivityView alloc] init];
    }
    [_sharedActivityView showWithTitle:title inView:view];
}

+ (void)displayInView:(UIView *)view {
    if (nil == _sharedActivityView) {
        _sharedActivityView = [[FBActivityView alloc] init];
    }
    [_sharedActivityView showWithTitle:NSStringEmpty inView:view];
}

+ (void)dismiss {
    [_sharedActivityView dismiss];
}

+ (void)dismissWithTitle:(NSString *)title {
    [_sharedActivityView dismissWithTitle:title];
}

@end
