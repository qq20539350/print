//
//  FBViewController.m
//  FeasycomLE
//
//  Created by LIDONG on 14-2-28.
//  Copyright (c) 2014年 LIDONG. All rights reserved.
//

#import "FBViewController.h"
#import "FBActivityView.h"

@interface FBViewController () {
    struct {
        unsigned int visible:1;
    } _extendedFlags;
}

@end

@implementation FBViewController

@dynamic isVisible;

- (id)init {
    if (self = [super initWithNibName:nil bundle:nil]) {
        if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
            [self setEdgesForExtendedLayout:UIRectEdgeNone];
            [self setAutomaticallyAdjustsScrollViewInsets:NO];
        } else {
            [self setWantsFullScreenLayout:NO];
        }
    }
    return self;
}

- (void)setTitle:(NSString *)newTitle {
    [super setTitle:((newTitle && 0 < [newTitle length]) ? newTitle : nil)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[[self navigationController] view] setBackgroundColor:UIColorBackground];
    [[[self navigationController] interactivePopGestureRecognizer] setEnabled:NO];
}

- (void)viewDidUnload {
    [super viewDidUnload];
    [self releaseUI];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    if (!_extendedFlags.visible) {
        [self releaseUI];
        [self setView:nil];
    }
}

- (void)releaseUI {
    // Inherit this method to release UI
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    _extendedFlags.visible = YES;
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    _extendedFlags.visible = NO;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return (UIInterfaceOrientationPortrait == toInterfaceOrientation);
}

- (BOOL)shouldAutorotate {
    return NO;
}

- (NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

- (BOOL)isVisible {
    return _extendedFlags.visible;
}

- (void)alertWithTitle:(NSString *)title message:(NSString *)message {
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:LS(@"CLOSE") otherButtonTitles:nil];
	
	[alert show];
}

- (void)alertWithTitle:(NSString *)title {
    [self alertWithTitle:title message:nil];
}

- (void)startWaitingWithTitle:(NSString *)title {
    [FBActivityView displayWithTitle:title view:[[self navigationController] view]];
}

- (void)startWaiting {
    [FBActivityView displayWithTitle:NSStringEmpty view:[[self navigationController] view]];
}

- (void)stopWaiting {
    [FBActivityView dismiss];
}

- (void)stopWaitingWithTitle:(NSString *)title {
    [FBActivityView displayInView:[[self navigationController] view]];
    [FBActivityView dismissWithTitle:title];
}

@end
