//
//  main.m
//  FeasycomLEDemo
//
//  Created by LIDONG on 7/12/15.
//  Copyright (c) 2015 Feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FBAppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([FBAppDelegate class]));
    }
}
