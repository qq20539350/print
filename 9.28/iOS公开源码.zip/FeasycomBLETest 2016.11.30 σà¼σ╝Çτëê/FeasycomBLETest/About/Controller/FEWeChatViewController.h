//
//  FEWeChatViewController.h
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/25.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FEWeChatViewController : UIViewController

@end
