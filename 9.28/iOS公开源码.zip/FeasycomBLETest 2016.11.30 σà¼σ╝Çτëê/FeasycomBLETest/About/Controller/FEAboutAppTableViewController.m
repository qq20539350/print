//
//  FEAboutAppTableViewController.m
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/15.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEAboutAppTableViewController.h"
#import <MessageUI/MessageUI.h>
@interface FEAboutAppTableViewController ()<MFMailComposeViewControllerDelegate >
@property (nonatomic, strong) NSMutableArray *rowArray;
@property (nonatomic, strong) NSArray *emailArray;
@end

@implementation FEAboutAppTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.rowArray = [@[@"1",@"1",@"1"] mutableCopy];
    self.emailArray = @[@"onen.ouyang@feasycom.com", @"348712665@qq.com", @"mingyue_yu@icloud.com"];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.rowArray[section] integerValue];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    [cell setSelected:NO animated:YES];
    if (indexPath.row == 1) {
        if([MFMailComposeViewController canSendMail]){
            MFMailComposeViewController *mailCon = [MFMailComposeViewController new];
            [mailCon setSubject:FELocalizedString(@"question")];
            [mailCon setToRecipients:[NSArray arrayWithObject:self.emailArray[indexPath.section]]];
            // 设置发邮件的代理
            [mailCon setMailComposeDelegate:self];
            [self presentViewController:mailCon animated:YES completion:nil];
        }else{
            NSLog(@"不能发邮件");
        }
        return;
    }
    NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
    [indexPaths addObject:[NSIndexPath indexPathForRow:1 inSection:indexPath.section]];
    [indexPaths addObject:[NSIndexPath indexPathForRow:2 inSection:indexPath.section]];
    if ([self.rowArray[indexPath.section] integerValue] > 1) {
        self.rowArray[indexPath.section] = @"1";
        [self.tableView deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    }else{
        self.rowArray[indexPath.section] = @"3";
        [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}

#pragma MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error{
    switch (result) {
        case MFMailComposeResultSent:
            NSLog(@"发送成功");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"发送失败");
            break;
        case MFMailComposeResultCancelled:
            NSLog(@"取消发送");
            break;
        default:
            break;
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
