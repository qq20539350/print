重要!
SDK1.5 废弃safeSendReq:接口，使用sendReq:即可。