//
//  FETabBarViewController.m
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/22.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FETabBarViewController.h"
#import "FEShareBt.h"
#import "FEDFUTableViewController.h"

@interface FETabBarViewController ()<FEShareBtDelegate>

@end

@implementation FETabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [FEShareBt sharedFEShareBt].delegate = self;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)DFUUpdata{
    NSLog(@"进来了");
    FEDFUTableViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"sto_dfuTV"];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    [self presentViewController:nav animated:NO completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
