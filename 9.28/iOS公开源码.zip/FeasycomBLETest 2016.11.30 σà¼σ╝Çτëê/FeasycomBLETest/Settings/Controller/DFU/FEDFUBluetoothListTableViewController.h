//
//  FEDFUBluetoothListTableViewController.h
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/24.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FEDFUTableViewController.h"
@class FEDFUBluetoothListTableViewController;
@protocol FEDFUBluetoothListTableViewControllerDelegate <NSObject>
-(void)start;
-(void)foundPeripheral:(CBPeripheral*)peripheral;
-(void)finish;
@optional //可选实现
@end
@interface FEDFUBluetoothListTableViewController : UITableViewController
@property(nonatomic,weak)id<FEDFUBluetoothListTableViewControllerDelegate> delegate;
@end
