//
//  FEDFUOtherFileTableViewController.m
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/22.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEDFUOtherFileTableViewController.h"
@interface FEDFUOtherFileTableViewController ()
@property (nonatomic, strong) NSMutableArray<NSURL*> *allUrls;
@property (nonatomic, strong) NSMutableArray<NSString*>*allFileNames;
@property (nonatomic, strong) NSFileManager *manager;
@property (nonatomic, strong) NSString *fileBassPath;
@end

@implementation FEDFUOtherFileTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.allUrls = [NSMutableArray array];
    self.allFileNames = [NSMutableArray array];
    self.manager = [NSFileManager defaultManager];
    [self searchAllFile];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) searchAllFile{
    self.fileBassPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    self.fileBassPath = [self.fileBassPath stringByAppendingString:@"/Inbox/"];
    // 目录枚举器
    NSDirectoryEnumerator *enumerator = [self.manager enumeratorAtPath:self.fileBassPath];
    //遍历枚举器内容
    NSString *fileName;
    while ((fileName = [enumerator nextObject])!=nil) {
        NSLog(@"%@",fileName);
        [self.allFileNames addObject:fileName];
        NSString *fileFullName = [self.fileBassPath stringByAppendingString:fileName];
        NSURL *url = [NSURL fileURLWithPath:fileFullName];
        [self.allUrls addObject:url];
    }

}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allFileNames.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"dfu_fileNameCell"];
    if(cell ==nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"dfu_fileNameCell"];
    }
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    cell.textLabel.text = self.allFileNames[indexPath.row];
    cell.backgroundColor = [UIColor whiteColor];
    if ([self.allUrls[indexPath.row].pathExtension isEqualToString:@"bin"]) {
        cell.textLabel.textColor = [UIColor blackColor];
    }else{
        cell.textLabel.textColor = [UIColor lightGrayColor];
    }
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
        if ([self.allUrls[indexPath.row].pathExtension isEqualToString:@"bin"]) {
            //固件路径
            self.dfuTV.updataFileURL = self.allUrls[indexPath.row];
            
        }else{
            UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
            [cell setSelected:NO animated:YES];
            return;
        }
    [self.navigationController popViewControllerAnimated:YES];
}

// 自定义行高
-(CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 60;
}

// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        //删除文件
        NSError *error;
        [self.manager removeItemAtURL:self.allUrls[indexPath.row] error:&error];
        if (!error) {
            [self.allFileNames removeObjectAtIndex:indexPath.row];
            [self.allUrls removeObjectAtIndex:indexPath.row];
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        }
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here, for example:
    // Create the next view controller.
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:<#@"Nib name"#> bundle:nil];
    
    // Pass the selected object to the new view controller.
    
    // Push the view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)dealloc{
    NSLog(@"销毁FEDFUOtherFileTableViewController");
}
@end
