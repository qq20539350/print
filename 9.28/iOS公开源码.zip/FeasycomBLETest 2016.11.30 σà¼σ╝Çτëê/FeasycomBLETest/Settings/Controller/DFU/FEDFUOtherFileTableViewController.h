//
//  FEDFUOtherFileTableViewController.h
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/22.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FEDFUTableViewController.h"
@interface FEDFUOtherFileTableViewController : UITableViewController
@property (nonatomic, strong) FEDFUTableViewController *dfuTV;
@end
