//
//  FEUDFTableViewController.h
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/10/3.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
@interface FEDFUTableViewController : UITableViewController
@property (nonatomic, strong) CBPeripheral *peripheral;
@property (nonatomic, strong) CBCharacteristic *readCharacteristic;
@property (nonatomic, strong) CBCharacteristic *writeCharacteristic;

-(void)setUpdataFileURL:(NSURL *)updataFileURL;
@end
