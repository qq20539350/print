//
//  FEDFUBluetoothListTableViewController.m
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/24.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEDFUBluetoothListTableViewController.h"
#import "FECommunicationTableViewCell.h"
#import <MJRefresh.h>
#import "FEShareBt.h"

#define DFUORDER @"EnterDFU0"

@interface FEDFUBluetoothListTableViewController ()<CBCentralManagerDelegate,CBPeripheralDelegate>
//外设数组
@property (nonatomic, strong) NSMutableArray *peripherals;
@property (nonatomic, strong) NSMutableArray *advertisementDatas;
//中心管理者
@property (nonatomic, strong) CBCentralManager*mgr;
//外设
@property (nonatomic, strong) CBPeripheral*peripheral;
@property (nonatomic, strong) CBCharacteristic *readCharacteristic;
@property (nonatomic, strong) CBCharacteristic *writeCharacteristic;
//信号数组
@property (nonatomic, strong) NSMutableArray *RSSIs;
@property (nonatomic, strong) NSTimer *reflashRSSITimer;

@property (nonatomic) BOOL isOK;
@end

@implementation FEDFUBluetoothListTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = FELocalizedString(@"chooseOne");
    //去掉列表分割线
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"FECommunicationTableViewCell"bundle:nil] forCellReuseIdentifier:@"CommCell"];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"MyCell"];
    //self.title = @"Searching peripherals";
    // 1.创建中心设备
    //设置代理
    if (![FEShareBt sharedFEShareBt].mgr) {
        self.mgr= [[CBCentralManager alloc] initWithDelegate:self queue:nil];
        [FEShareBt sharedFEShareBt].mgr = self.mgr;
    }else{
        self.mgr = [FEShareBt sharedFEShareBt].mgr;
        self.mgr.delegate = self;
    }
    UIBarButtonItem*buttonI = [[UIBarButtonItem alloc] initWithTitle:FELocalizedString(@"stopScan") style:UIBarButtonItemStylePlain target:self action:@selector(openOrclosed)];
    self.navigationItem.rightBarButtonItem= buttonI;
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        self.tableView.userInteractionEnabled = NO;
        if (self.mgr.isScanning) [self.mgr stopScan];
        [self.peripherals removeAllObjects];
        [self.advertisementDatas removeAllObjects];
        [self.RSSIs removeAllObjects];
        [self.tableView reloadData];
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"stopScan")];
        [self.tableView.mj_header endRefreshing];
        [self.mgr scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:[NSNumber numberWithBool:YES]}];
        self.tableView.userInteractionEnabled = YES;
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -蓝牙配置和操作
#pragma mark - CBCentralManagerDelegate

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    // 保存扫描到得外部设备
    // 判断如果数组中不包含当前扫描到得外部设置才保存
//    NSLog(@"查找设备");
    if ([RSSI integerValue]<0 && [RSSI integerValue]>-100) {
        if (![self.peripherals containsObject:peripheral]) {
            [self insertTableView:peripheral advertisementData:advertisementData RSSI:RSSI];
        }else{
            NSInteger index = [self.peripherals indexOfObject:peripheral];
            self.RSSIs[index] = RSSI;
//            NSLog(@"RSSI");
        }
    }
}
//扫描外设
- (void)openOrclosed{
    if([self.navigationItem.rightBarButtonItem.title isEqualToString:FELocalizedString(@"scan")]) {
        NSLog(@"扫描");
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"stopScan")];
        // 利用中心设备扫描外部设备
        /*
         如果指定数组代表只扫描指定的设备
         */
        [self.mgr scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:[NSNumber numberWithBool:YES]}];
    }else {
        NSLog(@"停止扫描");
        [self.mgr stopScan];
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"scan")];
    }
}
#pragma mark - CBCentralManagerDelegate
//连接外设成功调用
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    NSLog(@"连接成功");
    self.peripheral = peripheral;
    if (self.reflashRSSITimer) {
        [self.reflashRSSITimer invalidate];
        self.reflashRSSITimer = nil;
    }
    [self.mgr stopScan];
    //开始扫描服务
    [self.peripheral discoverServices:nil];
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(nullable NSError *)error{
    NSLog(@"连接失败%@",error);
}
//连接外设失败调用
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    //    [self showTheAlertViewWithMassage:@"链接失败"];
    NSLog(@"断开链接");
}
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    NSLog(@"检测代理方法");
    if (central.state == CBManagerStatePoweredOn) {
        [self.mgr scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:[NSNumber numberWithBool:YES]}];
        //        [self showTheAlertViewWithMassage:@"手机蓝牙处于可用状态"];
    }
    NSLog(@"%ld，%@", (long)central.state, central);
}

//插入table数据
-(void)insertTableView:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    if ([RSSI integerValue]<-100 && [RSSI integerValue]>0) return;
    if(![self.peripherals containsObject:peripheral]) {
        NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.peripherals.count inSection:0];
        [indexPaths addObject:indexPath];
        [self.peripherals addObject:peripheral];
        [self.advertisementDatas addObject:advertisementData];
        [self.RSSIs addObject:RSSI];
        [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    }else{
        NSInteger index = [self.peripherals indexOfObject:peripheral];
        self.RSSIs[index] = RSSI;
    }
}

#pragma 蓝牙服务
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    NSLog(@"扫描服务");
    // 获取外设中所有扫描到得服务
    NSArray *services = peripheral.services;
    for (CBService *service in services) {
        //拿到需要的服务
        NSLog(@"服务%@", service.UUID.UUIDString);
        //从peripheral中得service中扫描特征
        [peripheral discoverCharacteristics:nil forService:service];
    }
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    NSLog(@"扫描到服务%@的%lu个特征", service.UUID.UUIDString, service.characteristics.count);
    // 遍历特征, 拿到需要的特征处理
    for (CBCharacteristic * characteristic in service.characteristics) {
        if (characteristic.properties & CBCharacteristicPropertyNotify) {
            //拿到可读的特征了
            self.readCharacteristic = characteristic;
            [self.peripheral setNotifyValue:YES forCharacteristic:characteristic];
        }
        if (characteristic.properties & CBCharacteristicPropertyIndicate){
            //拿到可读的带反馈特征了
            if (!self.readCharacteristic)  {
                self.readCharacteristic = characteristic;
            }
            [self.peripheral setNotifyValue:YES forCharacteristic:characteristic];
        }
        if (characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse){
            //拿到可写的特征了
            self.writeCharacteristic = characteristic;
        }
        if (characteristic.properties & CBCharacteristicPropertyWrite){
            if (!self.writeCharacteristic) self.writeCharacteristic = characteristic;
        }
    }
    if (self.writeCharacteristic && self.readCharacteristic) {
        if (!self.isOK) {
            self.isOK = YES;
            NSData *data = [DFUORDER dataUsingEncoding:NSUTF8StringEncoding];
            [self.delegate foundPeripheral:self.peripheral];
            [self.peripheral writeValue:data forCharacteristic:self.writeCharacteristic type:CBCharacteristicWriteWithoutResponse];
            NSLog(@"发送dfu指令");
            [self.navigationController popViewControllerAnimated:YES];
            [self.delegate finish];
            NSLog(@"退回**********");
        } 
    }
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.peripherals.count;
}


- (FECommunicationTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FECommunicationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommCell"];
    if(cell == nil) {
        cell = [FECommunicationTableViewCell new];
    }
    CBPeripheral *peripheral = [self.peripherals objectAtIndex:indexPath.row];
    //[cell reflashName:peripheral.name];
    NSDictionary *advertisementData = self.advertisementDatas[indexPath.row];
    if (advertisementData[CBAdvertisementDataLocalNameKey]) {
        [cell reflashName:[NSString stringWithFormat:@"%@",advertisementData[CBAdvertisementDataLocalNameKey]]];
    }else{
        [cell reflashName:peripheral.name];
    }
    [cell reflashRSSI:[self.RSSIs[indexPath.row] integerValue]];
    cell.UUIDLabel.text = peripheral.identifier.UUIDString;
    if ([advertisementData[@"kCBAdvDataServiceUUIDs"] componentsJoinedByString:@","]) {
        cell.serviceUUIDsLabel.text = [[NSString alloc] initWithFormat:@"%@",[advertisementData[@"kCBAdvDataServiceUUIDs"] componentsJoinedByString:@","]];
    }else{
        cell.serviceUUIDsLabel.text = @"";
    }
    return cell;
}

// 选择列表
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    self.peripheral = self.peripherals[indexPath.row];
    self.peripheral.delegate = self;
    NSLog(@"尝试连接-----------------");
    [self.mgr connectPeripheral:self.peripherals[indexPath.row] options:@{CBConnectPeripheralOptionNotifyOnConnectionKey:@1,CBConnectPeripheralOptionNotifyOnNotificationKey:@1}];
}

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 80;
}

#pragma 自己写的方法
-(void)reflashRSSI{
    for (int i=0; i<self.RSSIs.count; i++) {
        FECommunicationTableViewCell *cell = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
        [cell reflashRSSI:[self.RSSIs[i] integerValue]];
    }
}

#pragma 视图状态
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self.delegate start];
    self.mgr.delegate = self;
    self.writeCharacteristic = nil;
    self.readCharacteristic = nil;
    self.isOK = NO;
    [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"stopScan")];
    [self.tableView reloadData];
    // 利用中心设备扫描外部设备
    [self.mgr scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:[NSNumber numberWithBool:YES]}];
    if (!self.reflashRSSITimer) {
        self.reflashRSSITimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(reflashRSSI) userInfo:nil repeats:YES];
    }
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.mgr stopScan];
    if (self.reflashRSSITimer) {
        [self.reflashRSSITimer invalidate];
        self.reflashRSSITimer = nil;
    }
}

#pragma 懒加载
-(NSMutableArray *)peripherals{
    if (!_peripherals) {
        _peripherals = [NSMutableArray array];
    }
    return _peripherals;
}
-(NSMutableArray *)advertisementDatas{
    if (!_advertisementDatas) {
        _advertisementDatas = [NSMutableArray array];
    }
    return _advertisementDatas;
}
-(NSMutableArray *)RSSIs{
    if (!_RSSIs) {
        _RSSIs = [NSMutableArray array];
    }
    return _RSSIs;
}

-(void)dealloc{
    NSLog(@"销毁dfu蓝牙搜索");
}
@end
