//
//  FEUDFTableViewController.m
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/10/3.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEDFUTableViewController.h"
#import "AppDelegate.h"
#import "FEDFUOtherFileTableViewController.h"
#import "FEDFUBluetoothListTableViewController.h"

@interface FEDFUTableViewController ()<UINavigationControllerDelegate,FEDFUBluetoothListTableViewControllerDelegate>
@property (nonatomic) BOOL isUpdating;
@property (nonatomic,strong) NSURL *updataFileURL;
@property (nonatomic,strong) NSString *updataFilePath;
@property (nonatomic, strong) FEDFUBluetoothListTableViewController *bluetoothListTV;
@property (weak, nonatomic) IBOutlet UIProgressView *updataProgress;
@property (weak, nonatomic) IBOutlet UILabel *fileNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *stateShowLabel;
@property (weak, nonatomic) IBOutlet UILabel *progressLabel;

@end

@implementation FEDFUTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIBarButtonItem*leftItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(dfuCancel)];
    self.navigationItem.leftBarButtonItem= leftItem;
    self.navigationItem.title = FELocalizedString(@"firmwareUpdata");
    [self.navigationController.navigationBar setBackgroundColor:[UIColor colorWithRed:0 green:0.5 blue:1 alpha:0.8]];
    self.isUpdating = NO;
    AppDelegate *appDele = (AppDelegate*)[UIApplication sharedApplication].delegate;
    if (appDele.url) {
        //获取文件名
        NSLog(@"%@",appDele.url);
        //判断文件后缀
        if ([appDele.url.pathExtension isEqualToString:@"bin"]) {
            self.updataFileURL = appDele.url;
        }
        
        //1.从指定文件路径中读取数据
        //NSData*readData = [NSData dataWithContentsOfURL:appDele.url];
//        NSLog(@"%ld",readData.length);
//        NSLog(@"%@",[[NSString alloc] initWithData:readData encoding:NSUTF8StringEncoding]);
    }

}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (0 == section) {
        return 4;
    }else{
        return 0;
    }
}

-(void)setUpdataFileURL:(NSURL *)updataFileURL{
    _updataFileURL = updataFileURL;
    self.fileNameLabel.text = [[self.updataFileURL lastPathComponent] stringByDeletingPathExtension];
//    NSLog(@"选中文件：%@",updataFileURL);
    self.updataFilePath = self.updataFileURL.absoluteString;
    self.updataFilePath = [self.updataFilePath substringFromIndex:7];
    self.updataFilePath = [self.updataFilePath stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    self.stateShowLabel.text = FELocalizedString(@"haveFirmware");
}

#pragma 控件方法

- (IBAction)clickToUpdata:(UIButton *)sender {
    if (self.isUpdating) {
        return;
    }
    //如果文件存在
    if ([[NSFileManager defaultManager] fileExistsAtPath:self.updataFilePath]){
        if (!self.bluetoothListTV) {
            self.bluetoothListTV = [FEDFUBluetoothListTableViewController new];
            self.bluetoothListTV.delegate = self;
        }
        [self.navigationController pushViewController:self.bluetoothListTV animated:YES];
    }else{
        self.stateShowLabel.text = FELocalizedString(@"noFile");
    }
}

- (IBAction)clickSelectOther:(UIButton *)sender {
    if (self.isUpdating) {
        return;
    }
    FEDFUOtherFileTableViewController *otherFileTV = [FEDFUOtherFileTableViewController new];
    otherFileTV.dfuTV = self;
    [self.navigationController pushViewController:otherFileTV animated:YES];
}

-(void)dfuCancel{
    [self dismissViewControllerAnimated:YES completion:nil];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma FEDFUBluetoothListTableViewControllerDelegate
-(void)start{
    self.peripheral = nil;
    self.writeCharacteristic = nil;
    self.readCharacteristic = nil;
}
-(void)foundPeripheral:(CBPeripheral *)peripheral{
    self.peripheral = peripheral;
}
-(void)finish{
    if (!self.isUpdating) {
        self.stateShowLabel.text = FELocalizedString(@"checking");
        self.isUpdating = YES;
        //必须延时，否则指令未发送完成就断开连接。
        [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(goToUpdata) userInfo:nil repeats:NO];
    }else{
    }
}

-(void)goToUpdata{
    
}

#pragma Xmodem
-(void)progress:(float)progress length:(int)length finishLength:(int)finishLength{
    [self.updataProgress setProgress:progress animated:YES];
    self.progressLabel.text = [NSString stringWithFormat:@"%d %%  %d / %d ",(int)(progress*100.0), length, finishLength];
}
-(void)transferDidFinish{
    self.stateShowLabel.text = FELocalizedString(@"transferDidFinish");
    self.isUpdating = NO;
}
-(void)transferDidAbort{
    self.stateShowLabel.text = FELocalizedString(@"transferDidAbort");
    self.isUpdating = NO;
}
-(void)verification:(BOOL)right{
    if (right) {
        self.stateShowLabel.text = FELocalizedString(@"updating");
    }else{
        self.stateShowLabel.text = FELocalizedString(@"verificationER");
        self.isUpdating = NO;
    }
}

-(void)dealloc{
    NSLog(@"销毁空中升级");
}
@end
