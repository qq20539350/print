//
//  FESettingSearchTableViewController.m
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/9/28.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FESettingSearchTableViewController.h"
#import "FESettingSearchTableViewCell.h"
#import "FEShareBt.h"
#import <MJRefresh.h>
#import <AVFoundation/AVFoundation.h>

#define NONERE                0
#define CONNETING         1
#define OPENINGEN         2
#define GETNAINFO          3
#define ERRORDATA         4
#define GETPININFO         5
#define GETBAUDINFO     6
#define CHANGEINFO       7

@interface FESettingSearchTableViewController ()<CBCentralManagerDelegate,CBPeripheralDelegate>
//外设数组
@property (nonatomic, strong) NSMutableArray *peripherals;
//中心管理者
@property (nonatomic, strong) CBCentralManager*mgr;
//外设
@property (nonatomic, strong) CBPeripheral*peripheral;
//信号数组
@property (nonatomic, strong) NSMutableArray *RSSIs;
@property (nonatomic, strong) NSTimer *reflashRSSITimer;
@property (nonatomic, strong) CBCharacteristic *characteristic;
@property (nonatomic, strong) CBCharacteristic *wrNoReCharacteristic;
@property (nonatomic, strong) CBCharacteristic *wrCharacteristic;
//接收状态
@property (nonatomic) NSInteger reState;
@property (nonatomic, strong) NSData *sendData;
@property (nonatomic, weak) FESettingSearchTableViewCell *selectCell;
@property (nonatomic) NSInteger changeWitchOne;
@property (nonatomic, strong) NSMutableArray *infosAfter;
@property (nonatomic, strong) NSMutableArray *succesDrivers;
@property (nonatomic) BOOL isStar;
//音频(本地音频)
@property (nonatomic, strong) AVAudioPlayer *playerOK;
@property (nonatomic, strong) AVAudioPlayer *playerAllarm;

//计时器
@property (nonatomic, strong) NSTimer *timerForOpenAT;
@end

@implementation FESettingSearchTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //去掉列表分割线
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"FESettingSearchTableViewCell"bundle:nil] forCellReuseIdentifier:@"SettingSearchCell"];
    FEShareBt *shareBt = [FEShareBt sharedFEShareBt];
    self.peripherals = shareBt.peripherals;
    self.mgr = shareBt.mgr;
    self.peripheral = shareBt.peripheral;
    self.RSSIs = shareBt.RSSIs;
    UIBarButtonItem*buttonI = [[UIBarButtonItem alloc] initWithTitle:FELocalizedString(@"stopScan")style:UIBarButtonItemStylePlain target:self action:@selector(openOrclosed)];
    self.navigationItem.rightBarButtonItem= buttonI;
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        self.tableView.userInteractionEnabled = NO;
        if (self.mgr.isScanning) [self.mgr stopScan];
        [self.peripherals removeAllObjects];
        [self.RSSIs removeAllObjects];
        [self.tableView reloadData];
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"stopScan")];
        [self.tableView.mj_header endRefreshing];
        [self.mgr scanForPeripheralsWithServices:nil options:nil];
        if (self.selectCell) {
            [self.selectCell clear];
        }
        self.tableView.userInteractionEnabled = YES;
    }];
    self.reState = ERRORDATA;
    self.isStar = NO;
    [self.succesDrivers removeAllObjects];
    //1.音频文件路径
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"allarm" ofType:@"mp3"];
    //2.创建对象(执行文件)
    self.playerAllarm = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:audioPath] error:nil];
    //1.音频文件路径
    audioPath = [[NSBundle mainBundle] pathForResource:@"OK" ofType:@"mp3"];
    //2.创建对象(执行文件)
    self.playerOK = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:audioPath] error:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    self.mgr.delegate = self;
    [self.tableView.mj_header beginRefreshing];
}

#pragma mark -蓝牙配置和操作
#pragma mark - CBCentralManagerDelegate
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    // 保存扫描到得外部设备
    // 判断如果数组中不包含当前扫描到得外部设置才保存
    NSLog(@"查找设备");
    if (![self.filterName isEqualToString:@""] && [peripheral.name rangeOfString:self.filterName].location == NSNotFound) return;
    if ([RSSI integerValue]<0 && [RSSI integerValue]>self.filterRssi) {
        if (![self.peripherals containsObject:peripheral]) {
            [self insertTableView:peripheral advertisementData:advertisementData RSSI:RSSI];
        }else{
            NSInteger index = [self.peripherals indexOfObject:peripheral];
            self.RSSIs[index] = RSSI;
        }
    }
}
//扫描外设
- (void)openOrclosed{
    if([self.navigationItem.rightBarButtonItem.title isEqualToString:FELocalizedString(@"scan")]) {
        NSLog(@"扫描");
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"stopScan")];
        // 利用中心设备扫描外部设备
        [self.mgr scanForPeripheralsWithServices:nil options:nil];
    }else {
        NSLog(@"停止扫描");
        [self.mgr stopScan];
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"scan")];
    }
}
#pragma mark - CBCentralManagerDelegate
//连接外设成功调用
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    [self.selectCell progressPersend:20];
    [self.mgr stopScan];
    //开始扫描服务
    [self.peripheral discoverServices:nil];
}

//连接外设失败调用
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    //    [self showTheAlertViewWithMassage:@"链接失败"];
    //[SVProgressHUD showInfoWithStatus:FELocalizedString(@"disconnected")];
    NSLog(@"断开成功");
    if (self.isStar) {
        self.isStar = NO;
        self.reState = OPENINGEN;
        [self.mgr connectPeripheral:self.peripheral options:nil];
    }
}
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    NSLog(@"检测代理方法");
    if (central.state == CBManagerStatePoweredOn) {
        [self.mgr scanForPeripheralsWithServices:nil options:nil];
        //        [self showTheAlertViewWithMassage:@"手机蓝牙处于可用状态"];
    }
    NSLog(@"%ld，%@", (long)central.state, central);
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    NSLog(@"扫描服务");
    // 获取外设中所有扫描到得服务
    NSArray *services = peripheral.services;
    for (CBService *service in services) {
        //拿到需要的服务
        NSLog(@"服务%@", service.UUID.UUIDString);
        //从peripheral中得service中扫描特征
        [peripheral discoverCharacteristics:nil forService:service];
    }
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    NSLog(@"扫描特征");
    // 遍历特征, 拿到需要的特征处理
    for (CBCharacteristic * characteristic in service.characteristics) {
        if (characteristic.properties & CBCharacteristicPropertyNotify ||  characteristic.properties & CBCharacteristicPropertyIndicate) {
            //拿到可读的特征了
            if (!self.characteristic)  {
                NSLog(@"可读");
                self.characteristic = characteristic;
                [self.peripheral setNotifyValue:YES forCharacteristic:characteristic];
            }
        }else if (characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse){
            //拿到可写的特征了
            if (!self.wrNoReCharacteristic) {
                NSLog(@"可写");
                self.wrNoReCharacteristic = characteristic;
                [self send:@"$OpenFscAtEngine$"];
                self.timerForOpenAT = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(openATTimeout) userInfo:nil repeats:NO];
            }
        }else if (characteristic.properties & CBCharacteristicPropertyWrite){
            self.wrCharacteristic = characteristic;
        }
    }
}
//处理蓝牙发送过来的数据
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error{
    NSLog(@"接收到数据");
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    NSString *stringByBuf = [[NSString alloc] initWithData:characteristic.value encoding:NSUTF8StringEncoding];
    NSLog(@"收到%@", stringByBuf);
    if ([stringByBuf rangeOfString:@"ERROR"].location != NSNotFound) self.reState = ERRORDATA;
    switch (self.reState) {
        case OPENINGEN:
            NSLog(@"正在打开FscAtEngine");
            if ([stringByBuf rangeOfString:@"$OK,Opened$"].location != NSNotFound) {
                NSLog(@"打开FscAtEngine成功");
                [self.timerForOpenAT invalidate];
                [self.selectCell progressPersend:30];
                [self send:@"AT+NAME\r\n"];
                self.reState = GETNAINFO;
            }
            break;
        case GETNAINFO:
            NSLog(@"正在获取名字");
            if ([stringByBuf rangeOfString:@"+NAME="].location != NSNotFound) {
                [self.selectCell progressPersend:40];
                NSLog(@"获取名字成功！");
                NSString *strTemp = [self getStringBy:stringByBuf cut:@"+NAME="];
                self.selectCell.nameBeforeLabel.text = strTemp;
                [self send:@"AT+PIN\r\n"];
                self.reState = GETPININFO;
            }
            break;
        case ERRORDATA:
            NSLog(@"出错");
            [self.selectCell changeOK:NO];
            [self.selectCell progressPersend:0];
            if (self.isFaileSound) [self.playerAllarm play];
            NSLog(@"尝试断开");
            [self.mgr cancelPeripheralConnection:self.peripheral];
            break;
        case GETPININFO:
            NSLog(@"正在获取配对码");
            if ([stringByBuf rangeOfString:@"+PIN="].location != NSNotFound) {
                [self.selectCell progressPersend:50];
                NSLog(@"获取配对码成功！");
                NSString *strTemp = [self getStringBy:stringByBuf cut:@"+PIN="];
                self.selectCell.pinBeforeLabel.text = strTemp;
                [self send:@"AT+BAUD\r\n"];
                self.reState = GETBAUDINFO;
            }
            break;
        case GETBAUDINFO:
            NSLog(@"正在获取波特率");
            if ([stringByBuf rangeOfString:@"+BAUD="].location != NSNotFound) {
                [self.selectCell progressPersend:60];
                NSLog(@"获取波特率成功！");
                NSString *strTemp = [self getStringBy:stringByBuf cut:@"+BAUD="];
                self.selectCell.baudBeforeLabel.text = strTemp;
                self.reState = CHANGEINFO;
                if ([self.isChangeInfos[self.changeWitchOne] boolValue]) {
                    [self send:self.changeInfos[self.changeWitchOne]];
                }else{
                    [self nextChangeInfo];
                }
            }
            break;
        case CHANGEINFO:
            NSLog(@"尝试修改%@",self.changeInfos[self.changeWitchOne]);
            if ([stringByBuf rangeOfString:@"OK"].location != NSNotFound) {
                [self.selectCell progressPersend:70 + (self.changeWitchOne + 1)*(30 / self.changeInfos.count)];
                NSLog(@"修改成功！");
                //给界面赋值
                NSString *strTemp = [self getStringBy:self.changeInfos[self.changeWitchOne] cut:@"="];
                UILabel *label = self.infosAfter[self.changeWitchOne];
                label.text = strTemp;
                [self nextChangeInfo];
            }
            break;
        default:
            break;
    }
}
//发送消息成功
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    if (error) {
        NSLog(@"发送失败");
    }else{
        NSLog(@"发送成功");
    }
}

//插入table数据
-(void)insertTableView:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    if(![self.peripherals containsObject:peripheral]) {
        NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.peripherals.count inSection:0];
        [indexPaths addObject:indexPath];
        [self.peripherals addObject:peripheral];
        [self.RSSIs addObject:RSSI];
        [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    }else{
        NSInteger index = [self.peripherals indexOfObject:peripheral];
        self.RSSIs[index] = RSSI;
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.peripherals.count;
}

- (FESettingSearchTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    FESettingSearchTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SettingSearchCell"];
    if(cell == nil) {
        cell = [FESettingSearchTableViewCell new];
    }
    CBPeripheral *peripheral = [self.peripherals objectAtIndex:indexPath.row];
    [cell reflashName:peripheral.name];
    [cell reflashRSSI:[self.RSSIs[indexPath.row] integerValue]];
    cell.serviceUUIDsLabel.text = peripheral.identifier.UUIDString;
    [cell successed:NO];
    for (NSString *string in self.succesDrivers) {
        if ([string isEqualToString:cell.serviceUUIDsLabel.text]) {
            [cell successed:YES];
        }
    }
    return cell;
}

// 选择列表
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.selectCell progressPersend:0];
    if (self.peripheral !=NULL && self.peripheral.state == CBPeripheralStateConnected) {
        self.isStar = YES;
        NSLog(@"尝试断开");
        [self.mgr cancelPeripheralConnection:self.peripheral];
        self.reState = NONERE;
    }else{
        self.reState = OPENINGEN;
    }
    self.peripheral = self.peripherals[indexPath.row];
    self.peripheral.delegate = self;
    self.selectCell = [self.tableView cellForRowAtIndexPath:indexPath];
    self.changeWitchOne = 0;
    self.characteristic = nil;
    self.wrNoReCharacteristic = nil;
    [self.infosAfter removeAllObjects];
    //增加项目的地方(注意顺序)
    [self.infosAfter    addObject:self.selectCell.nameAfterLabel];
    [self.infosAfter    addObject:self.selectCell.pinAfterLabel];
    [self.infosAfter    addObject:self.selectCell.baudAfterLabel];
    [self.selectCell progressPersend:10];
    //如果是非连接状态
    if (self.reState == OPENINGEN) {
        [self.mgr connectPeripheral:self.peripheral options:nil];
    }
}

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 115;
}

#pragma 自己的方法
- (NSString *)getStringBy:(NSString *)reString cut:(NSString *)cutString{
    NSString *strTemp;
    NSRange r1 = [reString rangeOfString:cutString];
    if (r1.location >= reString.length || r1.length <= 0) return FELocalizedString(@"forFail");
    strTemp = [reString substringWithRange:NSMakeRange(r1.location + r1.length, reString.length-r1.location-r1.length)];
    r1 = [strTemp rangeOfString:@"\r\n"];
     if (r1.location >= reString.length || r1.length <= 0) return FELocalizedString(@"forFail");
    NSRange range = NSMakeRange(0, r1.location);
    strTemp = [strTemp substringWithRange:range];
    return strTemp;
}

- (void)send:(NSString*)string{
    self.sendData = [string dataUsingEncoding:NSUTF8StringEncoding];
    [self.peripheral writeValue:self.sendData forCharacteristic:self.wrNoReCharacteristic type:CBCharacteristicWriteWithoutResponse];
}
- (void)nextChangeInfo{
    NSLog(@"下一个");
    self.changeWitchOne++;
    if (self.changeWitchOne < self.changeInfos.count) {
        if ([self.isChangeInfos[self.changeWitchOne] boolValue]) {
            [self send:self.changeInfos[self.changeWitchOne]];
        }else{
            [self nextChangeInfo];
        }
    }else if (self.changeWitchOne == self.changeInfos.count){
        [self.succesDrivers addObject:self.selectCell.serviceUUIDsLabel.text];
        [self.selectCell changeOK:YES];
        [self.selectCell progressPersend:100];
        if (self.isSuccessSound) [self.playerOK play];
        [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(progressTo0) userInfo:nil repeats:NO];
        NSLog(@"尝试断开");
        [self.mgr cancelPeripheralConnection:self.peripheral];
    }
}

-(void)progressTo0{
    [self.selectCell progressPersend:0];
}
-(void)openATTimeout{
    NSLog(@"超时");
    [self.selectCell changeOK:NO];
    [self.selectCell progressPersend:100];
    if (self.isSuccessSound) [self.playerOK play];
    [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(progressTo0) userInfo:nil repeats:NO];
    NSLog(@"尝试断开");
    [self.mgr cancelPeripheralConnection:self.peripheral];
}

//懒加载
-(NSMutableArray *)changeInfos{
    if (!_changeInfos) {
        _changeInfos = [NSMutableArray array];
    }
    return _changeInfos;
}
- (NSMutableArray *)isChangeInfos{
    if (!_isChangeInfos) {
        _isChangeInfos = [NSMutableArray array];
    }
    return _isChangeInfos;
}
- (NSMutableArray *)infosAfter{
    if (!_infosAfter) {
        _infosAfter = [NSMutableArray array];
    }
    return _infosAfter;
}
- (NSMutableArray *)succesDrivers{
    if (!_succesDrivers) {
        _succesDrivers = [NSMutableArray array];
    }
    return _succesDrivers;
}

@end
