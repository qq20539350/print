//
//  FESettingSearchTableViewController.h
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/9/28.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FESettingSearchTableViewController : UITableViewController

@property (nonatomic, strong) NSMutableArray *changeInfos;
@property (nonatomic, strong) NSMutableArray * isChangeInfos;
@property (nonatomic, strong) NSString *filterName;
@property (nonatomic) NSInteger filterRssi;
@property (nonatomic) BOOL isSuccessSound;
@property (nonatomic) BOOL isFaileSound;
@end
