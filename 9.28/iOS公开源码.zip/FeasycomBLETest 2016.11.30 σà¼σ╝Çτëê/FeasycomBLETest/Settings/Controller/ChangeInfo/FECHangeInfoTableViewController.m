//
//  FECHangeInfoTableViewController.m
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/9/29.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FECHangeInfoTableViewController.h"
#import "FESettingSearchTableViewController.h"
#import "FEDFUTableViewController.h"

@interface FECHangeInfoTableViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *pinTextField;
@property (weak, nonatomic) IBOutlet UITextField *baudTextField;
@property (weak, nonatomic) IBOutlet UITextField *filterNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *filterRssiTextField;
@property (weak, nonatomic) IBOutlet UISwitch *nameSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *pinSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *baudSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *filterNameSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *filterRssiSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *successSound;
@property (weak, nonatomic) IBOutlet UISwitch *faileSound;

@end

@implementation FECHangeInfoTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    self.nameTextField.text          = [def objectForKey:@"Change name"];
    self.pinTextField.text              = [def objectForKey:@"Change pin"];
    self.baudTextField.text           = [def objectForKey:@"Change baud"];
    self.filterNameTextField.text  = [def objectForKey:@"Filter name"];
    self.filterRssiTextField.text     = [def objectForKey:@"Filter rssi"];
    self.nameSwitch.on               = [[def objectForKey:@"Change name on"] boolValue];
    self.pinSwitch.on                   = [[def objectForKey:@"Change pin on"] boolValue];
    self.baudSwitch.on                = [[def objectForKey:@"Change baud on"] boolValue];
    self.filterNameSwitch.on        = [[def objectForKey:@"Filter name on"] boolValue];
    self.filterRssiSwitch.on           = [[def objectForKey:@"Filter rssi on"] boolValue];
    self.successSound.on            = [[def objectForKey:@"Filter success sound on"] boolValue];
    self.faileSound.on                  = [[def objectForKey:@"Filter faile sound on"] boolValue];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 0;
}
*/
//- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//    if (1 == section) {
//        return 3;
//    }else {
//        return 1;
//    }
//}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.nameTextField resignFirstResponder];
    [self.pinTextField resignFirstResponder];
    [self.baudTextField resignFirstResponder];
    [self.filterNameTextField resignFirstResponder];
    [self.filterRssiTextField resignFirstResponder];
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    [cell setSelected:NO animated:YES];
}
- (IBAction)clickNameSwitch:(UISwitch *)sender {
    if ([self.nameTextField.text isEqualToString:@""]) {
        sender.on = NO;
    }
}
- (IBAction)clickPinSwitch:(UISwitch *)sender {
    if ([self.pinTextField.text isEqualToString:@""]) {
        sender.on = NO;
    }
}
- (IBAction)clickBaudSwitch:(UISwitch *)sender {
    if ([self.baudTextField.text isEqualToString:@""]) {
        sender.on = NO;
    }
}

- (IBAction)clickChangeNameNext:(UITextField *)sender {
    [self.pinTextField becomeFirstResponder];
}
- (IBAction)clickChangePinNext:(UITextField *)sender {
    [self.baudTextField becomeFirstResponder];
}
- (IBAction)clickChangeBaudNext:(UITextField *)sender {
    
}
- (IBAction)clickFilterName:(UITextField *)sender {
    [self.filterRssiTextField becomeFirstResponder];
}
- (IBAction)clickFilterRSSI:(UITextField *)sender {
}
- (IBAction)clickFilterRssiSwitch:(UISwitch *)sender {
    if (sender.isOn){
        if ([self.filterRssiTextField.text isEqualToString:@""]) {
            self.filterRssiTextField.text = FELocalizedString(@"rssiValue");
        }
    }
}
- (IBAction)changeRssiTextField:(UITextField *)sender {
    if ([sender.text integerValue] > 0) {
        sender.text = [NSString stringWithFormat:@"%ld",-[sender.text integerValue]];
    }
    if ([sender.text integerValue] < -100) {
        sender.text = [sender.text substringWithRange:NSMakeRange(0, sender.text.length-1)];
    }
}
- (IBAction)clickUpdata:(UIButton *)sender {
//    FEDFUTableViewController *dfuTV = [self.storyboard instantiateViewControllerWithIdentifier:@"sto_dfuTV"];
//    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:dfuTV];
//    [self presentViewController:nav animated:YES completion:nil];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:self.nameTextField.text         forKey:@"Change name"];
    [def setObject:self.pinTextField.text             forKey:@"Change pin"];
    [def setObject:self.baudTextField.text          forKey:@"Change baud"];
    [def setObject:self.filterNameTextField.text  forKey:@"Filter name"];
    [def setObject:self.filterRssiTextField.text    forKey:@"Filter rssi"];
    [def setObject:[NSString stringWithFormat:@"%d", self.nameSwitch.isOn]          forKey:@"Change name on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.pinSwitch.isOn]               forKey:@"Change pin on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.baudSwitch.isOn]           forKey:@"Change baud on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.filterNameSwitch.isOn]   forKey:@"Filter name on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.filterRssiSwitch.isOn]     forKey:@"Filter rssi on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.successSound.isOn]    forKey:@"Filter success sound on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.faileSound.isOn]    forKey:@"Filter faile sound on"];
    
}

//跳转
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    FESettingSearchTableViewController *vc  = segue.destinationViewController;
    [vc.changeInfos     addObject:[NSString stringWithFormat:@"AT+NAME=%@\r\n", self.nameTextField.text]];
    [vc.changeInfos     addObject:[NSString stringWithFormat:@"AT+PIN=%@\r\n", self.pinTextField.text]];
    [vc.changeInfos     addObject:[NSString stringWithFormat:@"AT+BAUD=%@\r\n", self.baudTextField.text]];
    [vc.isChangeInfos addObject:[NSString stringWithFormat:@"%d", self.nameSwitch.isOn]];
    [vc.isChangeInfos addObject:[NSString stringWithFormat:@"%d", self.pinSwitch.isOn]];
    [vc.isChangeInfos addObject:[NSString stringWithFormat:@"%d", self.baudSwitch.isOn]];
    [self clickFilterRssiSwitch:self.filterRssiSwitch];
    vc.filterName = self.filterNameSwitch.isOn ? self.filterNameTextField.text : @"";
    vc.filterRssi = self.filterRssiSwitch.isOn ? [self.filterRssiTextField.text integerValue] : -100;
    vc.isSuccessSound = self.successSound.isOn;
    vc.isFaileSound       = self.faileSound.isOn;
}
@end
