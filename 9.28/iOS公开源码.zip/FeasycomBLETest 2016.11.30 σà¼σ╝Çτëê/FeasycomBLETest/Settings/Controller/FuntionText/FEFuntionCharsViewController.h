//
//  FEFuntionCharsViewController.h
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/10/6.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FEFuntionCharsViewController : UIViewController
@property (nonatomic, strong) NSString *preUUID;
@property (nonatomic, strong) NSString *notUUID;
@property (nonatomic, strong) NSString *wriUUID;
@property (nonatomic) NSInteger maxCount;
@property (nonatomic) NSInteger RSSIActual;
- (id)initWithSendString:(NSString*)sendString revertString:(NSString*)recertString successSound:(BOOL)isSuccessSound faileSound:(BOOL)isFaileSound;
@end
