//
//  FEFuntionTableViewController.h
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/9/30.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FEFuntionTableViewController : UITableViewController
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *preUUID;
@property (nonatomic, strong) NSString *notUUID;
@property (nonatomic, strong) NSString *wriUUID;
@property (nonatomic, strong) NSString *sendString;
@property (nonatomic, strong) NSString *revertString;
@property (nonatomic) NSInteger rssi;
@property (nonatomic) NSInteger RSSIActual;
@property (nonatomic) BOOL isAutoConnet;
@property (nonatomic) BOOL isSuccessSound;
@property (nonatomic) BOOL isFaileSound;
@property (nonatomic) NSInteger maxCount;
@end
