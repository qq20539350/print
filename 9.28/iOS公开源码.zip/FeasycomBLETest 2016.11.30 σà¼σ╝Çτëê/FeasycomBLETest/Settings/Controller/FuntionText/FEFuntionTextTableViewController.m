//
//  FEFuntionTextTableViewController.m
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/9/30.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEFuntionTextTableViewController.h"
#import "FEFuntionTableViewController.h"

@interface FEFuntionTextTableViewController ()
@property (nonatomic, weak) IBOutlet UITextField *nameTF;
@property (nonatomic, weak) IBOutlet UISwitch *nameSwitch;
@property (nonatomic, weak) IBOutlet UISwitch *UUIDSwitch;
@property (nonatomic, weak) IBOutlet UITextField *preUUIDTF;
@property (nonatomic, weak) IBOutlet UITextField *notUUIDTF;
@property (nonatomic, weak) IBOutlet UITextField *wriUUIDTF;
@property (nonatomic, weak) IBOutlet UITextField *sendTF;
@property (nonatomic, weak) IBOutlet UISwitch *sendSwitch;
@property (nonatomic, weak) IBOutlet UITextField *reTF;
@property (nonatomic, weak) IBOutlet UISwitch *reSwitch;
@property (nonatomic, weak) IBOutlet UITextField *rssiTF;
@property (nonatomic, weak) IBOutlet UISwitch *rssiSwitch;
@property (nonatomic, weak) IBOutlet UISwitch *autoConnet;
@property (weak, nonatomic) IBOutlet UISwitch *successSound;
@property (weak, nonatomic) IBOutlet UISwitch *faileSound;
@property (weak, nonatomic) IBOutlet UITextField *successCountTF;
@property (weak, nonatomic) IBOutlet UIStepper *successCountStepper;
@end

@implementation FEFuntionTextTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
//    if ([def objectIsForcedForKey:@"Funtion name"] )                    self.nameTF.text            = [def objectForKey:@"Funtion name"];
//    if ([def objectIsForcedForKey:@"Funtion preUUID"] )               self.preUUIDTF.text       = [def objectForKey:@"Funtion preUUID"];
//    if ([def objectIsForcedForKey:@"Funtion notUUID"] )               self.notUUIDTF.text       = [def objectForKey:@"Funtion notUUID"];
//    if ([def objectIsForcedForKey:@"Funtion wriUUID"] )               self.wriUUIDTF.text        = [def objectForKey:@"Funtion wriUUID"];
//    if ([def objectIsForcedForKey:@"Funtion send"] )                     self.sendTF.text             = [def objectForKey:@"Funtion send"];
//    if ([def objectIsForcedForKey:@"Funtion revert"] )                    self.reTF.text                 = [def objectForKey:@"Funtion revert"];
//    if ([def objectIsForcedForKey:@"Funtion rssi"] )                       self.rssiTF.text                = [def objectForKey:@"Funtion rssi"];
//    if ([def objectIsForcedForKey:@"Funtion name on"] )               self.nameSwitch.on       = [[def objectForKey:@"Funtion name on"] boolValue];
//    if ([def objectIsForcedForKey:@"Funtion UUID on"] )               self.UUIDSwitch.on       = [[def objectForKey:@"Funtion UUID on"] boolValue];
//    if ([def objectIsForcedForKey:@"Funtion send on"] )                self.sendSwitch.on        = [[def objectForKey:@"Funtion send on"] boolValue];
//    if ([def objectIsForcedForKey:@"Funtion revert on"] )               self.reSwitch.on            = [[def objectForKey:@"Funtion revert on"] boolValue];
//    if ([def objectIsForcedForKey:@"Funtion rssi on"] )                   self.rssiSwitch.on         = [[def objectForKey:@"Funtion rssi on"] boolValue];
//    if ([def objectIsForcedForKey:@"Funtion autoConnet on"] )      self.autoConnet.on       = [[def objectForKey:@"Funtion autoConnet on"] boolValue];
//    if ([def objectIsForcedForKey:@"Funtion success sound on"] ) self.successSound.on  = [[def objectForKey:@"Funtion success sound on"] boolValue];
//    if ([def objectIsForcedForKey:@"Funtion faile sound on"] )       self.faileSound.on         = [[def objectForKey:@"Funtion faile sound on"] boolValue];
//    if ([def objectIsForcedForKey:@"Success on"] )                        self.successCountTF.text = [def objectForKey:@"Success count"];
    self.nameTF.text            = [def objectForKey:@"Funtion name"];
    self.preUUIDTF.text       = [def objectForKey:@"Funtion preUUID"];
    self.notUUIDTF.text       = [def objectForKey:@"Funtion notUUID"];
    self.wriUUIDTF.text        = [def objectForKey:@"Funtion wriUUID"];
    self.sendTF.text             = [def objectForKey:@"Funtion send"];
    self.reTF.text                 = [def objectForKey:@"Funtion revert"];
    self.rssiTF.text                = [def objectForKey:@"Funtion rssi"];
    self.nameSwitch.on       = [[def objectForKey:@"Funtion name on"] boolValue];
    self.UUIDSwitch.on       = [[def objectForKey:@"Funtion UUID on"] boolValue];
    self.sendSwitch.on        = [[def objectForKey:@"Funtion send on"] boolValue];
    self.reSwitch.on            = [[def objectForKey:@"Funtion revert on"] boolValue];
    self.rssiSwitch.on         = [[def objectForKey:@"Funtion rssi on"] boolValue];
    self.autoConnet.on       = [[def objectForKey:@"Funtion autoConnet on"] boolValue];
    self.successSound.on  = [[def objectForKey:@"Funtion success sound on"] boolValue];
    self.faileSound.on         = [[def objectForKey:@"Funtion faile sound on"] boolValue];
    self.successCountTF.text = [def objectForKey:@"Success count"];
    if ([self.successCountTF.text isEqualToString:@""]) {
        self.successCountTF.text = [NSString stringWithFormat:@"%d", 0];
    }
    self.successCountStepper.value = [self.successCountTF.text integerValue];
    [self clickUUID:self.UUIDSwitch];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 8;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 1 && self.UUIDSwitch.isOn)  return 4;
    return 1;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.nameTF resignFirstResponder];
    [self.preUUIDTF resignFirstResponder];
    [self.notUUIDTF resignFirstResponder];
    [self.wriUUIDTF resignFirstResponder];
    [self.sendTF resignFirstResponder];
    [self.reTF resignFirstResponder];
    [self.rssiTF resignFirstResponder];
    [self.successCountTF resignFirstResponder];
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    [cell setSelected:NO animated:YES];
}
- (IBAction)clickUUID:(UISwitch *)sender {
    NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
    [indexPaths addObject:[NSIndexPath indexPathForRow:1 inSection:1]];
    [indexPaths addObject:[NSIndexPath indexPathForRow:2 inSection:1]];
    [indexPaths addObject:[NSIndexPath indexPathForRow:3 inSection:1]];
    if (sender.isOn) {
        [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationTop];
    }else{
        [self.tableView deleteRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationTop];
    }
}
- (IBAction)clickNameTextFieldNext:(UITextField *)sender {
    if (self.UUIDSwitch.isOn) {
        [self.preUUIDTF becomeFirstResponder];
    }else{
        [self.sendTF becomeFirstResponder];
    }
}
- (IBAction)clickPreUUIDTFNext:(UITextField *)sender {
    [self.notUUIDTF becomeFirstResponder];
}
- (IBAction)clickNotUUIDTFNext:(UITextField *)sender {
    [self.wriUUIDTF becomeFirstResponder];
}
- (IBAction)clickWriUUIDTFNext:(UITextField *)sender {
    [self.sendTF becomeFirstResponder];
}
- (IBAction)clickSendTFNext:(UITextField *)sender {
    [self.reTF becomeFirstResponder];
}
- (IBAction)clickReTFNext:(UITextField *)sender {
    [self.rssiTF becomeFirstResponder];
}
- (IBAction)clickRssiTFChange:(UITextField *)sender {
    if ([sender.text integerValue] > 0) {
        sender.text = [NSString stringWithFormat:@"%ld",-[sender.text integerValue]];
    }
    if ([sender.text integerValue] < -100) {
        sender.text = [sender.text substringWithRange:NSMakeRange(0, sender.text.length-1)];
    }
}
- (IBAction)clickSuccessCountStepper:(UIStepper *)sender {
    self.successCountTF.text = [NSString stringWithFormat:@"%ld",(NSInteger)sender.value];
    [[NSUserDefaults standardUserDefaults] setObject:self.successCountTF.text forKey:@"Success count"];
}
- (IBAction)clickSuccessCountTF:(UITextField *)sender {
    if ([sender.text integerValue] > self.successCountStepper.maximumValue) {
        sender.text = [NSString stringWithFormat:@"%ld",(NSInteger)self.successCountStepper.maximumValue];
    }
    self.successCountStepper.value = [sender.text integerValue];
    [[NSUserDefaults standardUserDefaults] setObject:sender.text forKey:@"Success count"];
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    self.successCountTF.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"Success count"];
    self.successCountStepper.value = [self.successCountTF.text integerValue];
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    [def setObject:self.nameTF.text        forKey:@"Funtion name"];
    [def setObject:self.preUUIDTF.text   forKey:@"Funtion preUUID"];
    [def setObject:self.notUUIDTF.text  forKey:@"Funtion notUUID"];
    [def setObject:self.wriUUIDTF.text  forKey:@"Funtion wriUUID"];
    [def setObject:self.sendTF.text        forKey:@"Funtion send"];
    [def setObject:self.reTF.text            forKey:@"Funtion revert"];
    [def setObject:self.rssiTF.text          forKey:@"Funtion rssi"];
    
    [def setObject:[NSString stringWithFormat:@"%d", self.nameSwitch.isOn]     forKey:@"Funtion name on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.UUIDSwitch.isOn]     forKey:@"Funtion UUID on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.sendSwitch.isOn]      forKey:@"Funtion send on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.reSwitch.isOn]          forKey:@"Funtion revert on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.rssiSwitch.isOn]        forKey:@"Funtion rssi on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.autoConnet.isOn]      forKey:@"Funtion autoConnet on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.successSound.isOn] forKey:@"Funtion success sound on"];
    [def setObject:[NSString stringWithFormat:@"%d", self.faileSound.isOn]       forKey:@"Funtion faile sound on"];
}

//跳转
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    FEFuntionTableViewController *vc  = segue.destinationViewController;
    vc.name            = self.nameSwitch.isOn ? self.nameTF.text : @"";
    vc.preUUID       = self.UUIDSwitch.isOn ? self.preUUIDTF.text : @"";
    vc.notUUID       = self.UUIDSwitch.isOn ? self.notUUIDTF.text : @"";
    vc.wriUUID       = self.UUIDSwitch.isOn ? self.wriUUIDTF.text : @"";
    vc.sendString   = self.sendSwitch.isOn  ? self.sendTF.text : @"";
    vc.revertString = self.reSwitch.isOn        ? self.reTF.text : @"";
    vc.rssi              = self.rssiSwitch.isOn     ? [self.rssiTF.text integerValue] : -100;
    vc.isAutoConnet = self.autoConnet.isOn;
    vc.isSuccessSound = self.successSound.isOn;
    vc.isFaileSound       = self.faileSound.isOn;
    vc.maxCount = self.successCountStepper.maximumValue;
}
@end
