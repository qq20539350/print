//
//  FEFuntionTableViewController.m
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/9/30.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEFuntionTableViewController.h"
#import "FESettingSearchTableViewCell.h"
#import "FEFuntionCharsViewController.h"
#import "FEShareBt.h"
#import <MJRefresh.h>


@interface FEFuntionTableViewController ()<CBCentralManagerDelegate,CBPeripheralDelegate>
//外设数组
@property (nonatomic, strong) NSMutableArray *peripherals;
//中心管理者
@property (nonatomic, strong) CBCentralManager*mgr;
//外设
@property (nonatomic, strong) CBPeripheral*peripheral;
//信号数组
@property (nonatomic, strong) NSMutableArray *RSSIs;

@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) NSTimer *connectFailTimer;
@property (nonatomic) NSInteger rowCount;
@end

@implementation FEFuntionTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //去掉列表分割线
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"FESettingSearchTableViewCell"bundle:nil] forCellReuseIdentifier:@"SettingSearchCell"];
    FEShareBt *shareBt = [FEShareBt sharedFEShareBt];
    self.peripherals = shareBt.peripherals;
    self.mgr = shareBt.mgr;
    self.RSSIs = shareBt.RSSIs;
    self.rowCount = 0;
    UIBarButtonItem*buttonI = [[UIBarButtonItem alloc] initWithTitle:FELocalizedString(@"stopScan")style:UIBarButtonItemStylePlain target:self action:@selector(openOrclosed)];
    self.navigationItem.rightBarButtonItem= buttonI;
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.connectFailTimer invalidate];
        self.tableView.userInteractionEnabled = NO;
        if (self.mgr.isScanning) [self.mgr stopScan];
        [self.peripherals removeAllObjects];
        [self.RSSIs removeAllObjects];
        self.rowCount = 0;
        [self.tableView reloadData];
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"stopScan")];
        [self.tableView.mj_header endRefreshing];
        [self.mgr scanForPeripheralsWithServices:nil options:nil];
        self.tableView.userInteractionEnabled = YES;
    }];
    //屏幕常亮
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES ];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    self.mgr.delegate = self;
//    if (self.peripheral.state == CBPeripheralStateConnected) {
//        [self.mgr cancelPeripheralConnection:self.peripheral];
//    }
    [self reflash];
    if (self.isAutoConnet){
         self.timer = [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(reflash) userInfo:nil repeats:YES];
    }
}
#pragma mark -蓝牙配置和操作
#pragma mark - CBCentralManagerDelegate
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    // 保存扫描到得外部设备
    // 判断如果数组中不包含当前扫描到得外部设置才保存
    //NSLog(@"查找设备");
    if (![self.name isEqualToString:@""] && ![peripheral.name isEqualToString:self.name]) return;
    if ([RSSI integerValue]<0 && [RSSI integerValue]>self.rssi) {
        if (![self.peripherals containsObject:peripheral]) {
            [self insertTableView:peripheral advertisementData:advertisementData RSSI:RSSI];
        }else{
            NSInteger index = [self.peripherals indexOfObject:peripheral];
            self.RSSIs[index] = RSSI;
        }
    }
}
//扫描外设
- (void)openOrclosed{
    if([self.navigationItem.rightBarButtonItem.title isEqualToString:FELocalizedString(@"scan")]) {
        NSLog(@"扫描");
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"stopScan")];
        // 利用中心设备扫描外部设备
        [self.mgr scanForPeripheralsWithServices:nil options:nil];
    }else {
        NSLog(@"停止扫描");
        [self.mgr stopScan];
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"scan")];
    }
}
#pragma mark - CBCentralManagerDelegate
//连接外设成功调用
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    [self.mgr stopScan];
    
    FEFuntionCharsViewController *vc = [[FEFuntionCharsViewController alloc] initWithSendString:self.sendString revertString:self.revertString successSound:self.isSuccessSound faileSound:self.isFaileSound];
    vc.maxCount = self.maxCount;
    vc.preUUID = self.preUUID;
    vc.notUUID = self.notUUID;
    vc.wriUUID = self.wriUUID;
    vc.RSSIActual = self.RSSIActual;
    [self.navigationController pushViewController:vc animated:YES];
    
}

//连接外设失败调用
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"断开成功 ---FEFuntionTableViewController");
    [self.connectFailTimer invalidate];
    self.connectFailTimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(tryToConnect) userInfo:nil repeats:NO];
}
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    NSLog(@"检测代理方法");
    if (central.state == CBManagerStatePoweredOn) {
        [self.mgr scanForPeripheralsWithServices:nil options:nil];
    }
    NSLog(@"%ld，%@", (long)central.state, central);
}


//插入table数据
-(void)insertTableView:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    if(![self.peripherals containsObject:peripheral]) {
        NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.peripherals.count inSection:0];
        [indexPaths addObject:indexPath];
        [self.peripherals addObject:peripheral];
        [self.RSSIs addObject:RSSI];
        [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    }else{
        NSInteger index = [self.peripherals indexOfObject:peripheral];
        self.RSSIs[index] = RSSI;
    }
    if (self.isAutoConnet) {
//        if (![[FEShareBt sharedFEShareBt].peripheralLast.identifier.UUIDString isEqualToString:peripheral.identifier.UUIDString]) {
//            NSLog(@"uuid比较%@ -- %@",[FEShareBt sharedFEShareBt].peripheralLast.identifier.UUIDString,peripheral.identifier.UUIDString);
            [self tableView:self.tableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:self.rowCount inSection:0]];
//        }
        
    }
    self.rowCount++;
}
#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.peripherals.count;
}

- (FESettingSearchTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FESettingSearchTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SettingSearchCell"];
    if(cell == nil) {
        cell = [FESettingSearchTableViewCell new];
    }
    CBPeripheral *peripheral = [self.peripherals objectAtIndex:indexPath.row];
//    if ([[FEShareBt sharedFEShareBt].peripheralLast.identifier.UUIDString isEqualToString: peripheral.identifier.UUIDString]) {
//        [cell reflashName:[NSString stringWithFormat:@"%@ (%@)", peripheral.name, FELocalizedString(@"testOK")]];
//    }else{
        [cell reflashName:peripheral.name];
//    }
    [cell reflashRSSI:[self.RSSIs[indexPath.row] integerValue]];
    cell.serviceUUIDsLabel.text = peripheral.identifier.UUIDString;
    return cell;
}
- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 70;
}
//分区头信息
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    NSString *successCountString = [[NSUserDefaults standardUserDefaults] objectForKey:@"Success count"];
    NSString *str = [NSString stringWithFormat:@"%@%@", FELocalizedString(@"successName"),
                     successCountString == nil ? @"0": successCountString];
    return str;
}
// 选择列表
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.timer invalidate];
    self.peripheral = self.peripherals[indexPath.row];
    self.RSSIActual = [self.RSSIs[indexPath.row] integerValue];
    [FEShareBt sharedFEShareBt].peripheral = self.peripherals[indexPath.row];
    [self.mgr connectPeripheral:self.peripherals[indexPath.row] options:nil];
}

-(void)tryToConnect{
    [self.mgr connectPeripheral:[FEShareBt sharedFEShareBt].peripheral options:nil];
}

-(void)reflash{
    [self.tableView.mj_header beginRefreshing];
}
@end
