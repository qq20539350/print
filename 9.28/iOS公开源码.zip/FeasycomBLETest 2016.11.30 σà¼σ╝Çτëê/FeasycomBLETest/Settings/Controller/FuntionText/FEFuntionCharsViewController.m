//
//  FEFuntionCharViewController.m
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/10/6.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEFuntionCharsViewController.h"
#import "FEShareBt.h"
#import "NSString+FEString.h"
#import <SVProgressHUD.h>
#import <AVFoundation/AVFoundation.h>

@interface FEFuntionCharsViewController ()<CBCentralManagerDelegate,CBPeripheralDelegate>
//中心管理者
@property (nonatomic, strong) CBCentralManager*mgr;
//外设
@property (nonatomic, strong) CBPeripheral*peripheral;

@property (nonatomic, strong) NSString *sendString;
@property (nonatomic, strong) NSString *revertString;
@property (nonatomic) BOOL isSuccessSound;
@property (nonatomic) BOOL isFaileSound;
@property (weak, nonatomic) IBOutlet UITextView *showTV;
@property (weak, nonatomic) IBOutlet UILabel *countLabel;

@property (nonatomic, strong) CBCharacteristic *characteristic;
@property (nonatomic, strong) CBCharacteristic *wrNoReCharacteristic;
@property (nonatomic, strong) CBCharacteristic *wrCharacteristic;
//音频(本地音频)
@property (nonatomic, strong) AVAudioPlayer *playerOK;
@property (nonatomic, strong) AVAudioPlayer *playerAllarm;

@property (nonatomic, strong) NSTimer *timeout;
@property (nonatomic, strong) NSTimer *fineServiceTimeout;
@end

@implementation FEFuntionCharsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    FEShareBt *share = [FEShareBt sharedFEShareBt];
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    self.mgr = share.mgr;
    self.mgr.delegate = self;
    self.peripheral = share.peripheral;
    self.peripheral.delegate = self;
    self.wrNoReCharacteristic = share.wrNoReCharacteristic;
    NSString *successCountString = [def objectForKey:@"Success count"];
    self.countLabel.text = successCountString == nil ? @"0" : successCountString;
    //1.音频文件路径
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"allarm" ofType:@"mp3"];
    //2.创建对象(执行文件)
    self.playerAllarm = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:audioPath] error:nil];
    //1.音频文件路径
    audioPath = [[NSBundle mainBundle] pathForResource:@"OK" ofType:@"mp3"];
    //2.创建对象(执行文件)
    self.playerOK = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:audioPath] error:nil];
    
//    BOOL isSound = [[def objectForKey:@"Funtion sound on"] boolValue];
//    self.isSuccessSound = isSound ? [[def objectForKey:@"Funtion success sound on"] boolValue] : NO;
//    self.isFaileSound       = isSound ? [[def objectForKey:@"Funtion faile sound on"] boolValue] : NO;
    //开始扫描服务
    [self.peripheral discoverServices:nil];
    //NSLog(@"self.peripheral = %@", self.peripheral);
    if ([def boolForKey:@"Funtion name on"]) [self addString:FELocalizedString(@"nameOK")];
    if ([def boolForKey:@"Funtion rssi on"]) [self addString:FELocalizedString(@"RSSIOK")];
    if (![self.preUUID isEqualToString:@""]){
        [self addString:FELocalizedString(@"checkServerUUID")];
    }else if (![self.notUUID isEqualToString:@""]) {
        [self addString:FELocalizedString(@"checkNotUUID")];
    }else if (![self.wriUUID isEqualToString:@""]) {
        [self addString:FELocalizedString(@"checkWriUUID")];
    }
    //超时主动断开
    self.timeout = [NSTimer scheduledTimerWithTimeInterval:4.5 target:self selector:@selector(goingTimeout) userInfo:nil repeats:NO];
    self.fineServiceTimeout = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(discoverAgain) userInfo:nil repeats:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    self.peripheral.delegate = self;
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.timeout invalidate];
}

-(id)initWithSendString:(NSString *)sendString revertString:(NSString *)revertString successSound:(BOOL)isSuccessSound faileSound:(BOOL)isFaileSound{
    if (self = [super init]) {
        self.sendString = sendString;
        self.revertString = revertString;
        self.isSuccessSound = isSuccessSound;
        self.isFaileSound = isFaileSound;
    }
    return self;
}

#pragma mark -蓝牙配置和操作
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    NSLog(@"检测代理方法");
    if (central.state == CBManagerStatePoweredOn) {
        //[self.mgr scanForPeripheralsWithServices:nil options:nil];
    }
    NSLog(@"%ld，%@", (long)central.state, central);
}
//连接外设成功调用
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    [self.peripheral discoverServices:nil];
}
//连接外设失败调用
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSLog(@"断开成功mgr = %@ per= %@",self.mgr, self.peripheral);
//    [self.navigationController popViewControllerAnimated:YES];
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    NSLog(@"扫描服务");
    // 获取外设中所有扫描到得服务
    NSArray *services = peripheral.services;
    for (CBService *service in services) {
        if ([self.preUUID isEqualToString:@""] || [self.preUUID isEqualToString:service.UUID.UUIDString]) {
            if ([self.preUUID isEqualToString:service.UUID.UUIDString]) {
                [self addString:FELocalizedString(@"serverUUIDOK")];
                if (![self.notUUID isEqualToString:@""]) {
                    [self addString:FELocalizedString(@"checkNotUUID")];
                }
            }
            //拿到需要的服务
            //NSLog(@"服务%@", service.UUID.UUIDString);
            //从peripheral中得service中扫描特征
            [peripheral discoverCharacteristics:nil forService:service];
        }
    }
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    //NSLog(@"扫描特征");
    // 遍历特征, 拿到需要的特征处理
    for (CBCharacteristic * characteristic in service.characteristics) {
        if (characteristic.properties & CBCharacteristicPropertyNotify ||  characteristic.properties & CBCharacteristicPropertyIndicate) {
            //拿到可读的特征了
            [self.peripheral setNotifyValue:YES forCharacteristic:characteristic];
            if (!self.characteristic)  {
                if ([self.notUUID isEqualToString:@""] || [self.notUUID isEqualToString:characteristic.UUID.UUIDString]) {
                    if ([self.notUUID isEqualToString:characteristic.UUID.UUIDString]) {
                        [self addString:FELocalizedString(@"notUUIDOK")];
                    }
                    //NSLog(@"可读");
                    if (![self.wriUUID isEqualToString:@""]) {
                        [self addString:FELocalizedString(@"checkWriUUID")];
                    }
                    self.characteristic = characteristic;
                }
            }
        }
        if (characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse){
            //拿到可写的特征了
            if (!self.wrNoReCharacteristic) {
                if ([self.wriUUID isEqualToString:@""] || [self.wriUUID isEqualToString:characteristic.UUID.UUIDString]) {
                    if ([self.wriUUID isEqualToString:characteristic.UUID.UUIDString]) {
                        [self addString:FELocalizedString(@"wriUUIDOK")];
                    }
                    //NSLog(@"可写");
                    self.wrNoReCharacteristic = characteristic;
                    //发送部分
                    if (![self.sendString isEqualToString:@""]) {
                        NSString *strSend = [NSString stringWithFormat:@"\r\n$APP=1,%02ld,%03ld,%@\r\n", -self.RSSIActual, self.sendString.length, self.sendString];
                        NSLog(@"strSend:\n%@", strSend);
                        [self.peripheral writeValue:[strSend dataUsingEncoding:NSASCIIStringEncoding]  forCharacteristic:self.wrNoReCharacteristic type:CBCharacteristicWriteWithResponse];
                    }
                }
            }
        }else if (characteristic.properties & CBCharacteristicPropertyWrite){
            if(!self.wrCharacteristic) self.wrCharacteristic = characteristic;
        }
    }
}


//接收数据
- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    NSLog(@"收到数据");
    if (!error){
        if (![self.revertString isEqualToString:@""]){
            NSString *revertString = [NSString stringWithFormat:@"AT$APP=1,%03ld,%@\r\n", self.revertString.length, self.revertString];
            NSString *reStr = [[NSString alloc] initWithData:characteristic.value encoding:NSASCIIStringEncoding];
            if ([reStr isEqualToString:@"AT$APP=0\r\n"]) {
                [self failureWith:FELocalizedString(@"seNoEqualRe")];
                return;
            }
            if ([reStr isEqualToString:revertString]) {
                [self addString:FELocalizedString(@"reEqualToSe")];
                NSLog(@"--------->%@",FELocalizedString(@"reEqualToSe"));
                [self.peripheral writeValue:[@"\r\n$APP=2\r\n" dataUsingEncoding:NSASCIIStringEncoding]  forCharacteristic:self.wrNoReCharacteristic type:CBCharacteristicWriteWithResponse];
                self.peripheral.delegate = nil;
            }else if (![self.revertString isEqualToString:@""]){
                NSLog(@"%@", self.revertString);
                [self.peripheral writeValue:[@"\r\n$APP=0\r\n" dataUsingEncoding:NSASCIIStringEncoding]  forCharacteristic:self.wrNoReCharacteristic type:CBCharacteristicWriteWithResponse];
                [self failureWith:FELocalizedString(@"reNoEqualToSe")];
                return;
            }
        }
        [self addString:FELocalizedString(@"testSuccess")];
        //计数+1
        NSInteger count = [self.countLabel.text integerValue];
        count++;
        [FEShareBt sharedFEShareBt].peripheralLast = peripheral;
        //如果超出计数范围，从0开始
        if (count > self.maxCount) {
            count = 0;
        }
        self.countLabel.text = [NSString stringWithFormat:@"%ld",count];
        [[NSUserDefaults standardUserDefaults] setObject:self.countLabel.text forKey:@"Success count"];
//        [self.mgr cancelPeripheralConnection:self.peripheral];
        if (self.isSuccessSound) [self.playerOK play];
        [self.timeout invalidate];
        [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(popBack) userInfo:nil repeats:NO];
    }else{
        [self failureWith:FELocalizedString(@"reErr")];
    }
}
//发送消息成功
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    if (!error) {
        [self addString:FELocalizedString(@"sent")];
    }else{
        [self failureWith:FELocalizedString(@"sendErr")];
    }
    
}
-(void)popBack{
    NSLog(@"返回");
    [self.mgr cancelPeripheralConnection:self.peripheral];
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma 自己的方法
-(void)addString:(NSString *)string{
    //自定义时间格式输出
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"[hh:mm:ss] ";
    NSString *dateStr = [dateFormatter stringFromDate:[NSDate new]];
    string = [string stringByAppendingString:@"\r\n"];
    dateStr = [dateStr stringByAppendingString:string];
    self.showTV.text = [self.showTV.text stringByAppendingString:dateStr];
}

-(void)goingTimeout{
    NSLog(@"超时");
    [self.fineServiceTimeout invalidate];
    [self failureWith:FELocalizedString(@"timeout")];
}
-(void)discoverAgain{
    if (!self.characteristic || !self.wrNoReCharacteristic) {
        NSLog(@"找不到服务");
        [SVProgressHUD showInfoWithStatus:FELocalizedString(@"noServer")];
        [self addString:FELocalizedString(@"noServer")];
        if (self.isFaileSound){
            NSLog(@"警告声");
            [self.playerAllarm play];
        }
        [self.mgr cancelPeripheralConnection:self.peripheral];
        [self.mgr connectPeripheral:self.peripheral options:nil];
        self.fineServiceTimeout = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(discoverAgain) userInfo:nil repeats:NO];
    }
}
-(void)failureWith:(NSString *)string{
    self.peripheral.delegate = nil;
    //自定义时间格式输出
    NSInteger showTVLength = self.showTV.text.length;
    [self addString:string];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:self.showTV.text];
    //字体颜色
    [str addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(showTVLength-1,str.length-showTVLength)];
    //字体粗细大小
    [str addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0] range:NSMakeRange(0,showTVLength-1)];
    [str addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue-Bold" size:14.0] range:NSMakeRange(showTVLength-1,str.length-showTVLength)];
    self.showTV.attributedText = str;
    if (self.isFaileSound){
        NSLog(@"警告声");
        [self.playerAllarm play];
    }
    [self.timeout invalidate];
    UIAlertView *ale = [[UIAlertView alloc]initWithTitle:nil message:string delegate:self cancelButtonTitle:nil otherButtonTitles:FELocalizedString(@"ok"), nil];
    ale.delegate = self;
    [ale show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"dianjiAlert");
     [self.mgr cancelPeripheralConnection:self.peripheral];
}
-(void)dealloc{
    //NSLog(@"~~~~~~~~~~~~~~~~~~~~~~~~");
}

@end
