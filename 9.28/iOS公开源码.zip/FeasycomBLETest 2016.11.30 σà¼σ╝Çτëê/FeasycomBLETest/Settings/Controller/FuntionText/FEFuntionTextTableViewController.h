//
//  FEFuntionTextTableViewController.h
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/9/30.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FEFuntionTextTableViewController : UITableViewController

@end
