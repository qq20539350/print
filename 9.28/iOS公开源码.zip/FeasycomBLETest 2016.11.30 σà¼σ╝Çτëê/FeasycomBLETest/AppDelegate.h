//
//  AppDelegate.h
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/7/22.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic) NSURL *url;
@property (strong, nonatomic) UIWindow *window;


@end

