//
//  FEShareBt.m
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/9/28.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FEShareBt.h"



@implementation FEShareBt
singleton_implementation(FEShareBt)
-(NSMutableArray<NSData *> *)allTheSendDataBy:(NSString *)string{
    NSMutableArray *dataArray = [NSMutableArray array];
    NSInteger length = string.length;
    for (int i=0; i<length/PACKAGE_LENGTH; i++) {
        NSRange range = NSMakeRange(i*PACKAGE_LENGTH, PACKAGE_LENGTH);
        NSString *stringpartPart = [string substringWithRange:range];
        NSData *data = [stringpartPart dataUsingEncoding:NSUTF8StringEncoding];
        [dataArray addObject:data];
    }
    if (string.length%PACKAGE_LENGTH) {
        NSString *stringpartPart = [string substringFromIndex:string.length-string.length%PACKAGE_LENGTH];
        NSData *data = [stringpartPart dataUsingEncoding:NSUTF8StringEncoding];
        [dataArray addObject:data];
    }
    return dataArray;
}
-(void)DFUUpdata{
    NSLog(@"开始进入DFU升级");
    [self.delegate DFUUpdata];
}
@end
