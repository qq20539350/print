//
//  FEShareBt.h
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/9/28.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <Foundation/Foundation.h>
#import  <CoreBluetooth/CoreBluetooth.h>
#import "Singleton.h"
@class FEShareBt;
@protocol FEShareBtDelegate <NSObject>
-(void)DFUUpdata;
@optional //可选实现

@end

@interface FEShareBt : NSObject
singleton_interface(FEShareBt)
@property(nonatomic,weak)id<FEShareBtDelegate> delegate;
//外设数组
@property (nonatomic, strong) NSMutableArray *peripherals;
//中心管理者
@property (nonatomic, strong) CBCentralManager*mgr;
//外设
@property (nonatomic, strong) CBPeripheral*peripheral;
//可写
@property (nonatomic, strong) CBCharacteristic *wrNoReCharacteristic;
//信号数组
@property (nonatomic, strong) NSMutableArray *RSSIs;
//连接的设备名
@property (nonatomic, strong) NSString *connetedName;
//最后一次连接的设备
@property (nonatomic, strong) CBPeripheral *peripheralLast;
-(NSMutableArray<NSData*>*)allTheSendDataBy:(NSString*)string;
-(void)DFUUpdata;
@end
