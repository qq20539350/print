//
//  FECommunicationTableViewCell.m
//  FeasycomLE
//
//  Created by 余明悦 on 16/7/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FECommunicationTableViewCell.h"

#define LAYOUTCONSTANT(number) (14 + (CGFloat)(100 + number) * 41 / 100)

@interface FECommunicationTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *RSSILabel;
@property (nonatomic) NSInteger eachRSSI;
@property (nonatomic) NSInteger beforeRSSI;
@property (nonatomic) NSInteger afterRSSI;
@property (atomic, strong) NSTimer *animateTimer;
@property (atomic) NSInteger count;
@property (weak, nonatomic) IBOutlet UIProgressView *RSSIProgerssView;
@end
@implementation FECommunicationTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.beforeRSSI = 0;
    self.afterRSSI = 0;
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)reflashName:(NSString *)name{
    if (name) {
        self.nameLabel.textColor = [UIColor blueColor];
        self.nameLabel.text = name;
    }else{
        self.nameLabel.textColor = [UIColor redColor];
        self.nameLabel.text = FELocalizedString(@"unname");
    }
}

- (void)reflashRSSI:(NSInteger)RSSI {
//    self.beforeRSSI = self.afterRSSI;
//    self.afterRSSI = RSSI;
//    self.count = 10;
//    NSInteger betweenRSSI = (RSSI - self.beforeRSSI)/10;
//    if (RSSI > self.beforeRSSI) {
//        self.eachRSSI = betweenRSSI < 1 ? 1 : betweenRSSI;
//    }else{
//        self.eachRSSI = betweenRSSI > -1 ? -1 : betweenRSSI;
//    }
    self.RSSILabel.text = [NSString stringWithFormat:@"%ld", RSSI];
//    if (self.animateTimer) {
//        [self.animateTimer invalidate];
//        self.animateTimer = nil;
//    }
//    self.animateTimer = [NSTimer timerWithTimeInterval:0.1 target:self selector:@selector(rssiAnimate) userInfo:nil repeats:YES];
    [self.RSSIProgerssView setProgress:(100+RSSI) / 100.0 animated:YES];
}

//-(void)rssiAnimate{
//    self.RSSIProgerssView.progress = (100+self.beforeRSSI+self.eachRSSI) / 100.0;
//    self.count--;
//    if (self.count < 1) {
//        [self.animateTimer invalidate];
//        self.animateTimer = nil;
//    }
//}

@end
