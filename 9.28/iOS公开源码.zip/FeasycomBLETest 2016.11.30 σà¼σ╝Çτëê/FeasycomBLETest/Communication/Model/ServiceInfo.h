//
//  PeripheralInfo.h
//  BabyBluetoothAppDemo
//
//  Created by 刘彦玮 on 15/8/6.
//  Copyright (c) 2015年 刘彦玮. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface ServiceInfo : NSObject

@property (nonatomic,strong) CBService *service;
@property (nonatomic,strong) NSMutableArray *readCharacteristics;
@property (nonatomic,strong) NSMutableArray *readNoReCharacteristics;
@property (nonatomic,strong) NSMutableArray *writeCharacteristics;
@property (nonatomic,strong) NSMutableArray *writeNoReCharacteristics;

- (id)initWithService:(CBService*)service;
- (void)reflashCharacteristics;
@end
