//
//  PeripheralInfo.m
//  BabyBluetoothAppDemo
//
//  Created by 刘彦玮 on 15/8/6.
//  Copyright (c) 2015年 刘彦玮. All rights reserved.
//

#import "ServiceInfo.h"

@implementation ServiceInfo

-(instancetype)init{
    self = [super init];
    if (self) {
        _readCharacteristics = [[NSMutableArray alloc]init];
        _writeNoReCharacteristics = [[NSMutableArray alloc]init];
        _writeCharacteristics = [[NSMutableArray alloc]init];
    }
    return self;
}
-(id)initWithService:(CBService *)service{
    if (self = [super init]) {
        _readCharacteristics = [[NSMutableArray alloc] init];
        _readNoReCharacteristics = [[NSMutableArray alloc] init];
        _writeNoReCharacteristics = [[NSMutableArray alloc]init];
        _writeCharacteristics = [[NSMutableArray alloc]init];
        _service = service;
    }
    return self;
}
-(void)reflashCharacteristics{
    [self.readCharacteristics removeAllObjects];
    [self.readNoReCharacteristics removeAllObjects];
    [self.writeCharacteristics removeAllObjects];
    [self.writeNoReCharacteristics removeAllObjects];
    // 遍历特征, 拿到需要的特征处理
    for (CBCharacteristic * characteristic in self.service.characteristics) {
        if (characteristic.properties & CBCharacteristicPropertyBroadcast) {
            
        }else if (characteristic.properties & CBCharacteristicPropertyRead) {
            
        }else if (characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse){
            //拿到可写WithoutResponse的特征了
            [self.writeNoReCharacteristics addObject:characteristic];
        }else if (characteristic.properties & CBCharacteristicPropertyWrite){
            //拿到可写的特征了
            [self.writeCharacteristics addObject:characteristic];
        }else if (characteristic.properties & CBCharacteristicPropertyNotify){
            //拿到可读的无反馈特征了
            [self.readNoReCharacteristics addObject:characteristic];
        }else if (characteristic.properties & CBCharacteristicPropertyIndicate){
            //拿到可读的特征了
            [self.readCharacteristics addObject:characteristic];
        }else if (characteristic.properties & CBCharacteristicPropertyAuthenticatedSignedWrites){
            
        }else if (characteristic.properties & CBCharacteristicPropertyExtendedProperties){
            
        }else if (characteristic.properties & CBCharacteristicPropertyNotifyEncryptionRequired){
            
        }else if (characteristic.properties & CBCharacteristicPropertyIndicateEncryptionRequired){
          
        }
    }
}
@end
