//
//  NSString+FEString.m
//  FeasycomBLETest
//
//  Created by 余明悦 on 16/9/21.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "NSString+FEString.h"

@implementation NSString (FEString)
-(NSData*) hexToData {
    NSMutableData* data = [NSMutableData data];
    int idx;
    NSString *str = [[[self stringByReplacingOccurrencesOfString:@" " withString:@""]
                     stringByReplacingOccurrencesOfString:@"\r" withString:@""]
                     stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSLog(@"%@", str);
    for (idx = 0; idx+2 <= str.length; idx+=2) {
        NSRange range = NSMakeRange(idx, 2);
        NSString* hexStr = [str substringWithRange:range];
        NSScanner* scanner = [NSScanner scannerWithString:hexStr];
        unsigned int intValue;
        [scanner scanHexInt:&intValue];
        [data appendBytes:&intValue length:1];
    }
    return data;
}

-(NSData *)UTF8ToData{
    return [self dataUsingEncoding:NSUTF8StringEncoding];
}

-(NSString *)dataToHex:(NSData *)data{
    if (data.length){
        return [[[NSString stringWithFormat:@"%@",data]
              stringByReplacingOccurrencesOfString: @"<" withString: @""]
             stringByReplacingOccurrencesOfString: @">" withString: @""];
    }else{
        return @"";
    }
}

-(NSString *)dataToUTF8:(NSData *)data{
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}
@end
