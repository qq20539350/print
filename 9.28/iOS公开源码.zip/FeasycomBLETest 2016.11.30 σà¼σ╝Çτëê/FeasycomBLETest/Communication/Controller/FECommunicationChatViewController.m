//
//  FECommunicationChatViewController.m
//  FeasycomLE
//
//  Created by 余明悦 on 16/7/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FECommunicationChatViewController.h"
#import <zlib.h>
#import <SVProgressHUD.h>
#import "NSString+FEString.h"
#import "ServiceInfo.h"
#import "FESendFileTableViewController.h"
#import "FEChangeServiceTableViewController.h"

@interface FECommunicationChatViewController ()<UITextViewDelegate,CBCentralManagerDelegate,CBPeripheralDelegate,FESendFileTableViewControllerDelegate,FEChangeServiceTableViewControllerDelegate>

@property (nonatomic, strong) NSMutableArray *services;

@property (nonatomic) NSInteger reByte;
@property (nonatomic) NSInteger rePackage;
@property (nonatomic) NSInteger sendByte;
@property (nonatomic) NSInteger sendPackage;
@property (nonatomic) NSInteger sendedFileCount;
@property (nonatomic, strong) NSMutableData *reData;
@property (nonatomic, strong) NSMutableArray *reDataArr;
@property (nonatomic, strong) NSData *sendData;
@property (nonatomic, strong) NSThread *reflashViewThread;
@property (nonatomic) BOOL isStopReViTread;
@property (nonatomic) BOOL isClickHexSendSwitch;
@property (nonatomic) BOOL isSendingFile;
@property (nonatomic) BOOL isConnected;
@property (nonatomic) NSUInteger crcRe;
@property (nonatomic) NSUInteger crcSe;
@property (nonatomic, strong) UIButton *rightBtn;
@property (nonatomic, strong) UILabel *rightLabel;
@property (nonatomic, strong) NSTimer *readRssiTimer;
@property (nonatomic, strong) NSTimer *reDataTimer;
//速率
@property (nonatomic, strong) NSTimer *speed_timer;
@property (nonatomic) NSInteger speed_timeS;//秒数
@property (nonatomic) NSInteger speed_bytesCount;
@property (nonatomic) NSInteger speed_bytesCount2;
@property (nonatomic) NSInteger speed_bytesCount3;
@property (nonatomic) NSInteger speed_bytesCount4;
@property (nonatomic) NSInteger speed_bytesCount5;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *layout_bottom;
@property (weak, nonatomic) IBOutlet UISwitch *hexRe;
@property (weak, nonatomic) IBOutlet UIButton *clearBtn;
@property (weak, nonatomic) IBOutlet UILabel *reByteLabel;
@property (weak, nonatomic) IBOutlet UILabel *rePackageLabel;
@property (weak, nonatomic) IBOutlet UILabel *crcReLabel;
@property (weak, nonatomic) IBOutlet UITextView *reTextView;
@property (weak, nonatomic) IBOutlet UILabel *sendByteLabel;
@property (weak, nonatomic) IBOutlet UILabel *sendPackageLabel;
@property (weak, nonatomic) IBOutlet UILabel *crcSeLabel;
@property (weak, nonatomic) IBOutlet UITextView *sendTextView;
@property (weak, nonatomic) IBOutlet UITextField *intervalTextField;
@property (weak, nonatomic) IBOutlet UISwitch *intervalSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *hexSend;
@property (weak, nonatomic) IBOutlet UISwitch *responseSwitch;
@property (weak, nonatomic) IBOutlet UIButton *sendButton;
@property (weak, nonatomic) IBOutlet UIButton *sendFileBtn;
//发送文件
@property (weak, nonatomic) IBOutlet UIView *sendFileView;
@property (weak, nonatomic) IBOutlet UIProgressView *sfProgressView;
@property (weak, nonatomic) IBOutlet UILabel *sfPercenLabel;
@property (weak, nonatomic) IBOutlet UILabel *sfSendedLabel;
@property (weak, nonatomic) IBOutlet UILabel *sfSendCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *sfSpeedLabel;
@property (weak, nonatomic) IBOutlet UILabel *sfRunTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *totalLabel;
@end

@implementation FECommunicationChatViewController

//////////////////////////////////////////////////////////////  全局变量  //////////////////////////////////////////////////////////////
//接收模式
NSInteger sendStata = 0;
NSInteger sendWhenError = 0;//发送错误重试计数

//发送文件
NSInteger fileLength = 0;
NSInteger packageCount = 0;
NSInteger sendWitchPlace = 0;
NSData *fileSendingData;
NSUInteger reDataLength = 0;
BOOL isFlashView = NO;
BOOL isReing = NO;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (void)viewDidLoad {
    [super viewDidLoad];
    //配置信号
    // 创建一个使用本来的样式进行渲染的图片
    UIImage *rightImage = [[UIImage imageNamed:@"rssi 5"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    self.rightBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 35, 35)];
    [self.rightBtn setBackgroundImage:rightImage forState:UIControlStateNormal];
    [self.rightBtn addTarget:self action:@selector(clickRbImage) forControlEvents:UIControlEventTouchUpInside];
    UIView *rView1= [[UIView alloc]initWithFrame:CGRectMake(0, 0, 35, 35)];
    [rView1 addSubview:self.rightBtn];
    UIBarButtonItem *rb_rssi_image = [[UIBarButtonItem alloc] initWithCustomView:rView1];
    self.rightLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [self.rightLabel setTextColor:[UIColor blueColor]];
    UIView *rView2= [[UIView alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
    [rView2 addSubview:self.rightLabel];
    UIBarButtonItem *rb_rssi_text = [[UIBarButtonItem alloc] initWithCustomView:rView2];
    //在导航栏右侧添加按钮
    self.navigationItem.rightBarButtonItems=@[rb_rssi_image, rb_rssi_text];
    self.navigationItem.title = [FEShareBt sharedFEShareBt].connetedName;
    
    self.sendTextView.delegate = self;
    self.currPeripheral.delegate = self;
    self.mgr.delegate = self;
    self.isStopReViTread = NO;
    self.isClickHexSendSwitch = NO;
    self.isSendingFile = NO;
    self.isConnected = YES;
    [self.reData setLength:0];
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    //开始扫描服务
    [self.currPeripheral discoverServices:nil];
    [SVProgressHUD showInfoWithStatus:FELocalizedString(@"connected")];
    //self.reflashViewThread = [[NSThread alloc] initWithTarget:self selector:@selector(reflashView) object:nil];
    //self.reTextView.layoutManager.allowsNonContiguousLayout = NO;
    //读取上一次设置
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    self.hexRe.on = [def boolForKey:@"hexReSwitch"];
    self.hexSend.on = [def boolForKey:@"hexSendSwitch"];
    self.responseSwitch.on = [def boolForKey:@"responseSwitch"];
    self.rightLabel.hidden = [def boolForKey:@"rightLabelHidden"];
    NSString *intervalText = [def stringForKey:@"intervalTime"];
    self.intervalTextField.text = intervalText.length>0 ? intervalText : FELocalizedString(@"hundred");
    self.crcSe = crc32(0L, Z_NULL, 0);
    self.crcRe = crc32(0L, Z_NULL, 0);
    self.sendData = [def dataForKey:@"sendData"];
    self.sendTextView.text = self.hexSend.isOn ? [self.sendTextView.text dataToHex:self.sendData] : [self.sendTextView.text dataToUTF8:self.sendData];
}

#pragma 蓝牙部分
//连接外设失败调用
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    //    [self showTheAlertViewWithMassage:@"链接失败"];
    NSLog(@"断开链接");
    self.isConnected = NO;
    self.navigationItem.title = FELocalizedString(@"disconnected");
    [self.readRssiTimer invalidate];
    [self.rightBtn setBackgroundImage:[UIImage imageNamed:@"rssi 0"] forState:UIControlStateNormal];
    self.rightLabel.hidden = YES;
    UIAlertView *lock =[[UIAlertView alloc]initWithTitle:FELocalizedString(@"disconnected") message:nil delegate:self cancelButtonTitle:FELocalizedString(@"ok") otherButtonTitles: nil];
    [lock show];
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    NSLog(@"扫描服务");
    // 获取外设中所有扫描到得服务
    NSArray *services = peripheral.services;
    for (CBService *service in services) {
        //拿到需要的服务
        NSLog(@"服务%@", service.UUID.UUIDString);
        ServiceInfo *serviceInfo = [[ServiceInfo alloc] initWithService:service];
        [self.services addObject:serviceInfo];
        //从peripheral中得service中扫描特征
        [peripheral discoverCharacteristics:nil forService:service];
    }
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    NSLog(@"扫描到服务%@的%lu个特征", service.UUID.UUIDString, service.characteristics.count);
    // 遍历特征, 拿到需要的特征处理
    for (CBCharacteristic * characteristic in service.characteristics) {
        if (characteristic.properties & CBCharacteristicPropertyNotify || characteristic.properties & CBCharacteristicPropertyIndicate) {
            //拿到可读的特征了
            [self.currPeripheral setNotifyValue:YES forCharacteristic:characteristic];
        }
        if (characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse){
            //拿到可写的特征了
            if (!self.wrNoReCharacteristic) self.wrNoReCharacteristic = characteristic;
        }
        if (characteristic.properties & CBCharacteristicPropertyWrite){
            if (!self.wrCharacteristic) self.wrCharacteristic = characteristic;
        }
    }
}
//处理蓝牙发送过来的数据
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForDescriptor:(CBDescriptor *)descriptor error:(NSError *)error{
    NSLog(@"接收到数据");
    
}


- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    dispatch_async(dispatch_queue_create("readQueue", DISPATCH_QUEUE_SERIAL), ^{
        isReing = YES;
        NSUInteger reLength = characteristic.value.length;
        self.reByte += reLength;
        self.rePackage ++;
        [self.reDataTimer invalidate];
        self.reDataTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(reflashView) userInfo:nil repeats:NO];
        self.crcRe = crc32(self.crcRe, characteristic.value.bytes, (uint32_t)reLength);
        reDataLength = self.reData.length;
        if (reDataLength > 2000){
            [self.reData setLength:0];
        }
        [self.reData appendData:characteristic.value];
        
        if (isFlashView) return;
        isFlashView = YES;
        //    NSLog(@"----------");
        dispatch_sync(dispatch_queue_create("readConcurrentQueue", DISPATCH_QUEUE_SERIAL), ^{
            //        NSLog(@"进入线程");
            NSString *stringR = @"";
            stringR = self.hexRe.isOn ? [stringR dataToHex:self.reData] : [stringR dataToUTF8:self.reData];
            NSString *stringB = [NSString stringWithFormat:@"%ld", self.reByte];
            NSString *stringP = [NSString stringWithFormat:@"%ld", self.rePackage];
            NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",self.crcRe];
            dispatch_async(dispatch_get_main_queue(),^{
                self.reByteLabel.text = stringB;
                self.rePackageLabel.text = stringP;
                self.reTextView.text = stringR;
                self.crcReLabel.text = crcShow;
                [self.reTextView scrollRectToVisible:CGRectMake(0, self.reTextView.contentSize.height-15, self.reTextView.contentSize.width, 10) animated:YES];
                //            NSLog(@"------------No");
                isFlashView = NO;
            });
            [NSThread sleepForTimeInterval:0.02];
            //        NSLog(@"++++++++++");
        });
        isReing = NO;
    });
}

//发送消息成功
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    switch (sendStata) {
        case 0:
            if (error) {
                NSLog(@"发送失败~");
                if (self.responseSwitch.isOn && sendWhenError<RESENDWHENERRORCOUNT) {
                    sendWhenError++;
                    [self.currPeripheral writeValue:self.sendData forCharacteristic:self.wrCharacteristic type:CBCharacteristicWriteWithResponse];
                }
            }else{
                sendWhenError = 0;
                if (self.responseSwitch.isOn) {
                    dispatch_barrier_async(dispatch_queue_create("sendConcurrentQueue", DISPATCH_QUEUE_SERIAL), ^{
                        self.crcSe = crc32(self.crcSe, self.sendData.bytes, (uint32_t)self.sendData.length);
                        self.sendByte += self.sendData.length;
                        self.sendPackage++;
                        NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",self.crcSe];
                        dispatch_barrier_async(dispatch_get_main_queue(),^{
                            self.sendByteLabel.text = [NSString stringWithFormat:@"%ld", self.sendByte];
                            self.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", self.sendPackage];
                            self.crcSeLabel.text = crcShow;
                        });
                    });
                }
            }
            break;
        case 1:
            if (error) {
                NSLog(@"发送文件失败");
                if (self.responseSwitch.isOn && sendWhenError<RESENDWHENERRORCOUNT) {
                    sendWhenError++;
                    [self.currPeripheral writeValue:fileSendingData forCharacteristic:self.wrCharacteristic type:CBCharacteristicWriteWithResponse];
                }
            }else{
                if (self.responseSwitch.isOn){
                    sendWhenError = 0;
                    dispatch_async(dispatch_queue_create("sendFileConcurrentQueue", DISPATCH_QUEUE_SERIAL), ^{
                        while (isFlashView && isReing && self.isConnected) {
                            NSLog(@"等待中");
                            [NSThread sleepForTimeInterval:0.01];
                        }
                        isFlashView = YES;
                        sendWitchPlace++;
                        self.crcSe = crc32(self.crcSe, fileSendingData.bytes, (uint32_t)fileSendingData.length);
                        self.sendByte += fileSendingData.length;
                        self.sendedFileCount += fileSendingData.length;
                        self.speed_bytesCount += fileSendingData.length;
                        self.sendPackage++;
                        NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",self.crcSe];
                        dispatch_async(dispatch_get_main_queue(),^{
                            self.sendByteLabel.text = [NSString stringWithFormat:@"%ld", self.sendByte];
                            self.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", self.sendPackage];
                            self.crcSeLabel.text = crcShow;
                            isFlashView = NO;
                        });
                        if (sendWitchPlace == packageCount-1) {
                            if (fileLength%PACKAGE_LENGTH > 0) {
                                fileSendingData = [fileSendingData subdataWithRange:NSMakeRange(0, fileLength%PACKAGE_LENGTH)];
                            }
                        }
                        if (self.isSendingFile && sendWitchPlace < packageCount) {
                            if(self.wrCharacteristic) [self.currPeripheral writeValue:fileSendingData forCharacteristic:self.wrCharacteristic type:CBCharacteristicWriteWithResponse];
                        }else{
                            [self stopSendingFile];
                        }
                        [self reflashSendFileView];
                    });
                }
            }
            break;
        default:
            break;
    }
}

- (void)peripheral:(CBPeripheral *)peripheral didReadRSSI:(NSNumber *)RSSI error:(NSError *)error{
    [self.rightLabel setText:[NSString stringWithFormat:@"%@", RSSI]];
    NSInteger rssi = [RSSI integerValue];
    UIImage *rssiImage = self.rightBtn.currentBackgroundImage;
    switch (rssi) {
        case -100 ... -96:
            rssiImage = [UIImage imageNamed:@"rssi 0"];
            break;
        case -95 ... -86:
            rssiImage = [UIImage imageNamed:@"rssi 1"];
            break;
        case -85 ... -76:
            rssiImage = [UIImage imageNamed:@"rssi 2"];
            break;
        case -75 ... -66:
            rssiImage = [UIImage imageNamed:@"rssi 3"];
            break;
        case -65 ... -51:
            rssiImage = [UIImage imageNamed:@"rssi 4"];
            break;
        case -50 ... 0:
            rssiImage = [UIImage imageNamed:@"rssi 5"];
            break;
        default:
            break;
    }
    [self.rightBtn setBackgroundImage:rssiImage forState:UIControlStateNormal];
}

- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    NSLog(@"检测代理方法");
    if (central.state == CBManagerStatePoweredOn) {
        [self.mgr scanForPeripheralsWithServices:nil options:nil];
        //        [self showTheAlertViewWithMassage:@"手机蓝牙处于可用状态"];
    }
    NSLog(@"%ld，%@", central.state, central);
}

#pragma FESendFileTableViewControllerDelegate
-(void)sendFileByData:(NSData *)data sendLength:(NSInteger)length{
    self.sendedFileCount = 0;
    self.speed_bytesCount  = 0;
    self.speed_bytesCount2  = 0;
    self.speed_bytesCount3  = 0;
    self.speed_bytesCount4  = 0;
    self.speed_bytesCount5  = 0;
    self.speed_timeS = 0;
    self.sendFileView.hidden = NO;
    self.sfPercenLabel.text = @"0%";
    self.sfSendedLabel.text = @"0";
    self.sfSendCountLabel.text = [NSString stringWithFormat:@"%ld", length];
    self.sfSendedLabel.text = @"0 b/s";
    self.sfSendCountLabel.hidden = NO;
    self.responseSwitch.userInteractionEnabled = NO;
    self.speed_timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(speedTimerGoing) userInfo:nil repeats:YES];//开启速率计时器
    dispatch_async(dispatch_queue_create("sendFileQueue", DISPATCH_QUEUE_SERIAL), ^{
        self.isSendingFile = YES;
        dispatch_async(dispatch_get_main_queue(),^{
            self.totalLabel.text = FELocalizedString(@"total");
            [self.sendFileBtn setTitle:FELocalizedString(@"stopSend") forState:UIControlStateNormal];
        });
        packageCount = ((length-1)/PACKAGE_LENGTH)+1;
        sendWitchPlace = 0;
        sendStata = 1;
        fileSendingData = data;
        fileLength = length;
        [self sendFile];
    });
}

#pragma FEChangeServiceTableViewControllerDelegate
-(void)writeNoReCharacteristic:(CBCharacteristic *)characteristic{
    self.wrNoReCharacteristic = characteristic;
}
-(void)writeCharacteristic:(CBCharacteristic *)characteristic{
    self.wrCharacteristic = characteristic;
}
-(void)noRightCharacteristic{
    [SVProgressHUD showInfoWithStatus:FELocalizedString(@"noRightCharacteristic")];
}
#pragma 控件事件

- (IBAction)clickChangeService:(UIButton *)sender {
    if (self.isSendingFile || !self.isConnected) return;
    FEChangeServiceTableViewController *changeServiceVC = [FEChangeServiceTableViewController new];
    changeServiceVC.services = self.services;
    changeServiceVC.delegate = self;
    changeServiceVC.peripheral = self.currPeripheral;
    changeServiceVC.wrCharacteristic = self.wrCharacteristic;
    changeServiceVC.wrNoReCharacteristic = self.wrNoReCharacteristic;
    [self.navigationController pushViewController:changeServiceVC animated:YES];
}

- (IBAction)clearData:(UIButton *)sender {
    self.reByte = 0;
    self.rePackage = 0;
    self.sendByte = 0;
    self.sendPackage = 0;
    self.crcRe = 0;
    self.crcSe = 0;
    //清空数据
    [self.reData setLength:0];
    [self reflashView];
    [self.reDataArr removeAllObjects];
    self.sendByteLabel.text = [NSString stringWithFormat:@"%ld", self.sendByte];
    self.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", self.sendPackage];
}

- (IBAction)clickSend:(UIButton *)sender {
    if ([self.sendTextView.text isEqualToString:@""] || !self.isConnected) return;
    [self send];
}

- (IBAction)clickSendFile:(UIButton *)sender {
    if (!self.isConnected) return;
    if (self.isSendingFile) {
        self.isSendingFile = NO;
        [self.speed_timer invalidate];
        [self.sendFileBtn setTitle:FELocalizedString(@"sendFile") forState:UIControlStateNormal];
    }else{
        FESendFileTableViewController *VC = [self.sto instantiateViewControllerWithIdentifier:@"sto_sendFileVC"];
        VC.delegate = self;
        [self.navigationController pushViewController:VC animated:YES];
    }
}


- (IBAction)hexReSwitch:(UISwitch *)sender {
    [[NSUserDefaults standardUserDefaults] setBool:sender.isOn forKey:@"hexReSwitch"];
}

- (IBAction)hexSendSwitch:(UISwitch *)sender {
    [[NSUserDefaults standardUserDefaults] setBool:sender.isOn forKey:@"hexSendSwitch"];
    self.isClickHexSendSwitch = YES;
    self.sendTextView.text = sender.isOn ? [self.sendTextView.text dataToHex:self.sendData] : [self.sendTextView.text dataToUTF8:self.sendData];
}
- (IBAction)intervalSwitch:(UISwitch *)sender {
    if ([self.sendTextView.text isEqualToString:@""]) sender.on = NO;
    if (sender.isOn) {
        if (!self.isConnected) return;
        NSThread *intervalSendThread = [[NSThread alloc] initWithTarget:self selector:@selector(intervalSend) object:nil];
        [intervalSendThread start];
    }
}
- (IBAction)clickResponseSwitch:(UISwitch *)sender {
    [[NSUserDefaults standardUserDefaults] setBool:sender.isOn forKey:@"responseSwitch"];
}



- (void)textViewDidChangeSelection:(UITextView *)textView{
    if (self.isClickHexSendSwitch) {
        self.isClickHexSendSwitch = NO;
        return;
    }
    if (self.hexSend.isOn) {
        self.sendData = [textView.text hexToData];
    }else{
        self.sendData = [textView.text UTF8ToData];
    }
    NSLog(@"%@", self.sendData);
}

#pragma 自己写的方法
-(void)send{
    dispatch_sync(dispatch_queue_create("sendConcurrentQueue", DISPATCH_QUEUE_SERIAL), ^{
        if (self.responseSwitch.isOn) {
            if(self.wrCharacteristic) [self.currPeripheral writeValue:self.sendData forCharacteristic:self.wrCharacteristic type:CBCharacteristicWriteWithResponse];
        }else{
            if(self.wrNoReCharacteristic) [self.currPeripheral writeValue:self.sendData forCharacteristic:self.wrNoReCharacteristic type:CBCharacteristicWriteWithoutResponse];
            self.crcSe = crc32(self.crcSe, self.sendData.bytes, (uint32_t)self.sendData.length);
            self.sendByte += self.sendData.length;
            self.sendPackage++;
            NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",self.crcSe];
            dispatch_async(dispatch_get_main_queue(),^{
                self.sendByteLabel.text = [NSString stringWithFormat:@"%ld", self.sendByte];
                self.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", self.sendPackage];
                self.crcSeLabel.text = crcShow;
            });
        }
    });
}

-(void)sendFile{
    if (!self.isSendingFile) return;
    if (sendWitchPlace == packageCount-1){
        fileSendingData = [fileSendingData subdataWithRange:NSMakeRange(0, fileLength%PACKAGE_LENGTH)];
    }else if (sendWitchPlace > packageCount-1){//发送完毕
        sendStata = 0;
        self.isSendingFile = NO;
        [self.sendFileBtn setTitle:FELocalizedString(@"sendFile") forState:UIControlStateNormal];
        return;
    }
    if (self.responseSwitch.isOn) {
        if(self.wrCharacteristic) [self.currPeripheral writeValue:fileSendingData forCharacteristic:self.wrCharacteristic type:CBCharacteristicWriteWithResponse];
    }else{
        dispatch_sync(dispatch_queue_create("sendFileConcurrentQueue", DISPATCH_QUEUE_SERIAL), ^{
            while (sendWitchPlace < packageCount && self.isSendingFile && self.isConnected) {
                if (isFlashView && isReing && self.isConnected){
                    NSLog(@"等待中");
                    [NSThread sleepForTimeInterval:0.01];
                    continue;
                }
                isFlashView = YES;
                [self sendFileThread];
                //每秒10k的标准
                [NSThread sleepForTimeInterval:PACKAGE_LENGTH*0.0001];
            }
            [self stopSendingFile];
        });
    }
}
-(void)sendFileThread{
    if (sendWitchPlace == packageCount-1) {
        if (fileLength%PACKAGE_LENGTH > 0) {
            fileSendingData = [fileSendingData subdataWithRange:NSMakeRange(0, fileLength%PACKAGE_LENGTH)];
        }
    }
    if(self.wrNoReCharacteristic) [self.currPeripheral writeValue:fileSendingData forCharacteristic:self.wrNoReCharacteristic type:CBCharacteristicWriteWithoutResponse];
    sendWitchPlace++;
    self.crcSe = crc32(self.crcSe, fileSendingData.bytes, (uint32_t)fileSendingData.length);
    self.sendByte += fileSendingData.length;
    self.sendedFileCount += fileSendingData.length;
    self.speed_bytesCount += fileSendingData.length;
    self.sendPackage++;
    NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",self.crcSe];
    dispatch_async(dispatch_get_main_queue(),^{
        self.sendByteLabel.text = [NSString stringWithFormat:@"%ld", self.sendByte];
        self.sendPackageLabel.text = [NSString stringWithFormat:@"%ld", self.sendPackage];
        self.crcSeLabel.text = crcShow;
        isFlashView = NO;
    });
    [self reflashSendFileView];
}

-(void)stopSendingFile{
    NSLog(@"文件发送结束");
    [self.speed_timer invalidate];
    self.responseSwitch.userInteractionEnabled = YES;
    sendStata = 0;
    self.isSendingFile = NO;
    dispatch_async(dispatch_get_main_queue(),^{
        self.sfSendCountLabel.hidden = YES;
        self.totalLabel.text = FELocalizedString(@"clickToHidden");
        [self.sendFileBtn setTitle:FELocalizedString(@"sendFile") forState:UIControlStateNormal];
        self.sfSpeedLabel.text = [NSString stringWithFormat:@"%ld b/s",  self.sendedFileCount / self.speed_timeS];
    });
}

-(void)reflashSendFileView{
    dispatch_async(dispatch_get_main_queue(),^{
        [self.sfProgressView setProgress:(double)sendWitchPlace / (double)packageCount animated:NO];
        self.sfPercenLabel.text = [NSString stringWithFormat:@"%.1f %%", self.sfProgressView.progress * 100.0];
        self.sfSendedLabel.text = [NSString stringWithFormat:@"%ld", self.sendedFileCount];
    });
}

-(void)speedTimerGoing{
    if (0 == self.speed_bytesCount5) {
        self.speed_bytesCount2 = self.speed_bytesCount;
        self.speed_bytesCount3 = self.speed_bytesCount;
        self.speed_bytesCount4 = self.speed_bytesCount;
        self.speed_bytesCount5 = self.speed_bytesCount;
    }
    NSLog(@"秒%ld",self.speed_timeS);
    self.speed_timeS ++;
    dispatch_async(dispatch_get_main_queue(),^{
        NSInteger totalCount = self.speed_bytesCount + self.speed_bytesCount2 + self.speed_bytesCount3 + self.speed_bytesCount4 + self.speed_bytesCount5;
        self.sfSpeedLabel.text = [NSString stringWithFormat:@"%ld b/s", totalCount / 5];
        self.speed_bytesCount2 = self.speed_bytesCount;
        self.speed_bytesCount3 = self.speed_bytesCount2;
        self.speed_bytesCount4 = self.speed_bytesCount3;
        self.speed_bytesCount5 = self.speed_bytesCount4;
        self.speed_bytesCount = 0;
        self.sfRunTimeLabel.text = [self secondToTime:self.speed_timeS];
    });
}

-(NSString *)secondToTime:(NSInteger)second{
    return [NSString stringWithFormat:@"%02ld:%02ld:%02ld",second / 3600, (second % 3600) / 60, second%60];
}

-(void)intervalSend{
    while (self.intervalSwitch.isOn && self.isConnected) {
        [NSThread sleepForTimeInterval:[self.intervalTextField.text integerValue] * 0.001];
        [self send];
    }
}

-(void)reflashView{
    dispatch_sync(dispatch_queue_create("readConcurrentQueue", DISPATCH_QUEUE_SERIAL), ^{
        NSLog(@"最后刷新界面");
        NSString *stringR = @"";
        stringR = self.hexRe.isOn ? [stringR dataToHex:self.reData] : [stringR dataToUTF8:self.reData];
        NSString *stringB = [NSString stringWithFormat:@"%ld", self.reByte];
        NSString *stringP = [NSString stringWithFormat:@"%ld", self.rePackage];
        NSString *crcShow = [[NSString alloc] initWithFormat:@"%02lX",self.crcRe];
        NSString *crcSend = [[NSString alloc] initWithFormat:@"%02lX",self.crcSe];
        dispatch_async(dispatch_get_main_queue(),^{
            self.reByteLabel.text = stringB;
            self.rePackageLabel.text = stringP;
            self.reTextView.text = stringR;
            self.crcReLabel.text = crcShow;
            self.crcSeLabel.text = crcSend;
            [self.reTextView scrollRectToVisible:CGRectMake(0, self.reTextView.contentSize.height-15, self.reTextView.contentSize.width, 10) animated:YES];
        });
    });
}

//弹框
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) return;
}

-(void)readRssi{
    [self.currPeripheral readRSSI];
}

-(void)clickRbImage{
    self.rightLabel.hidden = !self.rightLabel.isHidden;
    [[NSUserDefaults standardUserDefaults] setBool:self.rightLabel.isHidden forKey:@"rightLabelHidden"];
}

#pragma mark - 键盘配置
//第三种键盘弹起方法（调整view的约束）
//键盘弹出设置
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showKeyboard:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(closeKeyboard:) name:UIKeyboardWillHideNotification object:nil];
}
-(void)showKeyboard:(NSNotification *)notification{
    // 读取userInfo中的动画种类
    NSInteger option = [notification.userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue];
    // 读取userInfo中的动画时长
    NSTimeInterval duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
    // 获取弹起的键盘的frame中的左顶点位置的y
    CGFloat height = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    self.layout_bottom.constant = height;
    [UIView animateWithDuration:duration    delay:0 options:option animations:^{
        [self.view layoutIfNeeded];
    } completion:nil];
}
-(void)closeKeyboard:(NSNotification *)notification{
    self.layout_bottom.constant = 0;
    [self.view layoutIfNeeded];
}
//键盘收回设置
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (self.isSendingFile && !self.speed_timer.isValid) {
        self.speed_timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(speedTimerGoing) userInfo:nil repeats:YES];//开启速率计时器
    }
    self.currPeripheral.delegate = self;
    self.isStopReViTread = NO;
    [self.reflashViewThread start];
    self.readRssiTimer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(readRssi) userInfo:nil repeats:YES];
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
     if (self.isSendingFile) [self.speed_timer invalidate];
    self.isStopReViTread = YES;
    [self.readRssiTimer invalidate];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.sendTextView resignFirstResponder];
    [self.intervalTextField resignFirstResponder];
    for (UITouch *touch in touches) {
        if (touch.view == self.sendFileView && [self.totalLabel.text isEqualToString:FELocalizedString(@"clickToHidden")]) {
            self.sendFileView.hidden = YES;
        }
    }
}

-(NSMutableArray *)services{
    if (!_services) {
        _services = [NSMutableArray array];
    }
    return _services;
}

-(NSMutableArray *)reDataArr{
    if (!_reDataArr) {
        _reDataArr = [NSMutableArray array];
    }
    return _reDataArr;
}

-(NSMutableData *)reData{
    if (!_reData) {
        _reData = [[NSMutableData alloc] init];
    }
    return _reData;
}

-(void)dealloc{
    [self.mgr cancelPeripheralConnection:self.currPeripheral];
    [[NSUserDefaults standardUserDefaults] setValue:self.sendData forKey:@"sendData"];
    [[NSUserDefaults standardUserDefaults] setValue:self.intervalTextField.text forKey:@"intervalTime"];
    [SVProgressHUD showInfoWithStatus:FELocalizedString(@"disconnected")];
}
@end
