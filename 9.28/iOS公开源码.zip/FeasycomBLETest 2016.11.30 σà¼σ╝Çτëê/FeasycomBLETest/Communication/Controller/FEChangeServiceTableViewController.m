//
//  FEChangeServiceTableViewController.m
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//
#define INFODEVICE @"180A"

#import "FEChangeServiceTableViewController.h"

@interface FEChangeServiceTableViewController ()<CBPeripheralDelegate>
@property (nonatomic, strong) NSMutableArray<CBCharacteristic *>* infoCharacteristics;
@property (nonatomic) NSInteger sortIndex;
@property (nonatomic, strong) UITableViewCell *wrCell;
@property (nonatomic, strong) UITableViewCell *wrNoReCell;
@property (nonatomic, strong) UISegmentedControl *stateSegment;
@property (nonatomic, strong) NSMutableArray<CBCharacteristic *>*chaReArray;
@end

@implementation FEChangeServiceTableViewController

typedef NS_ENUM(NSInteger, SegmentState) {
    N_read = 0,
    N_writeRe   = 1,
    N_write  = 2
};

- (void)viewDidLoad {
    [super viewDidLoad];
    //配置导航栏
    // 创建一个使用本来的样式进行渲染的图片
    NSMutableArray *array = [NSMutableArray new];
    [array addObject:FELocalizedString(@"n_read")];
    [array addObject:FELocalizedString(@"n_writeRe")];
    [array addObject:FELocalizedString(@"n_write")];
    self.stateSegment = [[UISegmentedControl alloc]initWithItems:array];
    [self.stateSegment setSelectedSegmentIndex:0];
    [self.stateSegment addTarget:self action:@selector(clickStateSegment) forControlEvents:UIControlEventAllEvents];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:self.stateSegment];
    //在导航栏右侧添加按钮
    self.navigationItem.rightBarButtonItem = rightItem;
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    //[self.tableView registerClass:[UITableViewCell class]forCellReuseIdentifier:@"MyCell"];
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.peripheral.delegate = self;
    [self sortService];
    self.infoCharacteristics = [NSMutableArray new];
    self.chaReArray = [NSMutableArray new];
    ServiceInfo *info;
    for (info in self.services) {
        [info reflashCharacteristics];//必须更新特征
        for (CBCharacteristic *characteristic in info.service.characteristics) {
            [self.peripheral readValueForCharacteristic:characteristic];
        }
        if ([info.service.UUID.UUIDString isEqualToString:INFODEVICE]) {
            [self.infoCharacteristics addObjectsFromArray:info.service.characteristics];
            [self sortInfoCharacteristic];//排序
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self reloadData];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.services.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    ServiceInfo *info = self.services[section];
    return info.service.characteristics.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyCell"];
    if(cell ==nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"MyCell"];
    }
    ServiceInfo *info = self.services[indexPath.section];
    CBCharacteristic *characteristic = info.service.characteristics[indexPath.row];
    NSString *characteristicString;
    if(![info.service.UUID.UUIDString isEqualToString:INFODEVICE]){
        characteristicString = @"";
        if (characteristic.properties & CBCharacteristicPropertyRead){
            //拿到值可读的特征了
            characteristicString = [characteristicString stringByAppendingString:FELocalizedString(@"readValue")];
        }
        if (characteristic.properties & CBCharacteristicPropertyNotify){
            //拿到可读的无反馈特征了
            characteristicString = [characteristicString stringByAppendingString:FELocalizedString(@"readNoRe")];
        }
        if (characteristic.properties & CBCharacteristicPropertyIndicate){
            //拿到可读的特征了
            characteristicString = [characteristicString stringByAppendingString:FELocalizedString(@"readRe")];
        }
        if (characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse){
            //拿到可写WithoutResponse的特征了
            characteristicString = [characteristicString stringByAppendingString:FELocalizedString(@"writeNoRe")];
            if (self.wrNoReCharacteristic == characteristic) {
                self.wrNoReCell = cell;
            }
        }
        if (characteristic.properties & CBCharacteristicPropertyWrite){
            //拿到可写的特征了
            characteristicString = [characteristicString stringByAppendingString:FELocalizedString(@"writeRe")];
            if (self.wrCharacteristic == characteristic) {
                self.wrCell = cell;
            }
        }
        cell.textLabel.text = characteristic.UUID.UUIDString;
        cell.detailTextLabel.text = characteristicString;
        //把接收的特征加入接收特征的数组
        if (characteristic.properties & CBCharacteristicPropertyNotify || characteristic.properties & CBCharacteristicPropertyIndicate) {
            [self.chaReArray addObject:characteristic];
        }
    }else{
        //设备信息
        characteristic = self.infoCharacteristics[indexPath.row];
        cell.textLabel.text = [self characteristicName:characteristic];
        cell.detailTextLabel.text = [self characteristicValue:characteristic];
    }
    switch (self.stateSegment.selectedSegmentIndex) {
        case N_read:
        {
            if (characteristic.isNotifying) {
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
            }else{
                cell.accessoryType = UITableViewCellAccessoryNone;
            }
        }
            break;
        case N_writeRe:
            if (characteristic == self.wrCharacteristic)  {
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
            }else{
                cell.accessoryType = UITableViewCellAccessoryNone;
            }
            break;
        case N_write:
            if (characteristic == self.wrNoReCharacteristic)  {
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
            }else{
                cell.accessoryType = UITableViewCellAccessoryNone;
            }
            break;
        default:
            cell.accessoryType = UITableViewCellAccessoryNone;
            break;
    }
    cell.detailTextLabel.textColor = [UIColor grayColor];
    cell.detailTextLabel.font = [UIFont systemFontOfSize:14];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
}

//分区头信息
-(NSString*)tableView:(UITableView*)tableView titleForHeaderInSection:(NSInteger)section{
    ServiceInfo *info = self.services[section];
    if(![info.service.UUID.UUIDString isEqualToString:INFODEVICE]){
        NSString *serviceName = [NSString stringWithFormat:@"%@:%@",FELocalizedString(@"service"), info.service.UUID.UUIDString];
        return serviceName;
    }else{
        return FELocalizedString(@"deviceInformation");
    }
}

// 自定义行高
-(CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 60;
}
//设置分区头区域的高度
-(CGFloat)tableView:(UITableView*)tableView heightForHeaderInSection:(NSInteger)section{
    return 60;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    ServiceInfo *info = self.services[indexPath.section];
    //不是设备信息才处理
    if(![info.service.UUID.UUIDString isEqualToString:INFODEVICE]){
        UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
        CBCharacteristic *characteristic = info.service.characteristics[indexPath.row];
        switch (self.stateSegment.selectedSegmentIndex) {
            case N_read:
                if (characteristic.properties & CBCharacteristicPropertyNotify || characteristic.properties & CBCharacteristicPropertyIndicate){
                    if (characteristic.isNotifying) {
                        if (self.chaReArray.count > 1) {
                            cell.accessoryType = UITableViewCellAccessoryNone;
                            [self.chaReArray removeObject:characteristic];
                            [self.peripheral setNotifyValue:NO forCharacteristic:characteristic];
                        }
                    }else{
                        cell.accessoryType = UITableViewCellAccessoryCheckmark;
                        [self.chaReArray addObject:characteristic];
                        [self.peripheral setNotifyValue:YES forCharacteristic:characteristic];
                    }
                }
                break;
            case N_writeRe:
                if (characteristic.properties & CBCharacteristicPropertyWrite){
                    //拿到可写的特征了
                    if (self.wrCell && self.wrCharacteristic != characteristic) {
                        self.wrCharacteristic = characteristic;
                        self.wrCell.accessoryType = UITableViewCellAccessoryNone;
                        self.wrCell = cell;
                        cell.accessoryType = UITableViewCellAccessoryCheckmark;
                    }
                    [self.delegate writeCharacteristic:self.wrCharacteristic];
                }
                break;
            case N_write:
                if (characteristic.properties & CBCharacteristicPropertyWriteWithoutResponse){
                    //拿到可写WithoutResponse的特征了
                    if (self.wrNoReCell && self.wrNoReCharacteristic != characteristic) {
                        self.wrNoReCharacteristic = characteristic;
                        self.wrNoReCell.accessoryType = UITableViewCellAccessoryNone;
                        self.wrNoReCell = cell;
                        cell.accessoryType = UITableViewCellAccessoryCheckmark;
                    }
                    [self.delegate writeNoReCharacteristic:self.wrNoReCharacteristic];
                }
                break;
                
            default:
                break;
        }
    }
}

-(NSString*)characteristicName:(CBCharacteristic*)characteristic{
    NSString *characteristicString = characteristic.UUID.UUIDString;
    if ([characteristicString isEqualToString:@"2A24"]) {
        return FELocalizedString(@"modelNumber");
    }else if ([characteristicString isEqualToString:@"2A25"]){
        return FELocalizedString(@"serialNumber");
    }else if ([characteristicString isEqualToString:@"2A27"]){
        return FELocalizedString(@"hardwareRevision");
    }else if ([characteristicString isEqualToString:@"2A28"]){
        return FELocalizedString(@"softwareRevision");
    }else if ([characteristicString isEqualToString:@"2A29"]){
        return FELocalizedString(@"manufacturerName");
    }else{
        characteristicString = [NSString stringWithFormat:@"%@",characteristic.description];
        NSRange range = [characteristicString rangeOfString:@"UUID = "];
        characteristicString = [characteristicString substringFromIndex:range.location+range.length];
        range = [characteristicString rangeOfString:@","];
        characteristicString = [characteristicString substringToIndex:range.location];
        characteristicString = [NSString stringWithFormat:@"%@(%@)",characteristicString, characteristic.UUID.UUIDString];
        return characteristicString;
    }
}

-(NSString*)characteristicValue:(CBCharacteristic*)characteristic{
    NSString *characteristicString = characteristic.UUID.UUIDString;
    NSString *string = [[NSString alloc] initWithData:characteristic.value encoding:NSUTF8StringEncoding];
    if ([characteristicString isEqualToString:@"2A25"]) {
        NSMutableString *stringTemp = [NSMutableString new];
        if (string.length == 12) {
            for (int i=0; i<12; i+=2) {
                [stringTemp appendString:[string substringWithRange:NSMakeRange(i, 2)]];
                [stringTemp appendString:@":"];
            }
            string = [stringTemp substringToIndex:stringTemp.length-1];
            NSLog(@"%@",string);
        }
    }
    return string;
}

-(void)clickStateSegment{
    [self reloadData];
}

-(void)reloadData{
    //刷新列表前要清空数组
    [self.chaReArray removeAllObjects];
    [self.tableView reloadData];
}

//排序
-(void)sortService{
    if (self.services) {
        ServiceInfo *info;
        for (int i=0; i<self.services.count; i++) {
            info = self.services[i];
            if ([info.service.UUID.UUIDString isEqualToString:INFODEVICE]) {
                [self.services removeObject:info];
                [self.services addObject:info];
                break;
            }
        }
    }
}
-(void)sortInfoCharacteristic{
    self.sortIndex = 0;
    [self replaceSortByString:@"2A24"];//型号
    [self replaceSortByString:@"2A29"];//制造商
    [self replaceSortByString:@"2A25"];//地址码
    [self replaceSortByString:@"2A27"];//硬件版本
    [self replaceSortByString:@"2A28"];//软件版本
}
-(void)replaceSortByString:(NSString*)string{
    CBCharacteristic *characteristic;
    for (NSInteger i=self.sortIndex; i<self.infoCharacteristics.count; i++) {
        characteristic = self.infoCharacteristics[i];
        if ([characteristic.UUID.UUIDString isEqualToString:string]) {//型号
            [self.infoCharacteristics removeObject:characteristic];
            [self.infoCharacteristics insertObject:characteristic atIndex:self.sortIndex];
            self.sortIndex++;
            break;
        }
    }
}

@end
