//
//  FESendFileTableViewController.m
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FESendFileTableViewController.h"

#define BTN1  1024
#define BTN2  1024*10
#define BTN3  1024*100
#define BTN4  1024*200
#define BTN5  1024*500
#define BTN6  1024*1024
#define BTN7  1024*1024*2
#define BTN8  1024*1024*5
#define BTN9  1024*1024*10
#define BTN10 1024*1024*20

@interface FESendFileTableViewController ()
@property (weak, nonatomic) IBOutlet UITextField *byteCountTF;
@property (weak, nonatomic) IBOutlet UISegmentedControl *byteTypeSC;
//@property (nonatomic, strong) NSString *stringBase;
@property (nonatomic, strong) NSData *data;
@end

@implementation FESendFileTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
//    self.stringBase = @"1234567890";
//    for (NSInteger i=0; i<21; i++) {
//        self.stringBase = [self.stringBase stringByAppendingString:self.stringBase];
//    }
//    NSLog(@"stringBase长度%lu",(unsigned long)self.stringBase.length);
    NSString *string = @"1234567890";
    for (NSInteger i=0; i<6; i++) {
        string = [string stringByAppendingString:string];
    }
    string = [string substringToIndex:PACKAGE_LENGTH];
    self.data = [string dataUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"string长度%ld",(long)string.length);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    self.byteCountTF.text = [def valueForKey:@"sf_byteCount"];
    NSLog(@"%@,%ld",[def valueForKey:@"sf_byteCount"],[def integerForKey:@"sf_byteTypeSC"]);
    if ([self.byteCountTF.text isEqualToString:@""]) {
        self.byteCountTF.text = [NSString stringWithFormat:@"%d", 500];
    }
    self.byteTypeSC.selectedSegmentIndex = [def integerForKey:@"sf_byteTypeSC"];
}

-(void)viewWillDisappear:(BOOL)animated{
    [[NSUserDefaults standardUserDefaults] setValue:self.byteCountTF.text forKey:@"sf_byteCount"];
    [[NSUserDefaults standardUserDefaults] setInteger:self.byteTypeSC.selectedSegmentIndex forKey:@"sf_byteTypeSC"];
}
- (IBAction)OKBtn:(UIButton *)sender {
    NSInteger number = [self.byteCountTF.text integerValue];
    NSInteger multiple;
    switch (self.byteTypeSC.selectedSegmentIndex) {
        case 0:
            multiple = 1024;
            break;
        case 1:
            multiple = 1024*1024;
            break;
        case 2:
            multiple = 1000;
            break;
        case 3:
            multiple = 1000*1000;
            break;
        default:
            multiple = 1024;
            break;
    }
    number = number*multiple;
    [self.navigationController popViewControllerAnimated:YES];
    [self.delegate sendFileByData:self.data sendLength:number];
}

- (IBAction)clickBtn:(UIButton *)sender {
    NSInteger stringSendLength = 0;
    switch (sender.tag) {
        case 1001:
            stringSendLength = BTN1;
            break;
        case 1002:
            stringSendLength = BTN2;
            break;
        case 1003:
            stringSendLength = BTN3;
            break;
        case 1004:
            stringSendLength = BTN4;
            break;
        case 1005:
            stringSendLength = BTN5;
            break;
        case 1006:
            stringSendLength = BTN6;
            break;
        case 1007:
            stringSendLength = BTN7;
            break;
        case 1008:
            stringSendLength = BTN8;
            break;
        case 1009:
            stringSendLength = BTN9;
            break;
        case 1010:
            stringSendLength = BTN10;
            break;
        default:
            break;
    }
    NSLog(@"changdu:%ld",stringSendLength);
//    [self.delegate sendFileByString:[self.stringBase substringToIndex:stringSendLength] length:stringSendLength stringEnough:YES];
    [self.navigationController popViewControllerAnimated:YES];
    [self.delegate sendFileByData:self.data sendLength:stringSendLength];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)dealloc{
    NSLog(@"销毁FESendFileTableViewController");
}
@end
