//
//  FEChangeServiceTableViewController.h
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServiceInfo.h"

@class FEChangeServiceTableViewController;
@protocol FEChangeServiceTableViewControllerDelegate <NSObject>
//string发送的字符串，length待发送长度，enough：YES代表字符串已经包含所有长度数据，NO:长度过长，字符串只包含部分
//-(void) sendFileByString:(NSString*)string length:(NSInteger)length stringEnough:(BOOL)enough;

-(void) writeCharacteristic:(CBCharacteristic*)characteristic;
-(void) writeNoReCharacteristic:(CBCharacteristic*)characteristic;
@optional //可选实现
-(void) noRightCharacteristic;
@end
@interface FEChangeServiceTableViewController : UITableViewController
@property(nonatomic,weak)id<FEChangeServiceTableViewControllerDelegate> delegate;
@property (nonatomic, strong) CBPeripheral *peripheral;
@property (nonatomic, strong) CBCharacteristic *wrNoReCharacteristic;
@property (nonatomic, strong) CBCharacteristic *wrCharacteristic;

@property (nonatomic, strong) NSMutableArray *services;
@end
