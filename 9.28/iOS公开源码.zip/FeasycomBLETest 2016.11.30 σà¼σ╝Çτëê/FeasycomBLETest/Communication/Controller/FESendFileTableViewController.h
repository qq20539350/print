//
//  FESendFileTableViewController.h
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>
@class FESendFileTableViewController;
@protocol FESendFileTableViewControllerDelegate <NSObject>
//string发送的字符串，length待发送长度，enough：YES代表字符串已经包含所有长度数据，NO:长度过长，字符串只包含部分
//-(void) sendFileByString:(NSString*)string length:(NSInteger)length stringEnough:(BOOL)enough;
-(void) sendFileByData:(NSData*)data sendLength:(NSInteger)length;
@optional //可选实现

@end
@interface FESendFileTableViewController : UITableViewController
@property(nonatomic,weak)id<FESendFileTableViewControllerDelegate> delegate;
@end
