//
//  FECommunicationTableViewController.m
//  FeasycomLE
//
//  Created by 余明悦 on 16/7/20.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import "FECommunicationTableViewController.h"
#import "FECommunicationTableViewCell.h"
#import "FECommunicationChatViewController.h"
#import <MJRefresh.h>
#import <SVProgressHUD.h>
#import "FEShareBt.h"
#import "AppDelegate.h"

@interface FECommunicationTableViewController ()<CBCentralManagerDelegate,CBPeripheralDelegate>
//外设数组
@property (nonatomic, strong) NSMutableArray *peripherals;
@property (nonatomic, strong) NSMutableArray *advertisementDatas;
//中心管理者
@property (nonatomic, strong) CBCentralManager*mgr;
//外设
@property (nonatomic, strong) CBPeripheral*peripheral;
//信号数组
@property (nonatomic, strong) NSMutableArray *RSSIs;
@property (nonatomic, strong) NSTimer *reflashRSSITimer;
@end

@implementation FECommunicationTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%p",self.storyboard);
    //改变tabbar颜色
    //[self.tabBarController.tabBar setBarTintColor:[UIColor colorWithRed:0.5 green:0.85 blue:1 alpha:1]];
    //改变tabbar未选中项文字颜色。
    //[self.tabBarController.tabBar setUnselectedItemTintColor:[UIColor whiteColor]];
    //self.tabBarController.tabBar.translucent = NO; //是否透明
    //去掉列表分割线
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //注册cell
    [self.tableView registerNib:[UINib nibWithNibName:@"FECommunicationTableViewCell"bundle:nil] forCellReuseIdentifier:@"CommCell"];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"MyCell"];
    //self.title = @"Searching peripherals";
    // 1.创建中心设备
    //设置代理
    self.mgr= [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    [FEShareBt sharedFEShareBt].mgr = self.mgr;
    [FEShareBt sharedFEShareBt].peripheral = self.peripheral;
    UIBarButtonItem*buttonI = [[UIBarButtonItem alloc] initWithTitle:FELocalizedString(@"stopScan") style:UIBarButtonItemStylePlain target:self action:@selector(openOrclosed)];
    self.navigationItem.rightBarButtonItem= buttonI;
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        self.tableView.userInteractionEnabled = NO;
        if (self.mgr.isScanning) [self.mgr stopScan];
        [self.peripherals removeAllObjects];
        [self.advertisementDatas removeAllObjects];
        [self.RSSIs removeAllObjects];
        [self.tableView reloadData];
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"stopScan")];
        [self.tableView.mj_header endRefreshing];
        [self.mgr scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:[NSNumber numberWithBool:YES]}];
        self.tableView.userInteractionEnabled = YES;
    }];
    
}

#pragma mark -蓝牙配置和操作
#pragma mark - CBCentralManagerDelegate

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    // 保存扫描到得外部设备
    // 判断如果数组中不包含当前扫描到得外部设置才保存
//    NSLog(@"查找设备");
    if ([RSSI integerValue]<0 && [RSSI integerValue]>-100) {
        if (![self.peripherals containsObject:peripheral]) {
            [self insertTableView:peripheral advertisementData:advertisementData RSSI:RSSI];
        }else{
            NSInteger index = [self.peripherals indexOfObject:peripheral];
            self.RSSIs[index] = RSSI;
//            NSLog(@"RSSI");
        }
    }
}
//扫描外设
- (void)openOrclosed{
    if([self.navigationItem.rightBarButtonItem.title isEqualToString:FELocalizedString(@"scan")]) {
        NSLog(@"扫描");
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"stopScan")];
        // 利用中心设备扫描外部设备
        /*
         如果指定数组代表只扫描指定的设备
         */
        [self.mgr scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:[NSNumber numberWithBool:YES]}];
    }else {
        NSLog(@"停止扫描");
        [self.mgr stopScan];/*
        if (self.peripheral !=nil){
            NSLog(@"disConnect start");
            [self.mgr cancelPeripheralConnection:self.peripheral];
        }
        self.peripherals =nil;
        [self.tableView reloadData];*/
        [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"scan")];
//        AppDelegate *dele = (AppDelegate *)[UIApplication sharedApplication].delegate;
//        NSString *str = [NSString stringWithFormat:@"%@",dele.url];
//        str = [str stringByRemovingPercentEncoding];
//        [self.navigationItem.rightBarButtonItem setTitle:str];
    }
}
#pragma mark - CBCentralManagerDelegate
//连接外设成功调用
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    if (self.reflashRSSITimer) {
        [self.reflashRSSITimer invalidate];
        self.reflashRSSITimer = nil;
    }
    [self.mgr stopScan];
    FECommunicationChatViewController *chatVC = [FECommunicationChatViewController new];
    chatVC.mgr = self.mgr;
    chatVC.currPeripheral = self.peripheral;
    chatVC.hidesBottomBarWhenPushed = YES;
    chatVC.sto = self.storyboard;
    [self.navigationController pushViewController:chatVC animated:YES];
    
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(nullable NSError *)error{
    NSLog(@"连接失败%@",error);
}
//连接外设失败调用
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    //    [self showTheAlertViewWithMassage:@"链接失败"];
    [SVProgressHUD showInfoWithStatus:FELocalizedString(@"disconnected")];
    NSLog(@"断开链接");
}
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    NSLog(@"检测代理方法");
    if (central.state == CBManagerStatePoweredOn) {
        [self.mgr scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:[NSNumber numberWithBool:YES]}];
        //        [self showTheAlertViewWithMassage:@"手机蓝牙处于可用状态"];
    }
    NSLog(@"%ld，%@", (long)central.state, central);
}

        //插入table数据
-(void)insertTableView:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    if ([RSSI integerValue]<-100 && [RSSI integerValue]>0) return;
    if(![self.peripherals containsObject:peripheral]) {
        NSMutableArray *indexPaths = [[NSMutableArray alloc] init];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.peripherals.count inSection:0];
        [indexPaths addObject:indexPath];
        [self.peripherals addObject:peripheral];
        [self.advertisementDatas addObject:advertisementData];
        [self.RSSIs addObject:RSSI];
        [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    }else{
        NSInteger index = [self.peripherals indexOfObject:peripheral];
        self.RSSIs[index] = RSSI;
    }
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.peripherals.count;
}


- (FECommunicationTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    FECommunicationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommCell"];
    if(cell == nil) {
        cell = [FECommunicationTableViewCell new];
    }
    CBPeripheral *peripheral = [self.peripherals objectAtIndex:indexPath.row];
    //[cell reflashName:peripheral.name];
    NSDictionary *advertisementData = self.advertisementDatas[indexPath.row];
    if (advertisementData[CBAdvertisementDataLocalNameKey]) {
        [cell reflashName:[NSString stringWithFormat:@"%@",advertisementData[CBAdvertisementDataLocalNameKey]]];
    }else{
        [cell reflashName:peripheral.name];
    }
    [cell reflashRSSI:[self.RSSIs[indexPath.row] integerValue]];
    cell.UUIDLabel.text = peripheral.identifier.UUIDString;
    if ([advertisementData[@"kCBAdvDataServiceUUIDs"] componentsJoinedByString:@","]) {
        cell.serviceUUIDsLabel.text = [[NSString alloc] initWithFormat:@"%@",[advertisementData[@"kCBAdvDataServiceUUIDs"] componentsJoinedByString:@","]];
    }else{
        cell.serviceUUIDsLabel.text = @"";
    }
    return cell;
}

// 选择列表
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    self.peripheral = self.peripherals[indexPath.row];
    NSDictionary *advertisementData = self.advertisementDatas[indexPath.row];
    [FEShareBt sharedFEShareBt].connetedName = advertisementData[CBAdvertisementDataLocalNameKey] ? [NSString stringWithFormat:@"%@",advertisementData[CBAdvertisementDataLocalNameKey]] : self.peripheral.name;
    NSLog(@"name = %@", [FEShareBt sharedFEShareBt].connetedName);
    [self.mgr connectPeripheral:self.peripherals[indexPath.row] options:@{CBConnectPeripheralOptionNotifyOnConnectionKey:@1,CBConnectPeripheralOptionNotifyOnNotificationKey:@1}];
}

- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath{
    return 80;
}

#pragma 自己写的方法
-(void)reflashRSSI{
    for (int i=0; i<self.RSSIs.count; i++) {
        FECommunicationTableViewCell *cell = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
        [cell reflashRSSI:[self.RSSIs[i] integerValue]];
    }
}

#pragma 视图状态
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    self.mgr.delegate = self;
    [self.navigationItem.rightBarButtonItem setTitle:FELocalizedString(@"stopScan")];
    [self.tableView reloadData];
    // 利用中心设备扫描外部设备
    [self.mgr scanForPeripheralsWithServices:nil options:@{CBCentralManagerScanOptionAllowDuplicatesKey:[NSNumber numberWithBool:YES]}];
    if (!self.reflashRSSITimer) {
         self.reflashRSSITimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(reflashRSSI) userInfo:nil repeats:YES];
    }
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.mgr stopScan];
    if (self.reflashRSSITimer) {
        [self.reflashRSSITimer invalidate];
        self.reflashRSSITimer = nil;
    }
}
- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma 懒加载
-(NSMutableArray *)peripherals{
    if (!_peripherals) {
        _peripherals = [NSMutableArray array];
        [FEShareBt sharedFEShareBt].peripherals = _peripherals;
    }
    return _peripherals;
}
-(NSMutableArray *)advertisementDatas{
    if (!_advertisementDatas) {
        _advertisementDatas = [NSMutableArray array];
    }
    return _advertisementDatas;
}
-(NSMutableArray *)RSSIs{
    if (!_RSSIs) {
        _RSSIs = [NSMutableArray array];
        [FEShareBt sharedFEShareBt].RSSIs = _RSSIs;
    }
    return _RSSIs;
}

@end
