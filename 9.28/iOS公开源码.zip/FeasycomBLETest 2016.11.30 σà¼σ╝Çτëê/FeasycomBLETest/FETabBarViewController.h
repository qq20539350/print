//
//  FETabBarViewController.h
//  FeasycomBLETest
//
//  Created by yumingyue on 2016/11/22.
//  Copyright © 2016年 feasycom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FETabBarViewController : UITabBarController

@end
