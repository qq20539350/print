lipo -create ./Debug-iphoneos/libzzPrinter.a  ./Debug-iphonesimulator/libzzPrinter.a  -output libzzPrinter.a

##lipo -create ./Release-iphoneos/libzzPrinter.a  ./Release-iphonesimulator/libzzPrinter.a  -output libzzPrinter.a
