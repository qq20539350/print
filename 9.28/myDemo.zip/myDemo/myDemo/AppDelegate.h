//
//  AppDelegate.h
//  myDemo
//
//  Created by hu on 2019/4/27.
//  Copyright © 2019 hu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

