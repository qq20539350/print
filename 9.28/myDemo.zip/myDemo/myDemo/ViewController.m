//
//  ViewController.m
//  myDemo
//
//  Created by hu on 2019/4/27.
//  Copyright © 2019 hu. All rights reserved.
//

#import "ViewController.h"
#import "zzPrinter.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    //=============================================
    //      检查打印机是否有效demo
    //=============================================
    BYTE check[8];
    BYTE cmd[16];
    
    // 1. get pritner check command
    int ret = getPrinterCheckCmd(NULL, check, cmd);
    if (ret > 0)
    {
        // 2. write printer check command to printer
        // bt.write(cmd, 11);
        
        // 3. read printer response data
        // bt.read(buffer, 8, 1000);    // wait max 1000ms
        
        // 4. compare printer response data with check buffer
        // if (!memcmp(buffer, check, 8))
        // {
        //      printf("valid printer\n");
        // }
        // else
        // {
        //      printf("invalid printer\n");
        // }
        
        printf("\n\n");
        for (int i=0; i<ret; i++){
            if (i && i%16==0) printf("\n");
            printf("%02x ", cmd[i]);
        }
        printf("\n\n");
    }
    //=============================================
    //      位图压缩演示demo
    //=============================================
    //  
    // 12x12 '.' = 0, '#' = 1
        //  0123456789AB
		//  ............	// 0
		//  ............	// 1
		//  .####.......	// 2
		//  ##..##......	// 3
		//  ##..##......	// 4
		//  ##..##......	// 5
		//  ##..##......	// 6
		//  ##..##......	// 7
		//  ##..##......	// 8
		//  .####.......	// 9
		//  ............	// 10
		//  ............	// 11
		// 
		// 转为横向高位在前的字节数组(24字节):
		// 00 00 	// 0
		// 00 00 	// 1
		// 78 00 	// 2
		// CC 00 	// 3
		// CC 00 	// 4
		// CC 00 	// 5
		// CC 00 	// 6
		// CC 00 	// 7
		// CC 00 	// 8
		// 78 00 	// 9
		// 00 00 	// 10
		// 00 00 	// 11
		// 上面24字节就表示 12x12像素位图数据，
		// 然后就可以使用下面的压缩算法， 进行压缩
		// 压缩后的数据，直接发给打印机，就可以打印出对应的位图（如上则打印这个数字0位图）
		//
        //
    //============================================
    // compress bitmap demo
    //============================================
    // num 0 bitmap data
    // 12x12 bitmap
    BYTE cnBitmapTab[] = {
        0x00, 0x00,
        0x00, 0x00,
        0x78, 0x00,
        0xCC, 0x00,
        0xCC, 0x00,
        0xCC, 0x00,
        0xCC, 0x00,
        0xCC, 0x00,
        0xCC, 0x00,
        0x78, 0x00,
        0x00, 0x00,
        0x00, 0x00,
    };
    int width = 12;
    int len = sizeof(cnBitmapTab);
    NSLog(@"before compress=%d\r\n", len);
    //
    // first get compressed data size
    int size = getPrintPictureData(NULL, cnBitmapTab, len, width);
    //size = getPrintPictureCommand(NULL, cnBitmapTab, len, BM_LINEDOTS_BYTES(width));  // same as above
    
    // second get compressed data to out buffer
    BYTE *cmdbuffer = (BYTE *)malloc(size);
    if (cmdbuffer){
        memset(cmdbuffer, 0, size);
        size = getPrintPictureData(cmdbuffer, cnBitmapTab, len, width);
        //size = getPrintPictureCommand(cmdbuffer, cnBitmapTab, len, BM_LINEDOTS_BYTES(width)); // same as above
        
        printf("\n\n");
        for (int i=0; i<size; i++){
            if (i && i%16==0) printf("\n");
            printf("%02x ", cmdbuffer[i]);
        }
        printf("\n\n");
        
        // now the compressed data should send to bluetooth printer
        //
        // bt.write(cmdbuffer, size);
        //
        free(cmdbuffer);
    }
    NSLog(@"after compressed=%d\r\n", size);
    
    //==========================================================================
    // test Demo
    // 下面演示一个384x10dots的黑块 位图
    // 使用压缩打印指令demo
    // 压缩前: 480Bytes
    // 压缩后: 15Bytes
    width = 384;
    int w_bytes = BM_LINEDOTS_BYTES(width);	//48
    BYTE in[480];
    
    len = sizeof(in);
    NSLog(@"len=%d,%d\r\n", len, BM_LINEDOTS_BYTES(width));
    
    memset(in, 0xFF, sizeof(in));
    // first get out buffer size
    //
    // out: bitmap output data buffer
    // in: bitmap data
    // len: in buffer size
    // w_bytes: bitmap per line bytes
    size = getPrintPictureCommand(NULL, in, len, w_bytes);
    
    
    // now, get the compress bitmap data to out buffer.
    //
    // out: bitmap output data buffer
    // in: bitmap data
    // len: in buffer size
    // w_bytes: bitmap per line bytes
    BYTE *out = (BYTE *)malloc(size);
    if (out){
        size = getPrintPictureCommand(out, in, len, w_bytes);
        free(out);
    }

    NSLog(@"size=%d\r\n", size);
    
    
    // 连接成功之后，打印一张测试页。
    UIImage * img = [UIImage imageNamed:@"yellowmen.png"];
    
    [ViewController imageToTransparent:img];
}

+ (void) imageToTransparent:(UIImage*) image
{
    // 分配内存
    const int imageWidth = image.size.width;
    const int imageHeight = image.size.height;
    size_t bytesPerRow = imageWidth * 4;
    //初始化一个RGB图像流
    uint32_t* rgbImageBuf = (uint32_t*)malloc(bytesPerRow * imageHeight);
    
    // 创建context，设置RGB图像流
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    
    CGContextRef context = CGBitmapContextCreate(rgbImageBuf, imageWidth, imageHeight, 8, bytesPerRow, colorSpace,
                                                 kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipLast);
    CGColorSpaceRelease(colorSpace);
    
    //RGB图像流接受图像
    CGContextDrawImage(context, CGRectMake(0, 0, imageWidth, imageHeight), image.CGImage);
    CGContextRelease(context);
    
    int w_bytes = (imageWidth + 7) / 8;
    BYTE* dotsmap = (BYTE*)malloc(w_bytes * imageHeight);
    
    if (dotsmap){
        memset(dotsmap, 0, w_bytes * imageHeight);
        
        // 遍历像素
        int pixelNum = imageWidth * imageHeight;
        uint32_t* pCurPtr = rgbImageBuf;//
        
        for (int y=0; y<imageHeight; y++){
            for (int x = 0; x < imageWidth; x++){
                // 分离三原色及透明度
                int red = ((*pCurPtr & 0xFF000000) >> 24);
                int green = ((*pCurPtr & 0x00FF0000) >> 16);
                int blue = ((*pCurPtr & 0x0000FF00) >> 8);
                int alpha =  ((*pCurPtr & 0x000000FF) >> 0);
                pCurPtr ++;
                
                int gray = red * 0.3 + green * 0.59 + blue * 0.11;
                
                if (gray < 127){
                    int idx = y*w_bytes + (x>>3);
                    int off = x & 7;
                    dotsmap[idx] |= 0x80>>off;
                }
            }
        }
        int size = getPrintPictureCommand(NULL, dotsmap, w_bytes * imageHeight, w_bytes);
        BYTE *out = (BYTE *)malloc(size);
        if (out){
            size = getPrintPictureCommand(out, dotsmap, w_bytes * imageHeight, w_bytes);
            
            //bt.write(out, size);        // print bitmap
            
            printf("\n\n");
            for (int i=0; i<size; i++){
                if (i && i%16==0) printf("\n");
                printf("%02x ", out[i]);
            }
            printf("\n\n");
            
            
            free(out);
        }
        free(dotsmap);
    }
    
}

/** 颜色变化 */
void ProviderReleaseData(void *info, const void *data, size_t size)
{
    free((void*)data);
}

@end
