//
//  ViewController.h
//  samplebarcode
//
//

#import "AppDelegate.h"

@interface ViewController : UIViewController<BLEPrintingDiscoverDelegate>

@end

