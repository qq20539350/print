//
//  ViewController.h
//  sampletext
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface ViewController : UIViewController<BLEPrintingDiscoverDelegate>

@end

